package cn.yijie.artware.service;

import static org.junit.Assert.*;

import java.util.Date;


import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

import cn.yijie.artware.entity.News;

@ContextConfiguration("classpath:/applicationContext.xml")
public class NewsServiceImplTest extends AbstractJUnit4SpringContextTests{
	
	private INewsService newsService ;

	public INewsService getNewsService() {
		return newsService;
	}
	@Resource
	public void setNewsService(INewsService newsService) {
		this.newsService = newsService;
	}

	@Test
	public void testDoAddNews() {
		
		News news = new News() ;
		news.setTitle("ˮ�����ű���") ;
		news.setSummary("�����¸���Ҫ�˳�һ��߿Ƽ�ˮ��") ;
		news.setContent("���������߿Ƽ�ˮ���ľ�����������");
		news.setPubDate(new Date()) ;
		
		this.newsService.doAddNews(news) ;
	}

	@Test
	public void testDoDeleteNews() {
		fail("Not yet implemented");
	}

	@Test
	public void testDoDeleteNewsById() {
		fail("Not yet implemented");
	}

	@Test
	public void testDoUpdateNews() {
		fail("Not yet implemented");
	}

	@Test
	public void testFindAllNews() {
		fail("Not yet implemented");
	}

	@Test
	public void testFindNewsById() {
		fail("Not yet implemented");
	}

	@Test
	public void testFindNewsByLimitNumOrderByDate() {
		fail("Not yet implemented");
	}

}
