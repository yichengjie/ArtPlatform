package cn.yijie.artware.service;


import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

import cn.yijie.artware.entity.SalesOrder;
import cn.yijie.artware.utils.Page;

@ContextConfiguration("classpath:/applicationContext.xml")
public class SalesOrderServiceImplTest  extends AbstractJUnit4SpringContextTests{
	
	private ISalesOrderService salesOrderService ;

	public ISalesOrderService getSalesOrderService() {
		return salesOrderService;
	}
	@Resource
	public void setSalesOrderService(ISalesOrderService salesOrderService) {
		this.salesOrderService = salesOrderService;
	}

	@Test
	public void testFindMySalesOrder() {
		
		int userId = 1 ;
		Page page = new Page () ;
		List<SalesOrder> sos = this.salesOrderService.findMySalesOrder(userId,page) ;
		System.out.println("--------------------------");
		if(sos!=null&&sos.size() >0){
			for (Iterator <SalesOrder>iterator = sos.iterator();iterator.hasNext();) {
				SalesOrder salesOrder = (SalesOrder)iterator.next();
				System.out.println(salesOrder);
			}
			
		}else{
			
			System.out.println("û����Ӧ����Ϣ��");
		}
		System.out.println("--------------------------");
		
	}

}
