package cn.yijie.artware.service;


import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

import cn.yijie.artware.entity.Admin;

@ContextConfiguration("classpath:/applicationContext.xml")
public class AdminServiceImplTest extends AbstractJUnit4SpringContextTests {
	
	@Resource
	private IAdminService adminService ;
	@Test
	public void testFindLoginAdmin() {
		
	}

	@Test
	public void testDoAddAdmin() {
		Admin admin = new Admin() ;
		admin.setUsername("admin") ;
		admin.setPassword("admin") ;
		this.adminService.doAddAdmin(admin) ;
	}

}
