package cn.yijie.artware.service;


import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

import cn.yijie.artware.entity.SalesItem;
import cn.yijie.artware.utils.Page;

@ContextConfiguration("classpath:/applicationContext.xml")
public class SalesItemServiceImplTest extends AbstractJUnit4SpringContextTests {
	
	private ISalesItemService salesItemService ;
	public ISalesItemService getSalesItemService() {
		return salesItemService;
	}
	@Resource
	public void setSalesItemService(ISalesItemService salesItemService) {
		this.salesItemService = salesItemService;
	}
	@Test
	public void testFindSalesItemByUser() {
		
		int userId = 1;
		Page page = new Page() ;
		
		List<SalesItem> sms = this.salesItemService.findSalesItemByUser(userId,page) ;
		if(sms!=null&&sms.size()>0){
			System.out.println("--------------------------------------------");
			for (Iterator<SalesItem> iterator = sms.iterator(); iterator.hasNext();) {
				SalesItem salesItem = (SalesItem) iterator.next();
				System.out.println(salesItem);
			}
			System.out.println("--------------------------------------------");
		}else{
			
			System.out.println("--------------------------------------------");
			System.out.println(sms);
			System.out.println("��������Ϣ�����ڣ�");
			System.out.println("--------------------------------------------");
		}
		
	}
	
	@Test
	public void testFindAllSalesItemByArtWareId(){
		
		int artWareId = 1 ;
		List<SalesItem> sms = this.salesItemService.findAllSalesItemByArtWareId(artWareId) ;
		
		if(sms!=null&&sms.size()>0){
			System.out.println("--------------------------------------------");
			for (Iterator<SalesItem> iterator = sms.iterator(); iterator.hasNext();) {
				SalesItem salesItem = (SalesItem) iterator.next();
				System.out.println(salesItem);
			}
			System.out.println("--------------------------------------------");
		}else{
			
			System.out.println("--------------------------------------------");
			System.out.println(sms);
			System.out.println("��������Ϣ�����ڣ�");
			System.out.println("--------------------------------------------");
		}
	}
	
	@Test
	public void testDoUpdateSalesItemSetArtWareIdNull(){
		
		int artWareId = 1 ;
		this.salesItemService.doUpdateSalesItemSetArtWareIdNull(artWareId) ;
	}

}
