package cn.yijie.artware.service;


import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

import cn.yijie.artware.entity.Picture;

@ContextConfiguration("classpath:/applicationContext.xml")
public class PictureServiceImplTest  extends AbstractJUnit4SpringContextTests{
	
	@Resource
	private IPictureService pictureService ;

	@Test
	public void testDoDeletePicture() {
		
		int picId = 8 ;
		Picture p = this.pictureService.findPicById(picId) ;
		this.pictureService.doDeletePicture(p) ;
		
	}

	@Test
	public void testFindPicById() {
		int picId = 8 ;
		Picture p = this.pictureService.findPicById(picId) ;
		System.out.println(p);
	}

}
