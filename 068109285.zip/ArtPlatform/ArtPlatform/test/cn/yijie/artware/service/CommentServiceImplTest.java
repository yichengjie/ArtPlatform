package cn.yijie.artware.service;

import static org.junit.Assert.*;

import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

import cn.yijie.artware.entity.Comment;
import cn.yijie.artware.utils.Page;

@ContextConfiguration("classpath:/applicationContext.xml")
public class CommentServiceImplTest extends AbstractJUnit4SpringContextTests{
	
	private ICommentService commentService ;

	public ICommentService getCommentService() {
		return commentService;
	}
	@Resource
	public void setCommentService(ICommentService commentService) {
		this.commentService = commentService;
	}

	@Test
	public void testDoAddCommentComment() {
		
		int artWareId = 17 ;
		int userId = 1 ;
		Comment c = new Comment() ;
		c.setReview("����������,�����ٶ�Ҳͦ���!") ;
		this.commentService.doAddComment(c, artWareId, userId) ;
	}

	@Test
	public void testDoAddCommentCommentInt() {
		fail("Not yet implemented");
	}

	@Test
	public void testDoDeleteComentById() {
		fail("Not yet implemented");
	}

	@Test
	public void testFindAllCommentByArtWareId() {
	  int artWareId = 21 ;
	  Page page = new Page() ;
	  List<Comment> cs = this.commentService.findAllCommentByArtWareId(artWareId, page) ;
	  System.out.println("-------------------------------------");
	  if(cs!= null&&cs.size()>0){
		  for (Iterator<Comment> iterator = cs.iterator(); iterator.hasNext();) {
			Comment comment = (Comment) iterator.next();
			System.out.println(comment);
		}
	  }else{
		  System.out.println("��ѯ����Ϣ�����ڣ�");
	  }
	  System.out.println("-------------------------------------");
	}

	@Test
	public void testFindCommentById() {
		fail("Not yet implemented");
	}

}
