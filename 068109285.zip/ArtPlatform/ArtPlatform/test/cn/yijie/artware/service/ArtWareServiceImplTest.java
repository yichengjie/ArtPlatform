package cn.yijie.artware.service;


import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;


import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

import cn.yijie.artware.entity.ArtWare;
import cn.yijie.artware.entity.MainPicture;
import cn.yijie.artware.entity.Picture;
import cn.yijie.artware.utils.Page;

@ContextConfiguration("classpath:/applicationContext.xml")
public class ArtWareServiceImplTest extends AbstractJUnit4SpringContextTests {
	@Resource
	private IArtWareService artWareService ;
	
	@Test
	public void testDoAddArtWare() {
		
		
		ArtWare artWare = new ArtWare () ;
		artWare.setName("��һ������Ʒ") ;
		artWare.setDescr("��һ������Ʒ����") ;
		artWare.setPubdate(new Date()) ;
		artWare.setNormalPrice(15.8) ;
		artWare.setMemberPrice(15.0) ;
		//����Ʒ��ͼƬ
		MainPicture m_pic = new MainPicture() ;
		m_pic.setName("m_pic_a.jpg") ;
		artWare.setMainPicture(m_pic) ;
		
		
		//����Ʒ��һ��һ��ͼƬ
		Picture c_pic1 = new Picture () ;
		c_pic1.setName("c_pic_a1.jpg") ;
		//����Ʒ�ڶ���һ��ͼƬ
		Picture c_pic2 = new Picture () ;
		c_pic2.setName("c_pic_a2.jpg") ;
		
		artWare.addCommonPicture(c_pic1) ;
		artWare.addCommonPicture(c_pic2) ;
		
		int categoryId = 1 ;
		boolean flag = this.artWareService.doAddArtWare(artWare, categoryId) ;
		
		System.out.println(flag);
		
	}

	@Test
	public void testFindAllArtWare() {
		Page page = new Page () ;
		List<ArtWare> artWares = this.artWareService.findAllArtWare(page) ;
		
		System.out.println("===================================================");
		for (Iterator<ArtWare> iterator = artWares.iterator(); iterator.hasNext();) {
			ArtWare artWare =  iterator.next();
			System.out.println(artWare.getName());
		}
		System.out.println("===================================================");
	}
	
	@Test
	public void testFindArtWareById() {
		
		int id = 1 ;
		ArtWare artWare = this.artWareService.findArtWareById(id) ;
		if(artWare != null){
			System.out.println("artWareName : " + artWare.getName() + "  , mainPicName : " + artWare.getMainPicture().getName() );
			Set <Picture> ps = artWare.getCommonPictures() ;
			if(ps!= null&&ps.size()>0){
				for (Iterator<Picture> iterator = ps.iterator(); iterator.hasNext();) {
					Picture picture = (Picture) iterator.next();
					System.out.println(picture);
				}
			}else{
				System.out.println("��artWare û�ж�Ӧ����ͨͼƬ���ܣ�");
			}
			
		}else{
			
			System.out.println("û�в��ҵ�Id��Ӧ��ArtWare��");
		}
	}
	
	@Test
	public void testFindArtWareByCategoryId() {
		
		int categoryId = 1 ;
		Page page = new Page() ;
		page.setCurrentPage(3) ;
		List<ArtWare> artWares = this.artWareService.findArtWareByCategoryId(categoryId, page) ;
		System.out.println("------------------------------------------------");
		if(artWares!=null&&artWares.size()>0){
			for (Iterator<ArtWare> iterator = artWares.iterator(); iterator.hasNext();) {
				ArtWare artWare = (ArtWare) iterator.next();
				System.out.println(artWare);
			}
		}else{
			
			System.out.println("����������������,û�в��ҵ���Ӧ��Ŷ�Ӧ�Ĺ���Ʒ��");
		}
		System.out.println("------------------------------------------------");
	}
	
	@Test
	public void testDoDeleteArtWareById() {
		int artWareId = 12 ;
		boolean flag = this.artWareService.doDeleteArtWareById(artWareId) ;
		System.out.println(flag);
	}
	
	@Test
	public void testDoDeleteBetch(){
		
		int [] idArray =new int [1] ;
		idArray[0] = 1 ;
		//idArray[1] = 4 ;
		this.artWareService.doDeleteBetch(idArray) ;
	}
	
	@Test
	public void testDoUpdateArtWare(){
		
		 int id = 14 ; 
		 ArtWare artWare = this.artWareService.findArtWareById(id) ;
		 
		 Picture pic1 = new Picture() ;
		 pic1.setName("c_001.jpg") ;
		 
		 Picture pic2 = new Picture() ;
		 pic2.setName("c_002.jpg") ;
		 
		 artWare.addCommonPicture(pic1) ;
		 artWare.addCommonPicture(pic2) ;
		 
		 this.artWareService.doUpdateArtWare(artWare) ;
	}
	
	@Test
	public void testDoAddCommonPic(){
		
		int id = 14 ;
		ArtWare artWare = this.artWareService.findArtWareById(id) ;
		
		Picture pic1 = new Picture() ;
		pic1.setName("xinjia_a.jpg") ;
		Picture pic2 = new Picture() ;
		pic2.setName("xinjia_b.jpg") ;
		
		artWare.addCommonPicture(pic1) ;
		artWare.addCommonPicture(pic2) ;
		
		this.artWareService.doUpdateArtWare(artWare) ;
	}
	
	@Test
	public void testFindArtWareByCategoryLimitNum(){
		
		int categoryId = 1 ;
		int limitNum = 5 ;
		List<ArtWare> ars = this.artWareService.findArtWareByCategoryLimitNum(categoryId, limitNum) ;
		if(ars!= null&&ars.size()>0){
			for (Iterator <ArtWare>iterator = ars.iterator(); iterator.hasNext();) {
				ArtWare artWare = (ArtWare) iterator.next();
				System.out.println(artWare);
			}
		}else{
			
			System.out.println("�������û�������κεĹ���Ʒ��");
		}
		
	}
	
	@Test
	public void testFindArtWareByLike(){
		
		String keyWord = "gfhgf" ;
		Page page = new Page() ;
		
		List<ArtWare> ars = this.artWareService.findArtWareByLike(keyWord, page) ;
		
		this.printEntity(ars) ;
	}
	
	
	@Test
	public void testFindArtWareByLikeAndByCategoryId(){
		
		String keyWord = "" ;
		int categoryId = 1 ;
		Page page = new Page() ;
		List<ArtWare> ars = this.artWareService.findArtWareByLikeAndByCategoryId(keyWord, categoryId, page) ;
		this.printEntity(ars) ;
	}
	
	private void printEntity(Collection<?> ens){
		
		if(ens!= null&&ens.size()>0){
			for (Iterator <?>iterator = ens.iterator(); iterator.hasNext();) {
				
				System.out.println(iterator.next());
			}
		}else{
			
			System.out.println("û�в��ҵ���Ӧ��һ����¼��");
		}
	}
	
	

}
