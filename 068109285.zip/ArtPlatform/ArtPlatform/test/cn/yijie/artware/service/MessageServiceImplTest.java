package cn.yijie.artware.service;


import java.util.Date;

import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

import cn.yijie.artware.entity.Message;
import cn.yijie.artware.entity.User;


@ContextConfiguration("classpath:/applicationContext.xml")
public class MessageServiceImplTest extends AbstractJUnit4SpringContextTests {
	
	@Resource
	private IMessageService messageService ;
	@Resource
	private IUserService userService ;

	@Test
	public void testDoAddAdmin() {
		
		Message msg = new Message() ;
		msg.setContent("���ǽ���������ʽ�Ļ��ɣ���");
		msg.setPubDate(new Date()) ;
		int id = 1 ;
		User u = userService.findUserById(id) ;
		msg.setUser(u);
		
		messageService.doAddMessage(msg) ;
		
	}

}
