package cn.yijie.artware.service;

import static org.junit.Assert.*;

import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

import cn.yijie.artware.entity.User;
import cn.yijie.artware.utils.Page;

//@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:/applicationContext.xml")
public class UserServiceImplTest extends AbstractJUnit4SpringContextTests{
	
	@Resource
	IUserService userService ;

	@Test
	public void testDoAddUser() {
		User user1  = new User () ;
		user1.setUsername("yijie") ;
		user1.setPassword("123") ;
		user1.setPhone("18238112571") ;
		user1.setEmail("626659321@qq.com") ;
		user1.setAddress("��������") ;
		userService.doAddUser(user1) ;
		
		User user2  = new User () ;
		user2.setUsername("caobei") ;
		user2.setPassword("123") ;
		user2.setPhone("1234567") ;
		user2.setEmail("1234567@qq.com") ;
		user2.setAddress("��������") ;
		userService.doAddUser(user2) ;
		
		User user3  = new User () ;
		user3.setUsername("�캣") ;
		user3.setPassword("123") ;
		user3.setPhone("12345678") ;
		user3.setEmail("12345678@qq.com") ;
		user3.setAddress("��������") ;
		userService.doAddUser(user3) ;
		
		User user4  = new User () ;
		user4.setUsername("����") ;
		user4.setPassword("123") ;
		user4.setPhone("12345678") ;
		user4.setEmail("12345678@qq.com") ;
		user4.setAddress("����פ����") ;
		userService.doAddUser(user4) ;
		
		User user5  = new User () ;
		user5.setUsername("����") ;
		user5.setPassword("123") ;
		user5.setPhone("12345678") ;
		user5.setEmail("12345678@qq.com") ;
		user5.setAddress("��������") ;
		userService.doAddUser(user5) ;
		
		User user6  = new User () ;
		user6.setUsername("���ǳ�") ;
		user6.setPassword("123") ;
		user6.setPhone("12345678") ;
		user6.setEmail("12345678@qq.com") ;
		user6.setAddress("����ƽ��ɽ") ;
		userService.doAddUser(user6) ;
		
		User user7  = new User () ;
		user7.setUsername("����") ;
		user7.setPassword("123") ;
		user7.setPhone("12345678") ;
		user7.setEmail("12345678@qq.com") ;
		user7.setAddress("����") ;
		userService.doAddUser(user7) ;
		
		User user8  = new User () ;
		user8.setUsername("����") ;
		user8.setPassword("123") ;
		user8.setPhone("12345678") ;
		user8.setEmail("12345678@qq.com") ;
		user8.setAddress("���ϰ���") ;
		userService.doAddUser(user8) ;
		
		User user9  = new User () ;
		user9.setUsername("����") ;
		user9.setPassword("123") ;
		user9.setPhone("12345678") ;
		user9.setEmail("12345678@qq.com") ;
		user9.setAddress("��������") ;
		userService.doAddUser(user9) ;
		
		User user10  = new User () ;
		user10.setUsername("����") ;
		user10.setPassword("123") ;
		user10.setPhone("12345678") ;
		user10.setEmail("12345678@qq.com") ;
		user10.setAddress("��������") ;
		userService.doAddUser(user10) ;
		
		User user11  = new User () ;
		user11.setUsername("��������") ;
		user11.setPassword("123") ;
		user11.setPhone("12345678") ;
		user11.setEmail("12345678@qq.com") ;
		user11.setAddress("��������") ;
		userService.doAddUser(user11) ;
		
		User user12  = new User () ;
		user12.setUsername("����") ;
		user12.setPassword("123") ;
		user12.setPhone("12345678") ;
		user12.setEmail("12345678@qq.com") ;
		user12.setAddress("��������") ;
		userService.doAddUser(user12) ;
		
	}

	@Test
	public void testDoUpdateUser() {
		
		User user = this.userService.findUserById(2) ;
		user.setUsername("�ܱ�") ;
		user.setAddress("��������") ;
		this.userService.doUpdateUser(user) ;
 	}

	@Test
	public void testDoDeleteUser() {
		fail("Not yet implemented");
	}
	
	@Test
	//ע�������page.next()��ת����һҳ ;
	public void testFindUsersWithPage() {
		Page page = new Page() ;
		page.setPageSize(2) ;
		page.setCurrentPage(0) ;
		
		System.out.println("--------------------------------------------");
		System.out.println(page.getCurrentPage());
		System.out.println("--------------------------------------------");
		this.userService.findUsers(page) ;
		//������ת����һҳ
		page.next() ;
		List<User>users2 = this.userService.findUsers(page) ;
		Iterator <User>iter = users2.iterator() ;
		while(iter.hasNext()){
			User u = iter.next() ;
			System.out.println(u);
		}

		System.out.println("=============================================");
		System.out.println(page.getCurrentPage());
		System.out.println("=============================================");
	}
	@Test
	public void testDoDeleteUserById() {
		
		int id = 3 ;
		this.userService.doDeleteUserById(id) ;
	}

	@Test
	public void testFindAllUser() {
		fail("Not yet implemented");
	}
	
	@Test
	public void testLoginUser() {
		User user = new User () ;
		user.setUsername("yijie") ;
		user.setPassword("1234") ;
		
		User loginUser = this.userService.findLoginUser(user) ;
		if(loginUser == null){
			System.out.println("�û������ڣ�");
		}else{
			System.out.println(loginUser);
		}
	}
	@Test
	public void testFindUserById() {
		int id = 2 ;
		User u = this.userService.findUserById(id) ;
		System.out.println(u);
	}

}
