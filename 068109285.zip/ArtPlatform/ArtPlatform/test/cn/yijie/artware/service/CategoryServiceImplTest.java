package cn.yijie.artware.service;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

import cn.yijie.artware.entity.Category;
import cn.yijie.artware.utils.Page;

@ContextConfiguration("classpath:/applicationContext.xml")
public class CategoryServiceImplTest extends AbstractJUnit4SpringContextTests{
	
	@Resource
	private ICategoryService categoryService ;

	@Test
	public void testDoAddBatchCategories() {
		
		Category c1 = new Category();
		c1.setName("��԰���") ;
		c1.setDescr("��԰���Ĺ���Ʒ") ;
		
		Category c2 = new Category();
		c2.setName("ʯĥϵ��") ;
		c2.setDescr("ʯīϵ�еĹ���Ʒ");
		
		Category c3 = new Category();
		c3.setName("��ɽϵ��") ;
		c3.setDescr("��ɽϵ�еĹ���Ʒ") ;
		
		Category c4 = new Category();
		c4.setName("������Ȫ") ;
		c4.setDescr("������Ȫ�Ĺ���Ʒ") ;
		
		List<Category> cs = new ArrayList<Category>() ;
		cs.add(c1) ;
		cs.add(c2) ;
		cs.add(c3) ;
		cs.add(c4) ;
		
		this.categoryService.doAddCategories(cs) ;
		
	}
	
	@Test
	public void testDoAddBatchCategories2() {
		
		Category c1 = new Category();
		c1.setName("��԰���") ;
		c1.setDescr("��԰���Ĺ���Ʒ") ;
		
		Category c2 = new Category();
		c2.setName("ʯĥϵ��") ;
		c2.setDescr("ʯīϵ�еĹ���Ʒ");
		
		Category c3 = new Category();
		c3.setName("��ɽϵ��") ;
		c3.setDescr("��ɽϵ�еĹ���Ʒ") ;
		
		Category c4 = new Category();
		c4.setName("������Ȫ") ;
		c4.setDescr("������Ȫ�Ĺ���Ʒ") ;
		
		List<Category> cs = new ArrayList<Category>() ;
		cs.add(c1) ;
		cs.add(c2) ;
		cs.add(c3) ;
		cs.add(c4) ;
		
		this.categoryService.doAddBatchCategory(cs) ;
		
	}

	@Test
	public void testDoUpdateCategory() {
		fail("Not yet implemented");
	}
	
	@Test
	public void testfindCategoryWithPage() {
		
		Page page = new Page () ;
		page.setCurrentPage(4) ;
		List<Category> cs = this.categoryService.findCategoryWithPage(page) ;
		for (Iterator <Category>iterator = cs.iterator(); iterator.hasNext();) {
			Category category = (Category) iterator.next();
			System.out.println(category);
		}
		
	}

	@Test
	public void testDoDeleteCategory() {
		fail("Not yet implemented");
	}
	
	@Test
	public void testFindLimitNumCategory() {
		
		int limitNum = 7 ;
		
		List<Category> cas = this.categoryService.findCategoryWithLimitNum(limitNum) ;
		
		if(cas!= null&&cas.size()>0){
			System.out.println("----------------------------------");
			for (Iterator<Category> iterator = cas.iterator(); iterator.hasNext();) {
				Category category = (Category) iterator.next();
				System.out.println(category);
			}
			System.out.println("----------------------------------");
		}else{
			System.out.println("----------------------------------");
			System.out.println("û����������ʾ��");
			System.out.println("----------------------------------");
		}
	}
	
	@Test
	public void testFindCategoryByLike() {
		String keyWord = "" ;
		Page page = new Page () ;
		page.setCurrentPage(5) ;
		List<Category> list = this.categoryService.findCategoryByLike(keyWord, page) ;
		for (Iterator<Category> iterator = list.iterator(); iterator.hasNext();) {
			Category category = (Category) iterator.next();
			System.out.println(category);
			
		}
		System.out.println(page.getTotalPages());
	}

	@Test
	public void testFindCategoryById() {
		fail("Not yet implemented");
	}

	@Test
	public void testFindAllCategories() {
		List<Category> categories = this.categoryService.findAllCategories() ;
		
		if(categories!= null&&categories.size()>0){
			
			for (Iterator<Category> iterator = categories.iterator(); iterator.hasNext();) {
				Category category = (Category) iterator.next();
				System.out.println(category);
			}
		}else{
			
			System.out.println("û�д��ڵ����");
		}
	}

	@Test
	public void testDoAddRootCategory() {
		fail("Not yet implemented");
	}

}
