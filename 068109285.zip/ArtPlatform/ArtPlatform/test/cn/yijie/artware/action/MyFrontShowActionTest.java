package cn.yijie.artware.action;


import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

import cn.yijie.artware.entity.ArtWare;
import cn.yijie.artware.entity.Category;

@ContextConfiguration("classpath:/applicationContext.xml")
public class MyFrontShowActionTest extends AbstractJUnit4SpringContextTests {
	
	protected final Log log = LogFactory.getLog(getClass());
	private MyFrontShowAction myFrontShowAction ;
	
	

	public MyFrontShowAction getMyFrontShowAction() {
		return myFrontShowAction;
	}
	@Resource
	public void setMyFrontShowAction(MyFrontShowAction myFrontShowAction) {
		this.myFrontShowAction = myFrontShowAction;
	}

	@Test
	public void testListMyLimitNumCategory() throws Exception {
		
		log.warn("-----yijie-----testListMyLimitNumCategory Method start ....") ;
		String str = myFrontShowAction.listMyLimitNumCategory() ;
		
		System.out.println(str);
		
		List<Category> cs = myFrontShowAction.getMyCategory() ;
		
		if(cs!= null&&cs.size()>0){
			log.info("------yijie----������� �� " + cs.size()) ;
			
			for (Iterator<Category> iterator = cs.iterator(); iterator.hasNext();) {
				Category category = (Category) iterator.next();
				System.out.println(category);
			}
			
		}else{
			log.info("----yijie--- ��𲻴���!") ;
		}
		
	}

	@Test
	public void testListMyLatestArtWare() {
		
		
		
		String str = null;
		try {
			str = myFrontShowAction.listMyLatestArtWare();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(str);
		
		List<ArtWare> cs = myFrontShowAction.getMyLatestArtWare() ;
		
		if(cs!= null&&cs.size()>0){
			
			for (Iterator<ArtWare> iterator = cs.iterator(); iterator.hasNext();) {
				ArtWare artw = (ArtWare) iterator.next();
				System.out.println(artw);
			}
			
		}else{
			
			System.out.println("����Ʒ������!");
		}
	}

}
