package cn.yijie.artware.action;

import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

import cn.yijie.artware.entity.User;

@ContextConfiguration("classpath:/applicationContext.xml")
public class UserManagerActionTest extends AbstractJUnit4SpringContextTests{
	
	private UserManagerAction userManagerAction ;
	
	public UserManagerAction getUserManagerAction() {
		return userManagerAction;
	}
	@Resource
	public void setUserManagerAction(UserManagerAction userManagerAction) {
		this.userManagerAction = userManagerAction;
	}

	@Test
	public void testRegistUser() throws Exception {
		User user = new User () ;
		user.setUsername("�캣") ;
		user.setPassword("123") ;
		user.setPhone("1234567") ;
		user.setAddress("��������") ;
		userManagerAction.setUser(user) ;
		String str = userManagerAction.registUser() ;
		System.out.println(str);
	}

}
