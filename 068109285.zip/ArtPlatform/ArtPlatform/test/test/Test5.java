package test;

import org.apache.log4j.Logger;

import cn.yijie.artware.utils.MyImageUtil;

public class Test5 {
	
	private static Logger log  = Logger.getLogger(Test5.class.getName()) ;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyImageUtil mutilTemp = new MyImageUtil("F:\\g.jpg") ;
		int height = mutilTemp.getHeight() ;
		int width = mutilTemp.getWidth();
		if(height>198&&width>153){
			mutilTemp.resize(198, 153) ;
		}else{
			//mutilTemp.flipHorizontally() ;
			//mutilTemp.flipHorizontally() ;
			mutilTemp.multiply(198, 153) ;
		}
		//mutilTemp.saveAs("b.jpg") ;
		mutilTemp.save() ;
		log.info("height : " + height  + "   , width : " + width ) ;

	}

}
