package test;

import org.apache.log4j.Logger;


public class Test4 {
	
	private  Logger log = Logger.getLogger(this.getClass().getName()) ;
	
	public void say(){
		
		
		log.debug("this is my debug info !") ;
		log.info("this  is my info info !") ;
		log.warn("this is my warm info !") ;
		log.error("this. is my error info") ;
	}

}
