package test;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import cn.yijie.artware.entity.Picture;

public class Test2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Picture p1 = new Picture () ;
		p1.setName("p1") ;
		
		Picture p2 = new Picture() ;
		p2.setName("p2") ;
		
		System.out.println("++++++++++++++++++++++++++++++++");
		System.out.println(p1== p2);
		System.out.println(p1.getClass() == p2.getClass());
		System.out.println(p1.getId() == p2.getId());
		System.out.println(p1.equals(p2));
		System.out.println("++++++++++++++++++++++++++++++++");
		
		Set<Picture> set = new HashSet<Picture> () ;
		
		set.add(p1) ;
		set.add(p2) ;
		
		for (Iterator<Picture> iterator = set.iterator(); iterator.hasNext();) {
			Picture picture = (Picture) iterator.next();
			System.out.println(picture);
			
		}

	}

}
