package test;

import java.util.ArrayList;
import java.util.List;

public class Test3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> ls = new ArrayList<String>() ;
		ls.add("111") ;
		ls.add("222") ;
		ls.add("333") ;
		System.out.println(ls.get(1));

	}

}
