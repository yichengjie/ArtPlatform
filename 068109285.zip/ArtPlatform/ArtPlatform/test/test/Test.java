package test;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Set<String> set = new HashSet<String> () ;
		set.add("abc") ;
		set.add("efg") ;
		for (Iterator<String> iterator = set.iterator(); iterator.hasNext();) {
			String str = (String) iterator.next();
			System.out.println(str);
		}

	}

}
