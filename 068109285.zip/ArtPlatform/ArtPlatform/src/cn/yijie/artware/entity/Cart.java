package cn.yijie.artware.entity;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Cart {
	private List<CartItem> cartItems = new ArrayList<CartItem>() ;
	public List<CartItem> getCartItems() {
		return cartItems;
	}
	public void setCartItems(List<CartItem> cartItems) {
		this.cartItems = cartItems;
	}
	/**
	 * 
	 * @param artWare  ���ﳵ�����ӹ���Ʒ
	 */
	public void addArtWare(ArtWare artWare){
		
		Iterator<CartItem> iter = cartItems.iterator() ;
		
		while(iter.hasNext()){
			
			CartItem item = iter.next() ;
			if(item.getArtWare().getId() == artWare.getId()){
				
				item.setCount(item.getCount() +1 ) ;
				return ;
			}
		}
		CartItem ctim = new CartItem() ;
		ctim.setArtWare(artWare) ;
		ctim.setCount(1) ;
		cartItems.add(ctim) ;
	}
	/**
	 * 
	 * @return ���ﳵ�е���Ʒ�ܼ�Ǯ
	 */
	public double getTotalMemberPrice(){
		double tp = 0.0 ;
		Iterator<CartItem> iter = cartItems.iterator() ;
		while(iter.hasNext()){
			
			CartItem item = iter.next() ;
			tp +=item.getTotalPrice() ;
		}
		return tp;
	}
	/**
	 * 
	 * @param cartItemId   ������ƷIdɾ�����ﳵ�еĹ�����
	 * @return
	 */
	public boolean deleteCartItemById(int cartItemId){
		
		List<CartItem> cartItems = this.getCartItems() ;
		Iterator<CartItem> iter = cartItems.iterator() ;
		while(iter.hasNext()){
			CartItem cit = iter.next() ;
			if(cit.getArtWare().getId() == cartItemId){
				iter.remove() ;
				return true;
			}
		}
		return false;
	}
	
	public int getCartItemCount() {
		if(this.cartItems!=null&&this.cartItems.size()>0){
			return cartItems.size() ;
		}
		return 0 ;
	}
	
	
	public static void main(String[] args) {
		/*
		 * ���ɹ��ﳵ
		 */
		Cart cart = new Cart() ;
		/*
		 * �������ɵ�����α��Ʒ
		 */
		ArtWare p1= new ArtWare () ;
		p1.setId(1) ;
		p1.setName("����");
		p1.setMemberPrice(1.1) ;
		
		ArtWare p2= new ArtWare () ;
		p2.setId(2) ;
		p2.setName("ƻ��");
		p2.setMemberPrice(2.2) ;
		
		
		ArtWare p3= new ArtWare () ;
		p3.setId(3) ;
		p3.setName("����") ;
		p3.setMemberPrice(1.1) ;
		
		/*
		 * �빺�ﳵ������ ��Ʒ
		 */
		cart.addArtWare(p1) ;
		cart.addArtWare(p1) ;
		cart.addArtWare(p2) ;
		cart.addArtWare(p3) ;
		
		/*
		 * ͨ����Ʒidɾ�����ﳵ�еĹ�����
		 */
		//cart.deleteById(2) ;
		//cart.deleteById(1) ;
		
		/*
		 * ��ӡ���ﳵ�е����й�����
		 */
		System.out.println("-------------------------------");
		for(CartItem item :cart.getCartItems()){
			System.out.println(item.getArtWare().getId() + " , " + item.getArtWare().getName()+"  , "+ item.getCount()  );
		}
		/*
		 * ��ӡ�ܻ�Ա�۸�
		 */
		System.out.println("totalMemberPrice : " + cart.getTotalMemberPrice());
		System.out.println("-------------------------------");
	}
	

}

