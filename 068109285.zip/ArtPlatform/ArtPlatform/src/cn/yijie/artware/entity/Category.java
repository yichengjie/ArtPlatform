package cn.yijie.artware.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name ="t_category")
public class Category extends  BaseModel{
	private static final long serialVersionUID = -8049286646472142317L;
	
	//�������
	private String name;
	//�������
	private String descr ;
	//������������Ĺ���Ʒ
	private Set <ArtWare> artWares ;
	@Column(length=20,nullable=false,unique=true)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(length=200)
	public String getDescr() {
		return descr;
	}
	public void setDescr(String descr) {
		this.descr = descr;
	}
	
	@OneToMany(cascade=CascadeType.REMOVE,mappedBy="category")
	public Set<ArtWare> getArtWares() {
		return artWares;
	}
	public void setArtWares(Set<ArtWare> artWares) {
		this.artWares = artWares;
	}
	
	public void addArtWare(ArtWare a){
		
		if(this.artWares == null){
			this.artWares = new HashSet<ArtWare>() ;
		}
		this.artWares.add(a) ;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "id : " + this.getId() + " , name : " + this.getName() + " , descr : " + this.getDescr() ;
	}
	
}
