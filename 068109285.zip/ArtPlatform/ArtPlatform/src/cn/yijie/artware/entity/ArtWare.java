package cn.yijie.artware.entity;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="t_artWare")
public class ArtWare extends BaseModel{
	
	private static final long serialVersionUID = 1386248324221730651L;
	private String name ;
	private String descr;
	private double normalPrice;
	private double memberPrice;
	private Date pubdate;
	//����Ʒ��ͼƬ
	private MainPicture mainPicture ;
	private Category category ;
	//����Ʒ��ͨͼƬ
	private Set <Picture> commonPictures ;
	//����
	private Set<Comment> comments ;
	
	
	@OneToMany(cascade=CascadeType.REMOVE)
	@JoinColumn(name ="artWare_id")
	public Set<Comment> getComments() {
		return comments;
	}
	public void setComments(Set<Comment> comments) {
		this.comments = comments;
	}
	@ManyToOne
	@JoinColumn(name="category_id")
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	@Column(length=20,nullable=false)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(length=200)
	public String getDescr() {
		return descr;
	}
	public void setDescr(String descr) {
		this.descr = descr;
	}
	public double getNormalPrice() {
		return normalPrice;
	}
	public void setNormalPrice(double normalPrice) {
		this.normalPrice = normalPrice;
	}
	public double getMemberPrice() {
		return memberPrice;
	}
	public void setMemberPrice(double memberPrice) {
		this.memberPrice = memberPrice;
	}
	@Temporal(TemporalType.DATE)
	public Date getPubdate() {
		return pubdate;
	}
	public void setPubdate(Date pubdate) {
		this.pubdate = pubdate;
	}
	
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name ="mainPicture_id")
	public MainPicture getMainPicture() {
		return mainPicture;
	}
	public void setMainPicture(MainPicture mainPicture) {
		this.mainPicture = mainPicture;
	}
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name ="artWare_id")
	public Set<Picture> getCommonPictures() {
		return commonPictures;
	}
	public void setCommonPictures(Set<Picture> commonPictures) {
		this.commonPictures = commonPictures;
	}
	
	public void addCommonPicture(Picture p) {
		
		if(this.commonPictures == null){
			this.commonPictures = new HashSet<Picture>() ;
		}
		this.commonPictures.add(p) ;
	}
	
	public void addComment(Comment c){
		
		if(this.comments == null){
			this.comments = new HashSet<Comment>() ;
		}
		this.comments.add(c) ;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "id :  " + this.getId() + "  , name  : "  + this.getName();
	}

}
