package cn.yijie.artware.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="t_hotArtWareStatic")
public class HotArtWareStatic {
	
	private int id ;
	private Date dayId ;
	private int artWareId ;
	private int count ;
	
	@Id
	@GeneratedValue
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Temporal(TemporalType.DATE)
	public Date getDayId() {
		return dayId;
	}
	public void setDayId(Date dayId) {
		this.dayId = dayId;
	}
	
	public int getArtWareId() {
		return artWareId;
	}
	public void setArtWareId(int artWareId) {
		this.artWareId = artWareId;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	

}
