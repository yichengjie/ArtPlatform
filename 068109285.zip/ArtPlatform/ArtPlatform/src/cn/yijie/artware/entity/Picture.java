package cn.yijie.artware.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table(name="t_picture")
public class Picture extends BaseModel {

	private static final long serialVersionUID = 2203515039921541927L;
	
	private String name ;
	@Column(length=50,nullable=false)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String toString(){
		return "name : " + this.name  ;
	}
	
}
