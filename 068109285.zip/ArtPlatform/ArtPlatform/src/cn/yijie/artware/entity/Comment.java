package cn.yijie.artware.entity;


import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name ="t_comment")
public class Comment extends BaseModel {

	private static final long serialVersionUID = 9219017849580048430L;
	//���۵Ĺ۵�
	private String review ;
	//������
	private User user; 
	
	private Date pubDate ;
	
	@Temporal(TemporalType.DATE)
	public Date getPubDate() {
		return pubDate;
	}
	public void setPubDate(Date pubDate) {
		this.pubDate = pubDate;
	}
	@ManyToOne
	@JoinColumn(name ="user_id")
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "review : " + this.review ;
	}

}
