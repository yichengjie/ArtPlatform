package cn.yijie.artware.entity;

import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;


@Entity
@Table(name = "t_salesOrder")
public class SalesOrder extends BaseModel {
	private static final long serialVersionUID = -6540670069418229579L;
	//������
	private User user;
	//�ջ�������
	private String username_consignee ;
	//�ջ��˵绰
	private String phone_consignee ;
	//�ջ��˵绰
	private String addr_consignee;
	//�µ�ʱ��
	private Date orderDate;
	//����״̬
	private OrderStatus orderStauts;
	//������
	private Set<SalesItem> salesItems = new HashSet<SalesItem>();
	
	
	
	@ManyToOne
	@JoinColumn(name ="userid")
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	@Column(length=20,nullable=false)
	public String getUsername_consignee() {
		return username_consignee;
	}
	public void setUsername_consignee(String username_consignee) {
		this.username_consignee = username_consignee;
	}
	@Column(length=20,nullable=false)
	public String getPhone_consignee() {
		return phone_consignee;
	}
	public void setPhone_consignee(String phone_consignee) {
		this.phone_consignee = phone_consignee;
	}
	@Column(length=50,nullable=false)
	public String getAddr_consignee() {
		return addr_consignee;
	}
	public void setAddr_consignee(String addr_consignee) {
		this.addr_consignee = addr_consignee;
	}
	
	@Temporal(TemporalType.DATE)
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	@Enumerated(EnumType.STRING)
	public OrderStatus getOrderStauts() {
		return orderStauts;
	}
	public void setOrderStauts(OrderStatus orderStauts) {
		this.orderStauts = orderStauts;
	}
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name ="salesOrderId")
	public Set<SalesItem> getSalesItems() {
		return salesItems;
	}
	public void setSalesItems(Set<SalesItem> salesItems) {
		this.salesItems = salesItems;
	}
	
	@Transient
	public double getTotalMemberPrice(){
		double tp = 0.0 ;
		Iterator<SalesItem> iter = salesItems.iterator() ;
		while(iter.hasNext()){
			
			SalesItem item = iter.next() ;
			tp +=item.getTotalPrice() ;
		}
		return tp;
	}
	public void add(SalesItem salesItem){
		
		if(salesItems == null){
			
			salesItems =  new HashSet<SalesItem>();
		}
		salesItems.add(salesItem) ;
	}
	
	//����ʹ��
	public static void main(String[] args) {
		
		ArtWare artWare = new ArtWare() ;
		artWare.setName("ƻ��") ;
		artWare.setMemberPrice(8.5) ;
		
		ArtWare artWare2 = new ArtWare() ;
		artWare2.setName("�㽶") ;
		artWare2.setMemberPrice(7.5) ;
		
		SalesItem item = new SalesItem() ;
		item.setArtWare(artWare) ;
		item.setCount(3) ;
		
		SalesItem item2 = new SalesItem() ;
		item2.setArtWare(artWare2) ;
		item2.setCount(2) ;
		
		SalesOrder order = new SalesOrder() ;
		order.add(item) ;
		order.add(item2) ;
		
		System.out.println("--------------------------------------");
		System.out.println(order.getTotalMemberPrice());
		System.out.println("--------------------------------------");
		
	}
	

}
