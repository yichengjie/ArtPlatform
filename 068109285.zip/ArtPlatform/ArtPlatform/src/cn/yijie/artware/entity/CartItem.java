package cn.yijie.artware.entity;


public class CartItem {
	
	private ArtWare artWare;
	private int count  ;
	
	/*
	 * ���㹺������ܼ۸�
	 */
	public double getTotalPrice() {
		double dd = this.getArtWare().getMemberPrice() * this.getCount() ;
		return dd;
	}
	
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public ArtWare getArtWare() {
		return artWare;
	}

	public void setArtWare(ArtWare artWare) {
		this.artWare = artWare;
	}
	
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return " id : " + this.getArtWare().getName() + " , count : " + this.getCount() ;
	}

}
