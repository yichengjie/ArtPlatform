package cn.yijie.artware.entity;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name ="t_salesItem")
public class SalesItem extends BaseModel {
	private static final long serialVersionUID = -5777191498313206055L;
	
	private ArtWare artWare;
	private int count ;
	
	
	@ManyToOne
	@JoinColumn(name="artWareId")
	public ArtWare getArtWare() {
		return artWare;
	}
	public void setArtWare(ArtWare artWare) {
		this.artWare = artWare;
	}
	
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "salesItmeId : " + this.getId() + " ,count : " + this.getCount();
	}
	
	//��������ܼ�Ǯ
	@Transient
	public double getTotalPrice() {
		return this.getArtWare().getMemberPrice() * this.getCount();
	}
	

}
