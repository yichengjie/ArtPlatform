package cn.yijie.artware.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table(name="t_MainPicture")
public class MainPicture extends BaseModel{
	
	private static final long serialVersionUID = -617057045481396911L;
	
	
	private String name ;
	@Column(length=50,nullable=false)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String toString(){
		return "name : " + this.name ;
	}

}
