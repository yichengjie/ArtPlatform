package cn.yijie.artware.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import cn.yijie.artware.dto.LoginInfoVO;

@Entity
@Table(name ="t_admin")
public class Admin extends BaseModel {
	
	private static final long serialVersionUID = -2338606048567106035L;
	
	private String username ;
	private String password ;
	
	//Ĭ�Ϲ��캯��
	public Admin(){}
	
	//��¼ʱ���캯��
	public Admin(LoginInfoVO loginInfo){
		
		this.username = loginInfo.getUsername() ;
		this.password = loginInfo.getPassword() ;
	}
	
	@Column(length=20,nullable=false,unique=true)
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	@Column(length=20,nullable=false)
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
