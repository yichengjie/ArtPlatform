package cn.yijie.artware.dao;

import java.util.List;

import cn.yijie.artware.entity.Category;
import cn.yijie.artware.utils.Page;

public interface ICategoryDao {
	
	public void saveCategory(Category entity);
	public void saveCategories(List<Category> cs) ;
	public void updateCategory(Category entity) ;
	public void deleteCategory(Category entity) ;
	public Category findCategoryById(int id) ;
	public List<Category> findAllCategories() ;
	public List<Category> findCategoryWithPage(Page page) ;
	public List<Category> findCategoryByLike(String keyWord, Page page) ;
	/**
	 * 
	 * @param limitNum ��Ҫ��ʾ�������Ŀ
	 * @return  ��ʾ�޶���Ŀ����𼯺�
	 */
	public List<Category> findCategoryWithLimitNum(int limitNum) ;
}
