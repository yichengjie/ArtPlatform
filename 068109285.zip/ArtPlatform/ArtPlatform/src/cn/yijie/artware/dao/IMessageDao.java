package cn.yijie.artware.dao;

import java.util.List;

import cn.yijie.artware.entity.Message;
import cn.yijie.artware.utils.Page;

public interface IMessageDao {
	
	public void doAddMessage(Message message) ;
	public void doDeleteMessage(int id) ;
	public Message findMessageById(int id) ;
	public List<Message> listAllMessage(Page pageModel) ;

}
