package cn.yijie.artware.dao;

import cn.yijie.artware.entity.Admin;

public interface IAdminDao {
	public void   saveAdmin(Admin admin) ;
	public  Admin loginAdmin(Admin admin) ;
}
