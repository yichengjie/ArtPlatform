package cn.yijie.artware.dao;

import java.util.List;

import cn.yijie.artware.entity.User;
import cn.yijie.artware.utils.Page;


public interface IUserDao {
	
	public void saveUser(User entity);
	public void updateUser(User entity) ;
	public void deleteUser(User entity) ;
	public User findUserById(int id) ;
	public User loginUser(User user) ;
	public List<User> findAllUser() ;
	public List<User> findUsers(Page page) ;
	public User findUserByName(String username) ;

}
