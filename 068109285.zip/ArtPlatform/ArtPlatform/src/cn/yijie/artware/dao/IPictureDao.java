package cn.yijie.artware.dao;

import cn.yijie.artware.entity.Picture;

public interface IPictureDao {
	
	public void deletePicture(Picture pic) ;
	public Picture findPictureById(int picId) ;

}
