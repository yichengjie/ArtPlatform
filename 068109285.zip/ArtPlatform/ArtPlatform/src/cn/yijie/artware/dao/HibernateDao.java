package cn.yijie.artware.dao;

import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Component;


import cn.yijie.artware.utils.Page;


@Component
public class HibernateDao<T> implements IBaseDao<T>{
	private HibernateTemplate hibernateTemplate ;
	@Override
	public void save(Object entity) {
		// TODO Auto-generated method stub
		this.hibernateTemplate.save(entity) ;
	}
	@Override
	public void update(Object entity) {
		// TODO Auto-generated method stub
		this.hibernateTemplate.update(entity) ;
	}
	@Override
	public void delete(Object entity) {
		// TODO Auto-generated method stub
		this.hibernateTemplate.delete(entity) ;
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<T> findAll(String HQL) {
		// TODO Auto-generated method stub
		return this.hibernateTemplate.find(HQL);
	}
	@Override
	public T findUniqeObject(final String HQL) {
		// TODO Auto-generated method stub
		return this.hibernateTemplate.execute(new HibernateCallback<T>() {
			@SuppressWarnings("unchecked")
			@Override
			public T doInHibernate(Session session) throws HibernateException,
					SQLException {
				// TODO Auto-generated method stub
				return (T)session.createQuery(HQL).uniqueResult();
			}
		});
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<T> findAllWithPage(final int startNumber, final int pageSize, final String HQL) {
		// TODO Auto-generated method stub
		
		List<T> ls = this.hibernateTemplate.executeFind(new HibernateCallback<List<T>>() {
			@Override
			public List<T> doInHibernate(Session session) throws HibernateException,
					SQLException {
				// TODO Auto-generated method stub
				return (List<T>)session.createQuery(HQL).setMaxResults(pageSize).setFirstResult(startNumber).list() ;
			}
			
		}) ;
		return ls;
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<T> findList(String HQL) {
		// TODO Auto-generated method stub
		return (List<T>)this.hibernateTemplate.find(HQL);
	}
	@Override
	public Long getRows(final String hql) {
		// TODO Auto-generated method stub
		return  this.hibernateTemplate.execute(new HibernateCallback<Long>() {
			@Override
			public Long doInHibernate(Session session) throws HibernateException,
					SQLException {
				// TODO Auto-generated method stub
				return (Long)session.createQuery(hql).uniqueResult();
			}
		}) ;
	}
	@Override
	public Long getRows(final String HQL, final String[] params) {
		// TODO Auto-generated method stub
		return  this.hibernateTemplate.execute(new HibernateCallback<Long>() {
			@Override
			public Long doInHibernate(Session session) throws HibernateException,
					SQLException {
				// TODO Auto-generated method stub
				Query query = session.createQuery(HQL) ;
				if(params!=null&&params.length>0){
					for(int i= 0 ; i<params.length;i++){
						query.setString(i, params[i]) ;
					}
				}
				return (Long)query.uniqueResult();
			}
		}) ;
	}
	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}
	@Resource(name="hibernateTemplate")
	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	@Override
	public T findEntityById(Class<T> clazz, int id) {
		// TODO Auto-generated method stub
		return this.hibernateTemplate.get(clazz, id);
	}
	@Override
	public void saveBatchingEntities(List<T> entities) {
		// TODO Auto-generated method stub
		int count = 1 ;
		if(entities!= null&&entities.size()>0){
			for(T t :entities){
				count ++ ;
				this.hibernateTemplate.save(t) ;
				System.out.println("�����˵�"+count+"��entity------");
			}
		}else{
			System.out.println("û�пɱ���Ķ���");
		}
	}
	@Override
	public List<T> findEntityWithPage(String hql_section, String where_criteria_section, String[] params, Page page) {
		// TODO Auto-generated method stub
		if(where_criteria_section==null||where_criteria_section.length()==0){
			return findAllEntityWithPage(hql_section, page) ;
		}else{
			String count_hql = "select count(*) from " +hql_section +" where " +where_criteria_section;
			String hql  = "from " + hql_section +" where " +where_criteria_section ;
			long  count = (long)this.getRows(count_hql, params) ;
			page.setTotalRows((int)count) ;
			return this.findListWithReadyPage(hql, params, page) ;
		}
	}
	@Override
	public List<T> findAllEntityWithPage(String hql_section, Page page) {
		// TODO Auto-generated method stub
		String count_hql = "select count(*) from " +hql_section  ;
		String hql  = "from " + hql_section ;
		long allRows = (long)this.getRows(count_hql) ;
		page.setTotalRows((int)allRows) ;
		return this.findAllWithPage(page.getStartRow(), page.getPageSize(), hql) ;
	}
	@Override
	public List<T> findAllEntityWithPageOrderByDate(String hql_section,String order_section,Page page) {
		// TODO Auto-generated method stub
		String count_hql = "select count(*) from " +hql_section  ;
		String hql  = "FROM " + hql_section +" ORDER BY " + order_section  ;
		long allRows = (long)this.getRows(count_hql) ;
		page.setTotalRows((int)allRows) ;
		return this.findAllWithPage(page.getStartRow(), page.getPageSize(), hql) ;
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<T> findList(final String hql,final String[] args) {
		// TODO Auto-generated method stub
		return this.hibernateTemplate.executeFind(new HibernateCallback<List<T>>() {
			@Override
			public List<T> doInHibernate(Session session) throws HibernateException,
					SQLException {
				// TODO Auto-generated method stub
				Query query = session.createQuery(hql) ;
				if(args!=null&&args.length>0){
					for(int i= 0 ; i<args.length;i++){
						query.setString(i, args[i]) ;
					}
				}
				return (List<T>)query.list();
			}
		}) ;
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<T> findListWithReadyPage(final String hql, final String[] args, final Page page) {
		// TODO Auto-generated method stub
		if(page.getTotalRows()==0){
			System.out.println("��Ϣ�����ڣ�");
			return null;
		}else{
			return this.hibernateTemplate.executeFind(new HibernateCallback<List<T>>() {
				@Override
				public List<T> doInHibernate(Session session)
						throws HibernateException, SQLException {
					// TODO Auto-generated method stub
					Query query = session.createQuery(hql) ;
					if(args!=null&&args.length>0){
						for(int i= 0 ; i<args.length;i++){
							query.setString(i, args[i]) ;
						}
					}
					query.setMaxResults(page.getPageSize()).setFirstResult(page.getStartRow()) ;
					return query.list();
				}
			}); 
		}
	}
	@SuppressWarnings("unchecked")
	@Override
	public T findOneEntity(String hql) {
		// TODO Auto-generated method stub
		List<T> result = (List<T>)this.hibernateTemplate.find(hql) ;
		T t = null;
		if(result!= null&&result.size()>0){
			t = result.get(0) ;
		}
		return t;
	}
	@Override
	public void delete(final String hql) {
		// TODO Auto-generated method stub
		this.hibernateTemplate.execute(new HibernateCallback<T>() {
			@Override
			public T doInHibernate(Session session) throws HibernateException,
					SQLException {
				// TODO Auto-generated method stub
				session.createQuery(hql).executeUpdate() ;
				return null;
			}
		}) ;
	}
	@Override
	public void update( final String hql) {
		// TODO Auto-generated method stub
		this.hibernateTemplate.execute(new HibernateCallback<T>() {
			@Override
			public T doInHibernate(Session session) throws HibernateException,
					SQLException {
				// TODO Auto-generated method stub
				session.createQuery(hql).executeUpdate() ;
				return null;
			}
		}) ;
	}
	@Override
	public void updaetBatch(final List<T> entities) {
		// TODO Auto-generated method stub
		
		this.hibernateTemplate.execute(new HibernateCallback<T>() {
			@Override
			public T doInHibernate(Session session) throws HibernateException,
					SQLException {
				// TODO Auto-generated method stub
				
				// ѭ����ȡҩƷ����  
				for (int i = 0; i < entities.size(); i++) {  
				   T t  = (T) entities.get(i); // ��ȡҩƷ  
				   session.saveOrUpdate(t); // ����ҩƷ����  
				   // ������Ķ�������д�����ݿⲢ�ͷ��ڴ�  
				   if (i % 10 == 0) {  
				        session.flush();  
				         session.clear();  
				    }  
				}  
				return null;
			}
		}) ;
	}
	@Override
	public List<?> findLimitNumEntiry(final String hql ,final int limitNum) {
		// TODO Auto-generated method stub
		return this.hibernateTemplate.executeFind(new HibernateCallback<List<T>>() {
			@SuppressWarnings("unchecked")
			@Override
			public List<T> doInHibernate(Session session) throws HibernateException,
					SQLException {
				// TODO Auto-generated method stub
				Query query = session.createQuery(hql) ;
				query.setMaxResults(limitNum) ;
				return query.list();
			}
		}) ;
	}

}
