package cn.yijie.artware.dao;

import java.util.List;

import cn.yijie.artware.entity.SalesOrder;
import cn.yijie.artware.utils.Page;


public interface ISalesOrderDao {
	
	public void saveSalesOrder(SalesOrder salesOrder) ;
	public List<SalesOrder> getListSalesOrders(Page page) ;
	public List<SalesOrder> findSalesOrdersByLike(String keyWord,Page page) ;
	public void updateSalesOrder(SalesOrder salesOrder) ;
	public SalesOrder getSalesOrderById(int id) ;
	public SalesOrder findEagerSalesOrderById(int id) ;
	public void deleteSalesOrdersById(int id) ;
	//�ҵĶ���
	public List<SalesOrder> findMySalesOrder(int userId ,Page page) ;
	

}
