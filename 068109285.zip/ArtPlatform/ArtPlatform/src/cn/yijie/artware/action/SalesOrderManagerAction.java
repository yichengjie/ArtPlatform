package cn.yijie.artware.action;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import cn.yijie.artware.entity.OrderStatus;
import cn.yijie.artware.entity.SalesOrder;
import cn.yijie.artware.service.ISalesOrderService;
import cn.yijie.artware.utils.Page;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;

@Component("salesOrderManagerAction")
@Scope("prototype")
public class SalesOrderManagerAction extends ActionSupport {
	
	private ISalesOrderService salesOrderService ;
	private Page pageModel = new Page();
	private List<SalesOrder> salesOrders ;
	
	public List<SalesOrder> getSalesOrders() {
		return salesOrders;
	}
	public void setSalesOrders(List<SalesOrder> salesOrders) {
		this.salesOrders = salesOrders;
	}
	public Page getPageModel() {
		return pageModel;
	}
	public void setPageModel(Page pageModel) {
		this.pageModel = pageModel;
	}
	public ISalesOrderService getSalesOrderService() {
		return salesOrderService;
	}
	@Resource
	public void setSalesOrderService(ISalesOrderService salesOrderService) {
		this.salesOrderService = salesOrderService;
	}
	private static final long serialVersionUID = 97653464247260508L;
	//չʾ����
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		this.salesOrders = this.salesOrderService.findListSalesOrders(pageModel) ;
		return super.execute();
	}
	
	private String keyWord ;
	public String getKeyWord() {
		return keyWord;
	}
	public void setKeyWord(String keyWord) {
		this.keyWord = keyWord;
	}
	//ͨ���ؼ�����������
	public String searchByLike() throws Exception{
		
		this.salesOrders = this.salesOrderService.findSalesOrdersByLike(keyWord, pageModel) ;
		return Action.SUCCESS;
	}
	
	private int salesOrderId ;
	public int getSalesOrderId() {
		return salesOrderId;
	}
	public void setSalesOrderId(int salesOrderId) {
		this.salesOrderId = salesOrderId;
	}
	//ͨ������idɾ������
	public String deleteById() throws Exception{
		
		this.salesOrderService.doDeleteSalesOrdersById(salesOrderId) ;
		return Action.SUCCESS ;
	}
	private SalesOrder salesOrder;
	public SalesOrder getSalesOrder() {
		return salesOrder;
	}
	public void setSalesOrder(SalesOrder salesOrder) {
		this.salesOrder = salesOrder;
	}
	//��ת���޸Ķ���ҳ����ȥ
	public String moveToModifyPage() throws Exception{
		
		if(salesOrderId>0){
			this.salesOrder = this.salesOrderService.findSalesOrderById(salesOrderId) ;
			return Action.SUCCESS ;
		}else{
			
			return Action.ERROR ;
		}
	}
	

	private String username_consignee ;
	private String phone_consignee ;
	private String addr_consignee;
	private String orderStauts ;
	
	//�޸Ķ���
	public String getUsername_consignee() {
		return username_consignee;
	}
	public void setUsername_consignee(String username_consignee) {
		this.username_consignee = username_consignee;
	}
	public String getPhone_consignee() {
		return phone_consignee;
	}
	public void setPhone_consignee(String phone_consignee) {
		this.phone_consignee = phone_consignee;
	}
	public String getAddr_consignee() {
		return addr_consignee;
	}
	public void setAddr_consignee(String addr_consignee) {
		this.addr_consignee = addr_consignee;
	}
	public String getOrderStauts() {
		return orderStauts;
	}
	public void setOrderStauts(String orderStauts) {
		this.orderStauts = orderStauts;
	}
	//���¶���
	public String modifySalesOrder() throws Exception{
		
		SalesOrder sorder = this.salesOrderService.findSalesOrderById(salesOrderId) ;
		sorder.setAddr_consignee(this.addr_consignee) ;
		sorder.setUsername_consignee(this.username_consignee) ;
		sorder.setPhone_consignee(this.phone_consignee) ;
		OrderStatus st = OrderStatus.valueOf(orderStauts) ;
		sorder.setOrderStauts(st) ;
		this.salesOrderService.doUpdateSalesOrder(sorder) ;
		return Action.SUCCESS ;
	}
	
	private SalesOrder myDetailSalesOrder ;
	
	public SalesOrder getMyDetailSalesOrder() {
		return myDetailSalesOrder;
	}
	public void setMyDetailSalesOrder(SalesOrder myDetailSalesOrder) {
		this.myDetailSalesOrder = myDetailSalesOrder;
	}
	//������ϸ
	public String showSalesOrderById() throws Exception{
		
		this.myDetailSalesOrder = this.salesOrderService.findEagerSalesOrderById(salesOrderId) ;
		return Action.SUCCESS ;
	}

}
