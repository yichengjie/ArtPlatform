package cn.yijie.artware.action;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import cn.yijie.artware.entity.Message;
import cn.yijie.artware.service.IMessageService;
import cn.yijie.artware.utils.Page;

import com.opensymphony.xwork2.ActionSupport;

@Component("messageManagerAction")
@Scope("prototype")
public class MessageManagerAction extends ActionSupport {

	private static final long serialVersionUID = 1481655677227633136L;
	private IMessageService messageService ;
	
	private Page pageModel = new Page() ;
	
	
	public Page getPageModel() {
		return pageModel;
	}
	public void setPageModel(Page pageModel) {
		this.pageModel = pageModel;
	}
	public IMessageService getMessageService() {
		return messageService;
	}
	@Resource(name="messageService")
	public void setMessageService(IMessageService messageService) {
		this.messageService = messageService;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return super.execute();
	}
	
	private List<Message> allMsg ;
	
	public List<Message> getAllMsg() {
		return allMsg;
	}
	public void setAllMsg(List<Message> allMsg) {
		this.allMsg = allMsg;
	}
	
	//��ʾ���е�����
	public String listAllMessage() throws Exception {
		// TODO Auto-generated method stub
		
		this.allMsg = this.messageService.findAllMessage(pageModel)  ;
		return super.execute();
	}
	
	private int [] idArr ;
	
	public int[] getIdArr() {
		return idArr;
	}
	public void setIdArr(int[] idArr) {
		this.idArr = idArr;
	}
	//ɾ������
	public String deleteMessage() throws Exception{
		
		this.messageService.doDeleteArrayComment(idArr) ;
		
		return SUCCESS;
		
	}

}
