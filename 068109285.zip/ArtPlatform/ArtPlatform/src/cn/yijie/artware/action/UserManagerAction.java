package cn.yijie.artware.action;

import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import cn.yijie.artware.entity.User;
import cn.yijie.artware.service.IUserService;
import cn.yijie.artware.utils.AuthorityUtil;
import cn.yijie.artware.utils.Page;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

@Component("userManagerAction")
@Scope("prototype")
public class UserManagerAction extends ActionSupport implements ModelDriven<User>{
	private static final long serialVersionUID = 4046439656501846721L;
	private Logger log = Logger.getLogger(this.getClass().getName()) ;
	private IUserService userService ;
	//����ע��ʱ��ModelDrivernʹ��
	private User user = new User();
	//��Ա�޸���Ϣǰ����Ϣ
	private User oldInfo  ;
	
	public User getOldInfo() {
		return oldInfo;
	}
	public void setOldInfo(User oldInfo) {
		this.oldInfo = oldInfo;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public IUserService getUserService() {
		return userService;
	}
	@Resource
	public void setUserService(IUserService userService) {
		this.userService = userService;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return super.execute();
	}
	
	//�û�ע����õķ���
	public String registUser() throws Exception {
		this.userService.doAddUser(user) ;
		return SUCCESS;
	}
	//��ת���޸��û���Ϣ��ҳ����õķ���
	public String modifyUserInfoPage() throws Exception {
		this.oldInfo = AuthorityUtil.getUser() ;
		
		if(this.oldInfo!= null&&this.oldInfo.getUsername().length()>0){
			return SUCCESS;
		}else{
			this.addFieldError("fieldName", "�Բ����㻹û�е�¼���޷��鿴������Ϣ�����¼��") ;
			return LOGIN ;
		}
		
		
	}
	
	private int hiddenId ;
	public int getHiddenId() {
		return hiddenId;
	}
	public void setHiddenId(int hiddenId) {
		this.hiddenId = hiddenId;
	}
	//�޸ĸ�����Ϣ
	public String modifyUserInfo() throws Exception{
		
		
		User u = userService.findUserById(this.hiddenId) ;
		
		System.out.println("++++++++++++++++++++++++++++++++");
		System.out.println("user : " + user);
		System.out.println("u : " + u);
		System.out.println("user.userName : "+ user.getUsername());
		System.out.println("u.userName : " + u.getUsername());
		System.out.println("++++++++++++++++++++++++++++++++");
		if(u!=null&&user!=null&&user.getUsername()!=null&&u.getUsername().equals(this.user.getUsername())){
			u.setPassword(user.getPassword()) ;
			u.setAddress(user.getAddress()) ;
			u.setEmail(user.getEmail()) ;
			u.setPhone(user.getPhone());
			userService.doUpdateUser(u) ;
			return SUCCESS ;
		}else{
			
			return ERROR ;
		}
		
		
	}
	
	//�˳���¼
	public String exitLoginStatus()throws Exception{
		
		AuthorityUtil.getSession().invalidate() ;
		return SUCCESS ;
	}
	
	
	//չʾ�����û���Ϣ����
	private List<User> users ;
	//��ǰҳ����������Ϣ
	private Page pageModel = new Page() ;
	
	public Page getPageModel() {
		return pageModel;
	}
	public void setPageModel(Page pageModel) {
		this.pageModel = pageModel;
	}
	public List<User> getUsers() {
		return users;
	}
	public void setUsers(List<User> users) {
		this.users = users;
	}
	//��ʾ���е��û���Ϣ
	public String showAllUsers()throws Exception{
		
		users = this.userService.findUsers(pageModel) ;
		return SUCCESS ;
	}
	
	@Override
	public User getModel() {
		// TODO Auto-generated method stub
		return user;
	}
	
	
	private int userId ;
	private User userInfo ;
	

	public User getUserInfo() {
		return userInfo;
	}
	public void setUserInfo(User userInfo) {
		this.userInfo = userInfo;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	// ����Ա�鿴����ʱ,�鿴��������Ϣ 
	//����id�鿴ĳ�˵���Ϣ
	public String showUserById() throws Exception{
		
		userInfo = this.userService.findUserById(userId) ;
		
		return SUCCESS ;
	}
	
	//����Ա��ת���޸��û�����ҳ����ȥ
	public String adminGoToModifyUserPasswordPage() throws Exception{
		
		this.userInfo = this.userService.findUserById(userId) ;
		
		return SUCCESS ;
	}
	
	private String userPass ;
	
	public String getUserPass() {
		return userPass;
	}
	public void setUserPass(String userPass) {
		this.userPass = userPass;
	}
	//����Ա�޸��û�����
	public String adminModifyUserPassword () throws Exception{
		
		User u = this.userService.findUserById(userId) ;
		u.setPassword(this.userPass) ;
		
		this.userService.doUpdateUser(u) ;
		return SUCCESS ;
	}
	
	   //ע��ʱ������û���
		private String registusername ;
		private String flagStr  ;
		
		public String getFlagStr() {
			return flagStr;
		}
		public void setFlagStr(String flagStr) {
			this.flagStr = flagStr;
		}
		public String getRegistusername() {
			return registusername;
		}
		public void setRegistusername(String registusername) {
			this.registusername = registusername;
		}
		
		public String  checkUsernameExist ()throws Exception{
			log.info("����û����Ϸ���actionִ�п�ʼ") ;
			log.info("������û���Ϊ : " + this.registusername) ;
			boolean flag = this.userService.findUserExistStatusByName(registusername) ;
			if(flag){
				this.flagStr = "�û����Ѵ���" ;
			}else{
				this.flagStr = "�û�������" ;
			}
			log.info("flagStr  :" +  this.flagStr  ) ;
			return SUCCESS;
		}
		
	
	
}
