package cn.yijie.artware.action;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import cn.yijie.artware.entity.Comment;
import cn.yijie.artware.service.ICommentService;
import cn.yijie.artware.utils.Page;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;

@Component("commentManagerAciton")
@Scope("prototype")
public class CommentManageAction extends ActionSupport {
	private static final long serialVersionUID = 1L;
	
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return super.execute();
	}
	
	private int artWareId ;
	private ICommentService commentService ;
	private Page pageModel  = new Page();
	private List<Comment> comments ;
	
	public List<Comment> getComments() {
		return comments;
	}

	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}

	public Page getPageModel() {
		return pageModel;
	}

	public void setPageModel(Page pageModel) {
		this.pageModel = pageModel;
	}
	public int getArtWareId() {
		return artWareId;
	}
	public void setArtWareId(int artWareId) {
		this.artWareId = artWareId;
	}
	public ICommentService getCommentService() {
		return commentService;
	}
	@Resource
	public void setCommentService(ICommentService commentService) {
		this.commentService = commentService;
	}
	//ͨ������Ʒid��ѯ����Ʒ������
	public  String listComment()  throws Exception {
		this.comments = this.commentService.findAllCommentByArtWareId(artWareId, pageModel) ;
		return Action.SUCCESS ;
	}
	private int [] ids;
	public int[] getIds() {
		return ids;
	}
	public void setIds(int[] ids) {
		this.ids = ids;
	}
	//ɾ������Ʒ��Ӧ������
	public String deleteComment() throws Exception{
		this.commentService.doDeleteArrayComment(ids) ;
		return Action.SUCCESS ;
	}

}
