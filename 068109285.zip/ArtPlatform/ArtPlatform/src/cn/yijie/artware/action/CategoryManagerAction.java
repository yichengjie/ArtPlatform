package cn.yijie.artware.action;

import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import cn.yijie.artware.entity.Category;
import cn.yijie.artware.service.ICategoryService;
import cn.yijie.artware.utils.Page;

import com.opensymphony.xwork2.ActionSupport;

@Component("categoryManagerAction")
@Scope("prototype")
public class CategoryManagerAction extends ActionSupport {

	private static final long serialVersionUID = 8636040375047209771L;
	
	Logger log = Logger.getLogger(this.getClass().getName()) ;
	
	private ICategoryService categoryService ;
	private int categoryId ;
	private Category category = new Category();
	
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public ICategoryService getCategoryService() {
		return categoryService;
	}
	@Resource
	public void setCategoryService(ICategoryService categoryService) {
		this.categoryService = categoryService;
	}
	//�������
	private List<Category> categories ;
	
	public List<Category> getCategories() {
		return categories;
	}

	public void setCategories(List<Category> categories) {
		this.categories = categories;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return super.execute();
	}
	
	//��ǰҳ����������Ϣ
	private Page pageModel = new Page() ;
		
	public Page getPageModel() {
		return pageModel;
	}
	public void setPageModel(Page pageModel) {
		this.pageModel = pageModel;
	}
	
	 // ��ʾ�������ķ���
	public String listAllCategories() throws Exception {
		// TODO Auto-generated method stub
		categories  =  this.categoryService.findCategoryWithPage(pageModel) ;
		return SUCCESS;
	}
	// ��ת��д�����ҳ����
	public String moveToCategoryPage() throws Exception {
		// TODO Auto-generated method stub
		this.category = this.categoryService.findCategoryById(categoryId) ;
		return SUCCESS;
	}
	
	//�޸������Ϣ
	public String modifyCategory() throws Exception {
		// TODO Auto-generated method stub
		if(this.category.getId()>0&&this.category.getName().length()>0){
			this.categoryService.doUpdateCategory(category) ;
		}
		return SUCCESS;
	}
	
	//���������Ϣ
	public String addCategory() throws Exception {
		// TODO Auto-generated method stub
		
		log.info("---------������𷽷�ִ�п�ʼ----------") ;
		log.info("---------��Ҫ���ӵĲ��� -----> name : " + this.category.getName() + " ,  descr : " + this.category.getDescr()) ;
		if(this.category.getName().length()>0){
			this.categoryService.doAddCategory(category);
		}
		log.info("----------������𷽷�ִ�н���-----------") ;
		return SUCCESS;
	}
	
	//ɾ�����
	public String deleteCategory() throws Exception {
		// TODO Auto-generated method stub
		boolean flag = this.categoryService.doDeleteCategoryById(this.categoryId) ;
		if(!flag){
			System.out.println("ɾ�������Ϣʧ�ܣ��޷������������Id�Ų��ҵ���Ӧ�������Ϣ��");
		}
		return SUCCESS ; 
	}
	//�����ҹؼ���
	private String keyWord ;
	
	public String getKeyWord() {
		return keyWord;
	}
	public void setKeyWord(String keyWord) {
		this.keyWord = keyWord;
	}
	//���ҵ����
	public String searchCategory() throws Exception {
		// TODO Auto-generated method stub
		this.categories = this.categoryService.findCategoryByLike(keyWord, pageModel) ;
		return SUCCESS ; 
	}
	

}
