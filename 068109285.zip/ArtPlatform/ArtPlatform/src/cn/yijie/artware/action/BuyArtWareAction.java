package cn.yijie.artware.action;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.struts2.interceptor.SessionAware;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;


import cn.yijie.artware.entity.ArtWare;
import cn.yijie.artware.entity.Cart;
import cn.yijie.artware.entity.OrderStatus;
import cn.yijie.artware.entity.SalesOrder;
import cn.yijie.artware.entity.User;
import cn.yijie.artware.service.IArtWareService;
import cn.yijie.artware.service.ISalesOrderService;
import cn.yijie.artware.utils.ConvertMyCartToSalesOrder;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;

@Component("buyArtWareAction")
@Scope("prototype")
public class BuyArtWareAction extends ActionSupport implements SessionAware{
	private static final long serialVersionUID = 4179024478766739808L;
	private int artWareId; 
	Map<String, Object> session = new HashMap<String, Object>() ;
	private IArtWareService artWareService  ;


	public int getArtWareId() {
		return artWareId;
	}
	public void setArtWareId(int artWareId) {
		this.artWareId = artWareId;
	}
	public IArtWareService getArtWareService() {
		return artWareService;
	}
	@Resource
	public void setArtWareService(IArtWareService artWareService) {
		this.artWareService = artWareService;
	}
	
	public void setSession(Map<String, Object> sesison) {
		// TODO Auto-generated method stub
		this.session = sesison ;
	}
	public Map<String, Object> getSession() {
		return session;
	}


	//Ĭ�Ϻ���
	//�������ʱִ�еĺ�����������Ʒ���ӽ����ﳵ
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		
		ArtWare artWare = artWareService.findArtWareById(artWareId) ;
		System.out.println("artWareId  : " +artWareId);
		
		if(artWare == null){
			System.out.println("�Բ����㹺���id������");
			return SUCCESS;
		}else{
			
			Cart cart = (Cart)session.get("cart") ;
			
			if(cart == null){
				cart = new Cart() ;
			}
			cart.addArtWare(artWare) ;
			session.put("cart",cart) ;
			return SUCCESS;
		}
	}
	
	private int cartItemId ;
	
	public int getCartItemId() {
		return cartItemId;
	}
	public void setCartItemId(int cartItemId) {
		this.cartItemId = cartItemId;
	}
	//ɾ�����ﳵ�еĹ�����
	public String deleteCartItemInCart() throws Exception{
		
		Cart cart = (Cart)session.get("cart") ;
		if(cart!=null){
			cart.deleteCartItemById(cartItemId) ;
		}
		return Action.SUCCESS ;
	}
	
	//�ջ�������
	private String username_consignee ;
	//�ջ��˵绰
	private String phone_consignee ;
	//�ջ��˵绰
	private String addr_consignee;


	public String getUsername_consignee() {
		return username_consignee;
	}
	public void setUsername_consignee(String username_consignee) {
		this.username_consignee = username_consignee;
	}
	public String getPhone_consignee() {
		return phone_consignee;
	}
	public void setPhone_consignee(String phone_consignee) {
		this.phone_consignee = phone_consignee;
	}
	public String getAddr_consignee() {
		return addr_consignee;
	}
	public void setAddr_consignee(String addr_consignee) {
		this.addr_consignee = addr_consignee;
	}
	
	private ISalesOrderService salesOrderService ;
	
	public ISalesOrderService getSalesOrderService() {
		return salesOrderService;
	}
	@Resource
	public void setSalesOrderService(ISalesOrderService salesOrderService) {
		this.salesOrderService = salesOrderService;
	}
	//ȷ�϶���
	public String confirmMyOrder() throws Exception{
		
		
		User user = (User)session.get("user_login") ;
		
		SalesOrder salesOrder = new SalesOrder() ;
		salesOrder.setUser(user) ;
		
		salesOrder.setUsername_consignee(username_consignee) ;
		salesOrder.setPhone_consignee(phone_consignee) ;
		salesOrder.setAddr_consignee(addr_consignee) ;
		salesOrder.setOrderDate(new Date()) ;
		salesOrder.setOrderStauts(OrderStatus.δ����) ;
		
		Cart cart = (Cart)session.get("cart") ;
		ConvertMyCartToSalesOrder.convert(cart, salesOrder) ;
		this.salesOrderService.doSaveSalesOrder(salesOrder) ;
		this.session.put("cart", null) ;
		return Action.SUCCESS ;
	}
	
	
}
