package cn.yijie.artware.action;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import cn.yijie.artware.entity.News;
import cn.yijie.artware.service.INewsService;
import cn.yijie.artware.utils.Page;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;

@Component("newsManagerAction")
@Scope("prototype")
public class NewsManagerAction extends ActionSupport {

	private static final long serialVersionUID = 7561846919775867856L;
	private INewsService newsService ;
	private List<News> allNews ;
	private Page pageModel = new Page();
	
	public Page getPageModel() {
		return pageModel;
	}
	public void setPageModel(Page pageModel) {
		this.pageModel = pageModel;
	}
	public List<News> getAllNews() {
		return allNews;
	}
	public void setAllNews(List<News> allNews) {
		this.allNews = allNews;
	}
	public INewsService getNewsService() {
		return newsService;
	}
	@Resource
	public void setNewsService(INewsService newsService) {
		this.newsService = newsService;
	}
	//��ʾ���е�����
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		this.allNews = this.newsService.findAllNews(pageModel) ;
		return super.execute();
	}
	private int newsId ;
	private News myNews ;
	public News getMyNews() {
		return myNews;
	}
	public void setMyNews(News myNews) {
		this.myNews = myNews;
	}
	public int getNewsId() {
		return newsId;
	}
	public void setNewsId(int newsId) {
		this.newsId = newsId;
	}
	//ͨ��id��ѯ����
	public String listById() throws Exception {
		
		this.myNews = this.newsService.findNewsById(newsId) ;
		return Action.SUCCESS ;
	}
	//ͨ��idɾ������
	public String deleteById() throws Exception{
		
		this.newsService.doDeleteNewsById(newsId) ;
		return Action.SUCCESS ;
	}
	
	private String add_title ;
	private String add_summary ;
	private String add_content ;
	
	public String getAdd_title() {
		return add_title;
	}
	public void setAdd_title(String add_title) {
		this.add_title = add_title;
	}
	public String getAdd_summary() {
		return add_summary;
	}
	public void setAdd_summary(String add_summary) {
		this.add_summary = add_summary;
	}
	public String getAdd_content() {
		return add_content;
	}
	public void setAdd_content(String add_content) {
		this.add_content = add_content;
	}
	//��������
	public String addNews() throws Exception{
		
		News addNews = new News() ;
		addNews.setTitle(this.add_title) ;
		addNews.setSummary(this.add_summary) ;
		addNews.setContent(this.add_content) ;
		addNews.setPubDate(new Date()) ;
		
		this.newsService.doAddNews(addNews) ;
		return Action.SUCCESS ;
	}
	
	private int update_id ;
	private String update_title ;
	private String update_summary ;
	private String update_content ;
	
	public int getUpdate_id() {
		return update_id;
	}
	public void setUpdate_id(int update_id) {
		this.update_id = update_id;
	}
	public String getUpdate_title() {
		return update_title;
	}
	public void setUpdate_title(String update_title) {
		this.update_title = update_title;
	}
	public String getUpdate_summary() {
		return update_summary;
	}
	public void setUpdate_summary(String update_summary) {
		this.update_summary = update_summary;
	}
	public String getUpdate_content() {
		return update_content;
	}
	public void setUpdate_content(String update_content) {
		this.update_content = update_content;
	}
	//�޸�����
	public String updateNews() throws Exception{
		
		System.out.println("----------------------------------------");
		System.out.println(this.update_id);
		System.out.println("----------------------------------------");
		
		News u_news = this.newsService.findNewsById(this.update_id) ;
		u_news.setTitle(this.update_title) ;
		u_news.setSummary(this.update_summary) ;
		u_news.setContent(this.update_content) ;
		this.newsService.doUpdateNews(u_news) ;
		return Action.SUCCESS ;
	}
	
	//��ת���޸����� ҳ��
	public String moveToModifyNewsPage() throws Exception{
		
		System.out.println("----------------------------------------");
		System.out.println(this.newsId);
		System.out.println("----------------------------------------");
		
		this.myNews = this.newsService.findNewsById(newsId) ;
		return Action.SUCCESS ;
	}
	private String keyWord ;
	public String getKeyWord() {
		return keyWord;
	}
	public void setKeyWord(String keyWord) {
		this.keyWord = keyWord;
	}
	
	private List<News> likeNews ;
	public List<News> getLikeNews() {
		return likeNews;
	}
	public void setLikeNews(List<News> likeNews) {
		this.likeNews = likeNews;
	}
	//�ؼ�������
	public String findByLike() throws Exception{
		
		this.likeNews = this.newsService.findNewsByLike(keyWord, pageModel) ;
		return Action.SUCCESS ;
	}

}
