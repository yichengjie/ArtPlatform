package cn.yijie.artware.action;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.apache.struts2.interceptor.SessionAware;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import cn.yijie.artware.entity.ArtWare;
import cn.yijie.artware.entity.Category;
import cn.yijie.artware.entity.Comment;
import cn.yijie.artware.entity.Message;
import cn.yijie.artware.entity.News;
import cn.yijie.artware.entity.SalesItem;
import cn.yijie.artware.entity.SalesOrder;
import cn.yijie.artware.entity.User;
import cn.yijie.artware.service.IArtWareService;
import cn.yijie.artware.service.ICategoryService;
import cn.yijie.artware.service.ICommentService;
import cn.yijie.artware.service.IMessageService;
import cn.yijie.artware.service.INewsService;
import cn.yijie.artware.service.ISalesItemService;
import cn.yijie.artware.service.ISalesOrderService;
import cn.yijie.artware.utils.MyNunberUtil;
import cn.yijie.artware.utils.Page;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;

@Component("myFrontShowAction")
@Scope("prototype")
public class MyFrontShowAction extends ActionSupport implements SessionAware {
	private static final long serialVersionUID = 8399187940252750431L;
	private Logger log  = Logger.getLogger(this.getClass().getName()) ;
	private ICategoryService categoryService ;
	
	public ICategoryService getCategoryService() {
		return categoryService;
	}
	@Resource
	public void setCategoryService(ICategoryService categoryService) {
		this.categoryService = categoryService;
	}

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return super.execute();
	}
	
	private List<Category> myCategory ;

	public List<Category> getMyCategory() {
		return myCategory;
	}
	public void setMyCategory(List<Category> myCategory) {
		this.myCategory = myCategory;
	}
	
	/**
	 * 
	 * @return   ǰ̨��Ҫһ������ʾ��һ����Ŀ����𼯺�
	 * @throws Exception
	 */
	public String listMyLimitNumCategory() throws Exception {
		// TODO Auto-generated method stub
		int limitNum = 8;
		this.myCategory = this.categoryService.findCategoryWithLimitNum(limitNum) ;
		return SUCCESS;
	}
	
	private List<ArtWare> myLatestArtWare ;
	private IArtWareService artWareService ;
	
	public IArtWareService getArtWareService() {
		return artWareService;
	}
	@Resource
	public void setArtWareService(IArtWareService artWareService) {
		this.artWareService = artWareService;
	}
	public List<ArtWare> getMyLatestArtWare() {
		return myLatestArtWare;
	}
	public void setMyLatestArtWare(List<ArtWare> myLatestArtWare) {
		this.myLatestArtWare = myLatestArtWare;
	}
	
	/**
	 * @return �������µ��ض���Ŀ�Ĺ���Ʒ
	 * @throws Exception
	 */
	public String listMyLatestArtWare() throws Exception {
		// TODO Auto-generated method stub
		int limitNum  = 4 ;
		this.myLatestArtWare = this.artWareService.findArtWareByLimitNumOrderByDate(limitNum) ;
		return SUCCESS;
	}
	
	
	private int artWareId ;
	private ArtWare artWare ;
	
	public ArtWare getArtWare() {
		return artWare;
	}
	public void setArtWare(ArtWare artWare) {
		this.artWare = artWare;
	}
	public int getArtWareId() {
		return artWareId;
	}
	public void setArtWareId(int artWareId) {
		this.artWareId = artWareId;
	}
	//ͨ������Ʒid���ҵ�����Ʒ����ϸ��Ϣ
	public String showArtWareById() throws Exception {
		// TODO Auto-generated method stub
		this.artWare = artWareService.findArtWareById(artWareId) ;
		return SUCCESS;
	}
	
	//private int categoryId ;
	private String categoryId ;

	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	private List<ArtWare> allArtWare ;
	private Page pageModel = new Page() ;
	
	public Page getPageModel() {
		return pageModel;
	}
	public void setPageModel(Page pageModel) {
		this.pageModel = pageModel;
	}
	public List<ArtWare> getAllArtWare() {
		return allArtWare;
	}
	public void setAllArtWare(List<ArtWare> allArtWare) {
		this.allArtWare = allArtWare;
	}
	
	
	//ͨ��ͨ�����id�鿴����µ����й���Ʒ
	public String showArtWareByCategoryId() throws Exception {
		// TODO Auto-generated method stub
		log.info("call showArtWareByCategoryId start .....") ;
		log.info("��������idΪ  categoryIdStr : " +categoryId) ;
		Integer categoryIdNum = MyNunberUtil.getNumFromStr(categoryId) ;
		if(categoryIdNum!=null){
			this.allArtWare = this.artWareService.findArtWareByCategoryId((int)categoryIdNum, pageModel) ;
			return SUCCESS;
		}else{
			log.error("���id������������� �����ش���ҳ��") ;
			this.addFieldError("fieldName", "���id������������� �����ش���ҳ��");
			return ERROR ;
		}
		
	}
	
	//�����ؼ���
	private String keyWord ;
	private List<ArtWare> myLikeArtWare ;
	
	public List<ArtWare> getMyLikeArtWare() {
		return myLikeArtWare;
	}
	public void setMyLikeArtWare(List<ArtWare> myLikeArtWare) {
		this.myLikeArtWare = myLikeArtWare;
	}
	public String getKeyWord() {
		return keyWord;
	}
	public void setKeyWord(String keyWord) {
		this.keyWord = keyWord;
	}
	//�ؼ�����������Ʒ
	public String showArtWareByLike() throws Exception {
		// TODO Auto-generated method stub
		
		this.myLikeArtWare = this.artWareService.findArtWareByLike(keyWord, pageModel) ;
		return Action.SUCCESS;
	}
	
	//ͨ�������ؼ��ֺ����Id��������Ʒ
	public String showArtWareByLikeAndCategoryId() throws Exception {
			// TODO Auto-generated method stub
		log.info(" call showArtWareByLikeAndCategoryId start .....") ;	
		log.info("��������idΪ  categoryId : " +categoryId) ;
		Integer categoryIdNum = MyNunberUtil.getNumFromStr(categoryId) ;
		if(categoryIdNum!=null){
			this.myLikeArtWare = this.artWareService.findArtWareByLikeAndByCategoryId(keyWord, categoryIdNum, pageModel) ;
			return Action.SUCCESS;
		}else{
			log.error("���id������������� �����ش���ҳ��") ;
			this.addFieldError("fieldName", "���id������������� �����ش���ҳ��");
			return ERROR ;
		}
	} 
	
	//��ʾ���еĹ���Ʒ
	public String showAllArtWare() throws Exception{
		
		this.allArtWare = this.artWareService.findAllArtWare(pageModel);
		return Action.SUCCESS ;
	}
	
	private List<News> allNews ;
	private INewsService newsService ;
	
	
	public INewsService getNewsService() {
		return newsService;
	}
	@Resource
	public void setNewsService(INewsService newsService) {
		this.newsService = newsService;
	}
	public List<News> getAllNews() {
		return allNews;
	}
	public void setAllNews(List<News> allNews) {
		this.allNews = allNews;
	}
	//ǰ̨��ҳչ�����޸����ŷ���
	public String listAllNews() throws Exception{
		
		this.allNews = this.newsService.findAllNews(pageModel) ;
		return Action.SUCCESS ;
	}
	
	private int newsId ;
	private News singleNews ;
	public int getNewsId() {
		return newsId;
	}
	public void setNewsId(int newsId) {
		this.newsId = newsId;
	}
	public News getSingleNews() {
		return singleNews;
	}
	public void setSingleNews(News singleNews) {
		this.singleNews = singleNews;
	}
	//ͨ��id��������
	public String listNewsById() throws Exception{
		
		this.singleNews = this.newsService.findNewsById(newsId) ;
		return Action.SUCCESS ;
	}
	
	//�ؼ�����������
	private List<News> likeNews ;
	
	public List<News> getLikeNews() {
		return likeNews;
	}
	public void setLikeNews(List<News> likeNews) {
		this.likeNews = likeNews;
	}
	public String listNewsByLike() throws Exception{
		
		this.likeNews =  this.newsService.findNewsByLike(keyWord, pageModel) ;
		return Action.SUCCESS ;
	}
	 
	private List<SalesOrder> mySalesOrders ;
	private ISalesOrderService salesOrderService ;
	
	public List<SalesOrder> getMySalesOrders() {
		return mySalesOrders;
	}
	public void setMySalesOrders(List<SalesOrder> mySalesOrders) {
		this.mySalesOrders = mySalesOrders;
	}
	public ISalesOrderService getSalesOrderService() {
		return salesOrderService;
	}
	@Resource
	public void setSalesOrderService(ISalesOrderService salesOrderService) {
		this.salesOrderService = salesOrderService;
	}
	//�ҵĶ���
	public String listMySalesOrder()  throws Exception{
		
		User u = (User)this.session.get("user_login") ;
		
		if(u!=null){
			
			this.mySalesOrders = this.salesOrderService.findMySalesOrder(u.getId(), this.pageModel) ;
			return Action.SUCCESS ;
		}
		return Action.ERROR ;
	}
	
	//�ҵĶ�����
	private List<SalesItem> mySalesItems ;
	private ISalesItemService salesItemService ;
	
	public ISalesItemService getSalesItemService() {
		return salesItemService;
	}
	@Resource
	public void setSalesItemService(ISalesItemService salesItemService) {
		this.salesItemService = salesItemService;
	}
	public List<SalesItem> getMySalesItems() {
		return mySalesItems;
	}
	public void setMySalesItems(List<SalesItem> mySalesItems) {
		this.mySalesItems = mySalesItems;
	}

	private Map<String,Object> session ;
	public Map<String, Object> getSession() {
		return session;
	}
	@Override
	public void setSession(Map<String, Object> session) {
		// TODO Auto-generated method stub
		this.session = session ;
	}
	
	//�������Ĺ���Ʒ
	public String listBuyedArtWare() throws Exception{
		
		User u = (User)session.get("user_login") ;
		if(u!=null){
			
			this.mySalesItems = this.salesItemService.findSalesItemByUser(u.getId(),pageModel) ;
			return Action.SUCCESS ;
		}
		return Action.LOGIN ;
	}
	
	private ICommentService commentService ;
	private String review ;
	
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}
	public ICommentService getCommentService() {
		return commentService;
	}
	@Resource
	public void setCommentService(ICommentService commentService) {
		this.commentService = commentService;
	}
	//��������
	public String addComment() throws Exception{
		
		boolean flag = false;
		User u = (User)session.get("user_login") ;
		if(u!=null){
			
			Comment comment = new Comment() ;
			comment.setReview(review) ;
			comment.setPubDate(new Date()) ;
			flag = this.commentService.doAddComment(comment, artWareId, u.getId()) ;
			
			if(flag){
				return Action.SUCCESS ;
			}else{
				this.addFieldError("errorName", "��������ʧ�ܿ����Ƕ�Ӧ�Ĺ���Ʒ������!") ;
				return Action.ERROR ;
			}
			
		}else{
			this.addFieldError("errorName", "�û���û�е�¼!") ;
			return Action.LOGIN ;
		}
		
	}
	
	//��ת����������ҳ��
	public String moveToAddCommentPage() throws Exception {
		
		return Action.SUCCESS ;
	}
	
	private List<Comment> comments ;
	
	public List<Comment> getComments() {
		return comments;
	}
	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}
	//ͨ������Ʒid�鿴����Ʒ������
	public String listCommentByArtWareId()throws Exception{
		
		this.comments = this.commentService.findAllCommentByArtWareId(artWareId, pageModel) ;
		return Action.SUCCESS ;
	}
	
	//��ʾ�ҵĹ��ﳵ
	public String showMyCart()throws Exception{
		
		return Action.SUCCESS ;
	}
	
	
	
	
	
	
	//��ת����������
	public String  gotoAddMessagePage ()throws Exception{
		User u = (User)session.get("user_login") ;
		if(u==null){
			this.addFieldError("filedName", "�Բ�������û�е�¼�����ȵ�¼��") ;
			return LOGIN;
		}else{
			return SUCCESS;
		}
	}
	
	
	
	private String msgContent;
	private IMessageService messageService ;
	
	
	public IMessageService getMessageService() {
		return messageService;
	}
	@Resource(name ="messageService")
	public void setMessageService(IMessageService messageService) {
		this.messageService = messageService;
	}
	public String getMsgContent() {
		return msgContent;
	}
	public void setMsgContent(String msgContent) {
		this.msgContent = msgContent;
	}
	//��������
	public String  addMessage ()throws Exception{
			User u = (User)session.get("user_login") ;
			if(u==null){
				return LOGIN;
			}else{
				if(this.msgContent!=null&&msgContent.length()>5){
					if(msgContent.length()<25){
						Message m = new Message() ;
						m.setContent(this.getMsgContent()) ;
						m.setPubDate(new Date()) ;
						m.setUser(u) ;
						this.messageService.doAddMessage(m) ;
						return SUCCESS;
					}else{
						this.addFieldError("filedName", "����������Թ���(����25���ַ�)�����������룬лл������") ;
						return INPUT ;
					}
				}else{
					this.addFieldError("filedName", "����������Թ���(С��5���ַ�)�����������룬лл������") ;
					return INPUT ;
				}
			}
		}

}
