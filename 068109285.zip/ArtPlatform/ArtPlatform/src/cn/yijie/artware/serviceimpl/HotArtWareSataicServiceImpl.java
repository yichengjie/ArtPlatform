package cn.yijie.artware.serviceimpl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import cn.yijie.artware.dao.IHotArtWareStaticDao;
import cn.yijie.artware.entity.ArtWare;
import cn.yijie.artware.entity.HotArtWareStatic;
import cn.yijie.artware.service.IHotArtWareSataicService;
@Component("hotArtWareSataicService")
public class HotArtWareSataicServiceImpl implements IHotArtWareSataicService {
	
	private Logger log = Logger.getLogger(this.getClass().getName()) ;
	private IHotArtWareStaticDao hotArtWareStaticDao ;

	@Override
	public List<HotArtWareStatic> findStaticTheHotArtWareInfo() {
		// TODO Auto-generated method stub
		//Ĭ��ͳ�Ƴ�ǰʮ�����ȵĹ���Ʒ
		int limitNum = 10 ;
		return this.hotArtWareStaticDao.findStaticTheHotArtWareInfo(limitNum);
	}

	@Override
	public boolean findTodayHotArtWareExist() {
		// TODO Auto-generated method stub
		return this.hotArtWareStaticDao.findTodayHotArtWareExist();
	}

	@Override
	public void doInsertHotArtWareStatic(List<HotArtWareStatic> hcs) {
		// TODO Auto-generated method stub
		this.hotArtWareStaticDao.doInsertHotArtWareStatic(hcs) ;
	}

	@Override
	public void doInserTodayHotArtWareStatic() {
		// TODO Auto-generated method stub
		
		boolean flag = this.findTodayHotArtWareExist() ;
		//boolean flag = false ;
		if(!flag){
			log.info("��������ȹ���Ʒ���ݵ�һ��ͳ��") ;
			List<HotArtWareStatic> todayhac = this.findStaticTheHotArtWareInfo() ;
			this.doInsertHotArtWareStatic(todayhac) ;
		}else{
			log.info("����Ĺ���Ʒ�����Ѿ�ͳ�ƹ��ˣ�����Ҫ�ٴ�ͳ��") ;
		}
		
	}
	public IHotArtWareStaticDao getHotArtWareStaticDao() {
		return hotArtWareStaticDao;
	}
	@Resource
	public void setHotArtWareStaticDao(IHotArtWareStaticDao hotArtWareStaticDao) {
		this.hotArtWareStaticDao = hotArtWareStaticDao;
	}

	@Override
	public List<ArtWare> findTodayHotArtware() {
		// TODO Auto-generated method stub
		//Ĭ����ǰ̨��ʾ��������ƷͼƬ��Ϣ
		int limitNum = 6 ;
		return this.hotArtWareStaticDao.findTodayHotArtware(limitNum);
	}

}
