package cn.yijie.artware.serviceimpl;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import cn.yijie.artware.dao.IPictureDao;
import cn.yijie.artware.entity.Picture;
import cn.yijie.artware.service.IPictureService;

@Component("pictureService")
public class PictureServiceImpl implements IPictureService {
	
	private IPictureDao pictureDao ;

	public IPictureDao getPictureDao() {
		return pictureDao;
	}
	@Resource
	public void setPictureDao(IPictureDao pictureDao) {
		this.pictureDao = pictureDao;
	}

	@Override
	public void doDeletePicture(Picture pic) {
		// TODO Auto-generated method stub
		this.pictureDao.deletePicture(pic) ;
	}
	@Override
	public Picture findPicById(int picId) {
		// TODO Auto-generated method stub
		return this.pictureDao.findPictureById(picId);
	}
	@Override
	public boolean doDeletePictureById(int picId) {
		// TODO Auto-generated method stub
		Picture p = this.findPicById(picId) ;
		if(p!= null){
			this.doDeletePicture(p) ;
			return true;
		}
		return false;
	}

}
