package cn.yijie.artware.serviceimpl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import cn.yijie.artware.dao.IMessageDao;
import cn.yijie.artware.entity.Message;
import cn.yijie.artware.entity.User;
import cn.yijie.artware.service.IMessageService;
import cn.yijie.artware.service.IUserService;
import cn.yijie.artware.utils.Page;

@Component("messageService")
public class MessageServiceImpl implements IMessageService {
	
	private IMessageDao messageDao;
	private IUserService userService ;

	public IUserService getUserService() {
		return userService;
	}
	@Resource(name ="userService")
	public void setUserService(IUserService userService) {
		this.userService = userService;
	}
	public IMessageDao getMessageDao() {
		return messageDao;
	}
	@Resource(name="messageDao")
	public void setMessageDao(IMessageDao messageDao) {
		this.messageDao = messageDao;
	}

	@Override
	public void doAddMessage(Message message) {
		// TODO Auto-generated method stub
		this.messageDao.doAddMessage(message) ;
	}

	@Override
	public List<Message> findAllMessage(Page pageModel) {
		// TODO Auto-generated method stub
		return this.messageDao.listAllMessage(pageModel);
	}
	@Override
	public void doAddMessageByUserId(Message message, int userId) {
		// TODO Auto-generated method stub
		User  u = this.userService.findUserById(userId) ;
		if(u==null){
			System.out.println("������Ϣʧ�ܣ�û�в��ҵ�id��Ӧ�Ļ�Ա��Ϣ���������µ�¼��");
			
		}else{
			
			message.setUser(u) ;
			this.messageDao.doAddMessage(message) ;
		}
	}
	@Override
	public Message findMessageById(int id) {
		// TODO Auto-generated method stub
		return this.messageDao.findMessageById(id);
	}
	@Override
	public void doDeleteArrayComment(int[] arrId) {
		// TODO Auto-generated method stub
		if(arrId!=null&&arrId.length>0){
			for (int i = 0; i < arrId.length; i++) {
				this.messageDao.doDeleteMessage(arrId[i]) ;
			}
		}else{
			
			System.out.println("ɾ������ʧ��,���Զ�ӦidΪ�գ�");
		}
	}

}
