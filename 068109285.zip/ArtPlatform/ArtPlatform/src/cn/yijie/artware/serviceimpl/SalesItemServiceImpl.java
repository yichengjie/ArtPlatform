package cn.yijie.artware.serviceimpl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import cn.yijie.artware.dao.ISalesItemDao;
import cn.yijie.artware.entity.SalesItem;
import cn.yijie.artware.service.ISalesItemService;
import cn.yijie.artware.utils.Page;
@Component("salesItemService")
public class SalesItemServiceImpl implements ISalesItemService {
	
	private ISalesItemDao salesItemDao ;
	public ISalesItemDao getSalesItemDao() {
		return salesItemDao;
	}
	@Resource
	public void setSalesItemDao(ISalesItemDao salesItemDao) {
		this.salesItemDao = salesItemDao;
	}
	@Override
	public List<SalesItem> findSalesItemByUser(int userId,Page page) {
		// TODO Auto-generated method stub
		return this.salesItemDao.findSalesItemByUser(userId,page);
	}
	@Override
	public List<SalesItem> findAllSalesItemByArtWareId(int artWareId) {
		// TODO Auto-generated method stub
		return this.salesItemDao.findAllSalesItemByArtWareId(artWareId);
	}
	@Override
	public void doUpdateSalesItemSetArtWareIdNull(int artWareId) {
		// TODO Auto-generated method stub
		this.salesItemDao.doUpdateSalesItemSetArtWareIdNull(artWareId) ;
	}

}
