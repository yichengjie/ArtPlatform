package cn.yijie.artware.serviceimpl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import cn.yijie.artware.dao.ICategoryDao;
import cn.yijie.artware.entity.Category;
import cn.yijie.artware.service.ICategoryService;
import cn.yijie.artware.utils.Page;

@Component("categoryService")
public class CategoryServiceImpl implements ICategoryService {
	
	private ICategoryDao categoryDao ;

	public ICategoryDao getCategoryDao() {
		return categoryDao;
	}
	@Resource
	public void setCategoryDao(ICategoryDao categoryDao) {
		this.categoryDao = categoryDao;
	}

	@Override
	public void doAddCategory(Category entity) {
		// TODO Auto-generated method stub
		this.categoryDao.saveCategory(entity) ;
	}

	@Override
	public void doUpdateCategory(Category entity) {
		// TODO Auto-generated method stub
		this.categoryDao.updateCategory(entity) ;
	}

	@Override
	public void doDeleteCategory(Category entity) {
		// TODO Auto-generated method stub
		this.categoryDao.deleteCategory(entity) ;
	}

	@Override
	public Category findCategoryById(int id) {
		// TODO Auto-generated method stub
		return this.categoryDao.findCategoryById(id);
	}

	@Override
	public List<Category> findAllCategories() {
		// TODO Auto-generated method stub
		return this.categoryDao.findAllCategories();
	}
	@Override
	public void doAddCategories(List<Category> cs) {
		// TODO Auto-generated method stub
		this.categoryDao.saveCategories(cs) ;
	}
	@Override
	public void doAddBatchCategory(List<Category> cs) {
		// TODO Auto-generated method stub
		int count = 1 ;
		if(cs !=null&&cs.size() > 0){
			for(Category c : cs){
				count ++ ;
				this.categoryDao.saveCategory(c) ;
				System.out.println("--------------------- >  "+count);
			}
		}else{
			System.out.println("û�б����entity");
		}
	}
	@Override
	public List<Category> findCategoryWithPage(Page page) {
		// TODO Auto-generated method stub
		return this.categoryDao.findCategoryWithPage(page);
	}
	@Override
	public boolean doDeleteCategoryById(int id) {
		// TODO Auto-generated method stub
		Category c = this.findCategoryById(id) ;
		if(c!=null){
			this.doDeleteCategory(c) ;
			return true ;
		}else{
			return false;
		}
		
	}
	@Override
	public List<Category> findCategoryByLike(String keyWord, Page page) {
		// TODO Auto-generated method stub
		return this.categoryDao.findCategoryByLike(keyWord, page);
	}
	@Override
	public List<Category> findCategoryWithLimitNum(int limitNum) {
		// TODO Auto-generated method stub
		return this.categoryDao.findCategoryWithLimitNum(limitNum);
	}
	

}
