package cn.yijie.artware.serviceimpl;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import cn.yijie.artware.dao.IAdminDao;
import cn.yijie.artware.entity.Admin;
import cn.yijie.artware.service.IAdminService;

@Component("adminService")
public class AdminServiceImpl implements IAdminService {
	
	private IAdminDao adminDao ;
	
	@Override
	public Admin findLoginAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return adminDao.loginAdmin(admin);
	}
	
	public IAdminDao getAdminDao() {
		return adminDao;
	}
	@Resource
	public void setAdminDao(IAdminDao adminDao) {
		this.adminDao = adminDao;
	}

	@Override
	public void doAddAdmin(Admin admin) {
		// TODO Auto-generated method stub
		this.adminDao.saveAdmin(admin) ;
	}
}
