package cn.yijie.artware.serviceimpl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import cn.yijie.artware.dao.ISalesOrderDao;
import cn.yijie.artware.entity.SalesOrder;
import cn.yijie.artware.service.ISalesOrderService;
import cn.yijie.artware.utils.Page;

@Component("salesOrderService")
public class SalesOrderServiceImpl implements ISalesOrderService {
	
	private ISalesOrderDao salesOrderDao ;

	public ISalesOrderDao getSalesOrderDao() {
		return salesOrderDao;
	}
	@Resource
	public void setSalesOrderDao(ISalesOrderDao salesOrderDao) {
		this.salesOrderDao = salesOrderDao;
	}

	@Override
	public void doSaveSalesOrder(SalesOrder salesOrder) {
		// TODO Auto-generated method stub
		this.salesOrderDao.saveSalesOrder(salesOrder) ;
	}

	@Override
	public List<SalesOrder> findListSalesOrders(Page page) {
		// TODO Auto-generated method stub
		return this.salesOrderDao.getListSalesOrders(page);
	}

	@Override
	public void doUpdateSalesOrder(SalesOrder salesOrder) {
		// TODO Auto-generated method stub
		this.salesOrderDao.updateSalesOrder(salesOrder) ;
	}

	@Override
	public SalesOrder findSalesOrderById(int id) {
		// TODO Auto-generated method stub
		return this.salesOrderDao.getSalesOrderById(id);
	}
	@Override
	public List<SalesOrder> findSalesOrdersByLike(String keyWord, Page page) {
		// TODO Auto-generated method stub
		return this.salesOrderDao.findSalesOrdersByLike(keyWord, page);
	}
	@Override
	public void doDeleteSalesOrdersById(int id) {
		// TODO Auto-generated method stub
		this.salesOrderDao.deleteSalesOrdersById(id) ;
	}
	@Override
	public List<SalesOrder> findMySalesOrder(int userId ,Page page) {
		// TODO Auto-generated method stub
		return this.salesOrderDao.findMySalesOrder(userId,page);
	}
	@Override
	public SalesOrder findEagerSalesOrderById(int id) {
		// TODO Auto-generated method stub
		return this.salesOrderDao.findEagerSalesOrderById(id);
	}

}
