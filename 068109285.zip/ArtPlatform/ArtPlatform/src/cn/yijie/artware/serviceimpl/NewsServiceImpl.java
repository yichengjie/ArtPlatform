package cn.yijie.artware.serviceimpl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import cn.yijie.artware.dao.INewsDao;
import cn.yijie.artware.entity.News;
import cn.yijie.artware.service.INewsService;
import cn.yijie.artware.utils.Page;

@Component("newsService")
public class NewsServiceImpl implements INewsService {
	
	private INewsDao newsDao ;

	public INewsDao getNewsDao() {
		return newsDao;
	}
	@Resource
	public void setNewsDao(INewsDao newsDao) {
		this.newsDao = newsDao;
	}

	@Override
	public void doAddNews(News news) {
		// TODO Auto-generated method stub
		this.newsDao.doAddNews(news) ;
	}

	@Override
	public void doDeleteNews(News news) {
		// TODO Auto-generated method stub
		this.newsDao.doDeleteNews(news) ;
	}

	@Override
	public boolean doDeleteNewsById(int id) {
		// TODO Auto-generated method stub
		return this.newsDao.doDeleteNewsById(id);
	}

	@Override
	public void doUpdateNews(News news) {
		// TODO Auto-generated method stub
		this.newsDao.doUpdateNews(news) ;
	}

	@Override
	public List<News> findAllNews(Page page) {
		// TODO Auto-generated method stub
		return this.newsDao.findAllNews(page);
	}

	@Override
	public News findNewsById(int id) {
		// TODO Auto-generated method stub
		return this.newsDao.findNewsById(id);
	}
	@Override
	public List<News> findNewsByLimitNumOrderByDate(int limitNum) {
		// TODO Auto-generated method stub
		return this.newsDao.findNewsByLimitNumOrderByDate(limitNum);
	}
	@Override
	public List<News> findNewsByLike(String keyWord, Page page) {
		// TODO Auto-generated method stub
		return this.newsDao.findNewsByLike(keyWord, page);
	}

}
