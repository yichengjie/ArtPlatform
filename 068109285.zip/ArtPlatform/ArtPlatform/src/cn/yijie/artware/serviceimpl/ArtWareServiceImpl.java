package cn.yijie.artware.serviceimpl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import cn.yijie.artware.dao.IArtWareDao;
import cn.yijie.artware.dao.ICategoryDao;
import cn.yijie.artware.entity.ArtWare;
import cn.yijie.artware.entity.Category;
import cn.yijie.artware.service.IArtWareService;
import cn.yijie.artware.service.ISalesItemService;
import cn.yijie.artware.utils.Page;

@Component("artWareService")
public class ArtWareServiceImpl implements IArtWareService {
	
	private IArtWareDao artWareDao ;
	private ICategoryDao categoryDao ;
	private ISalesItemService salesItemService ;

	public ISalesItemService getSalesItemService() {
		return salesItemService;
	}
	@Resource
	public void setSalesItemService(ISalesItemService salesItemService) {
		this.salesItemService = salesItemService;
	}
	public ICategoryDao getCategoryDao() {
		return categoryDao;
	}
	@Resource
	public void setCategoryDao(ICategoryDao categoryDao) {
		this.categoryDao = categoryDao;
	}
	public IArtWareDao getArtWareDao() {
		return artWareDao;
	}
	@Resource(name ="artWareDao")
	public void setArtWareDao(IArtWareDao artWareDao) {
		this.artWareDao = artWareDao;
	}

	@Override
	public boolean doAddArtWare(ArtWare artWare,int categoryId) {
		// TODO Auto-generated method stub
		
		if(categoryId >0){
			Category c = categoryDao.findCategoryById(categoryId) ;
			if(c!= null){
				
				artWare.setCategory(c) ;
				//c.addArtWare(artWare) ;
				this.artWareDao.saveArtWare(artWare) ;
				return true ;
			}else{
				System.out.println("������д�����Id��Ӧ����𲻴��ڣ�");
				return false;
			}
		}
		return false;
	}

	@Override
	public List<ArtWare> findAllArtWare(Page page) {
		// TODO Auto-generated method stub
		return this.artWareDao.findAllArtWare(page);
	}
	@Override
	public ArtWare findArtWareById(int id) {
		// TODO Auto-generated method stub
		return this.artWareDao.findEagerArtWareById(id);
	}
	@Override
	public List<ArtWare> findArtWareByCategoryId(int categoryId, Page page) {
		// TODO Auto-generated method stub
		return this.artWareDao.findByCategoryId(categoryId, page);
	}
	@Override
	public boolean doDeleteArtWareById(int artWareId) {
		// TODO Auto-generated method stub
		//��ɾ������Ʒǰ��ɾ������Ʒ��Ӧ�Ķ�����������������Ե���޷�������ɾ������Ʒ
		this.salesItemService.doUpdateSalesItemSetArtWareIdNull(artWareId) ;
		return this.artWareDao.deleteArtWareById(artWareId);
	}
	@Override
	public void doDeleteBetch(int[] idArray) {
		// TODO Auto-generated method stub
		if(idArray!=null&&idArray.length>0){
			
			for(int i = 0 ; i <idArray.length;i++){
				this.salesItemService.doUpdateSalesItemSetArtWareIdNull(idArray[i]) ;
			}
		}
		 this.artWareDao.deleteArtWare(idArray) ;
	}
	@Override
	public void doUpdateArtWare(ArtWare artWare) {
		// TODO Auto-generated method stub
		this.artWareDao.update(artWare) ;
	}
	@Override
	public List<ArtWare> findArtWareByCategoryLimitNum(int categoryId,int limitNum) {
		// TODO Auto-generated method stub
		return this.artWareDao.listArtWareByCategoryLimitNum(categoryId, limitNum);
	}
	@Override
	public List<ArtWare> findArtWareByLimitNumOrderByDate(int limitNum) {
		// TODO Auto-generated method stub
		return this.artWareDao.listArtWareByLimitNumOrderByDate(limitNum);
	}
	@Override
	public List<ArtWare> findArtWareByLike(String keyWord, Page page) {
		// TODO Auto-generated method stub
		return this.artWareDao.findArtWareByLike(keyWord, page);
	}
	@Override
	public List<ArtWare> findArtWareByLikeAndByCategoryId(String keyWord,
			int categoryId, Page page) {
		// TODO Auto-generated method stub
		return this.artWareDao.findArtWareByLikeAndByCategoryId(keyWord, categoryId, page);
	}

}
