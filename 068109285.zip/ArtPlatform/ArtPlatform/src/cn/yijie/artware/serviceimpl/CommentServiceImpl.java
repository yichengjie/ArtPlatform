package cn.yijie.artware.serviceimpl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import cn.yijie.artware.dao.IArtWareDao;
import cn.yijie.artware.dao.ICommentDao;
import cn.yijie.artware.dao.IUserDao;
import cn.yijie.artware.entity.ArtWare;
import cn.yijie.artware.entity.Comment;
import cn.yijie.artware.entity.User;
import cn.yijie.artware.service.ICommentService;
import cn.yijie.artware.utils.Page;

@Component("commentService")
public class CommentServiceImpl implements ICommentService {
	
	private ICommentDao commentDao ;
	private IArtWareDao artWareDao ;
	private IUserDao userDao ;

	public IUserDao getUserDao() {
		return userDao;
	}
	@Resource
	public void setUserDao(IUserDao userDao) {
		this.userDao = userDao;
	}
	public IArtWareDao getArtWareDao() {
		return artWareDao;
	}
	@Resource
	public void setArtWareDao(IArtWareDao artWareDao) {
		this.artWareDao = artWareDao;
	}
	public ICommentDao getCommentDao() {
		return commentDao;
	}
	@Resource
	public void setCommentDao(ICommentDao commentDao) {
		this.commentDao = commentDao;
	}

	@Override
	public void doAddComment(Comment comment) {
		// TODO Auto-generated method stub
		this.commentDao.doAddComment(comment) ;
	}
	
	@Override
	public boolean doAddComment(Comment comment, int artWareId, int userId) {
		// TODO Auto-generated method stub
		ArtWare a = this.artWareDao.findEagerArtWareById(artWareId) ;
		if(a!=null){
			a.addComment(comment) ;
			User u = this.userDao.findUserById(userId) ;
			comment.setUser(u) ;
			this.commentDao.doAddComment(comment) ;
			this.artWareDao.update(a) ;
			return true;
		}else{
			return false;
		}
		
	}
	@Override
	public boolean doDeleteComentById(int id) {
		// TODO Auto-generated method stub
		return this.commentDao.doDeleteComentById(id);
	}

	@Override
	public List<Comment> findAllCommentByArtWareId(int artWareId, Page page) {
		// TODO Auto-generated method stub
		return this.commentDao.findAllCommentByArtWareId(artWareId, page);
	}

	@Override
	public Comment findCommentById(int id) {
		// TODO Auto-generated method stub
		return this.commentDao.findCommentById(id);
	}
	@Override
	public void doDeleteArrayComment(int[] arr) {
		// TODO Auto-generated method stub
		if(arr!=null&&arr.length>0){
			
			for(int i = 0 ; i < arr.length ; i ++){
				
				this.doDeleteComentById(arr[i]) ;
			}
			
		}else{
			
			System.out.println("ɾ������Ϣ������!");
		}
	}

}
