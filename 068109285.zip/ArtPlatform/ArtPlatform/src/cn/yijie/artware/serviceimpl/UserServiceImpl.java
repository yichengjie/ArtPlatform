package cn.yijie.artware.serviceimpl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import cn.yijie.artware.dao.IUserDao;
import cn.yijie.artware.entity.User;
import cn.yijie.artware.service.IUserService;
import cn.yijie.artware.utils.Page;
@Component("userService")
public class UserServiceImpl implements IUserService {
	private IUserDao userDao ;
	public IUserDao getUserDao() {
		return userDao;
	}
	@Resource
	public void setUserDao(IUserDao userDao) {
		this.userDao = userDao;
	}
	@Override
	public void doAddUser(User user) {
		// TODO Auto-generated method stub
		this.userDao.saveUser(user) ;
	}
	@Override
	public void doUpdateUser(User user) {
		// TODO Auto-generated method stub
		this.userDao.updateUser(user) ;
	}
	@Override
	public void doDeleteUser(User user) {
		// TODO Auto-generated method stub
		this.userDao.deleteUser(user) ;
	}
	@Override
	public List<User> findAllUser() {
		// TODO Auto-generated method stub
		return this.userDao.findAllUser();
	}
	@Override
	public User findUserById(int id) {
		// TODO Auto-generated method stub
		return this.userDao.findUserById(id);
	}
	@Override
	public void doDeleteUserById(int id) {
		// TODO Auto-generated method stub
		User user = this.findUserById(id) ;
		if(user != null){
			this.doDeleteUser(user) ;
		}else{
			System.out.println("ɾ���û���Ϣʧ�ܣ�û���ҵ���Ӧid���û���");
		}
	}
	@Override
	public User findLoginUser(User user) {
		// TODO Auto-generated method stub
		return this.userDao.loginUser(user);
	}
	@Override
	public List<User> findUsers(Page page) {
		// TODO Auto-generated method stub
		return this.userDao.findUsers(page);
	}
	@Override
	public boolean findUserExistStatusByName(String username) {
		// TODO Auto-generated method stub
		
		User u = this.userDao.findUserByName(username) ;
		if(u==null){
			return false;
		}else{
			return true ;
		}
	}
}
