package cn.yijie.artware.service;

import java.util.List;

import cn.yijie.artware.entity.Comment;
import cn.yijie.artware.utils.Page;

public interface ICommentService {
	public void doAddComment(Comment comment) ;
	public boolean doDeleteComentById(int id) ;
	public List<Comment> findAllCommentByArtWareId(int artWareId,Page page) ;
	public Comment findCommentById(int id) ;
	public boolean doAddComment(Comment comment,int artWareId ,int userId) ;
	public void doDeleteArrayComment(int [] arr) ;
}
