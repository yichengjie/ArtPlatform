package cn.yijie.artware.service;

import java.util.List;

import cn.yijie.artware.entity.SalesOrder;
import cn.yijie.artware.utils.Page;

public interface ISalesOrderService {
	
	public void             doSaveSalesOrder(SalesOrder salesOrder) ;
	public List<SalesOrder> findListSalesOrders(Page page) ;
	public List<SalesOrder> findSalesOrdersByLike(String keyWord,Page page) ;
	public void             doUpdateSalesOrder(SalesOrder salesOrder) ;
	public SalesOrder       findSalesOrderById(int id) ;
	public SalesOrder findEagerSalesOrderById(int id) ;
	public void doDeleteSalesOrdersById(int id) ;
	public List<SalesOrder> findMySalesOrder(int userId,Page page) ;

}
