package cn.yijie.artware.service;

import cn.yijie.artware.entity.Picture;

public interface IPictureService {
	
	public void doDeletePicture(Picture pic);
	public boolean doDeletePictureById(int picId) ;
	public Picture findPicById(int picId) ;
	

}
