package cn.yijie.artware.service;

import java.util.List;

import cn.yijie.artware.entity.Message;
import cn.yijie.artware.utils.Page;

public interface IMessageService {
	
	public void doAddMessage(Message message) ;
	public void doAddMessageByUserId(Message message ,int userId) ;
	public void doDeleteArrayComment(int [] arrId) ;
	public Message findMessageById(int id) ;
	public List<Message> findAllMessage(Page pageModel) ;
}
