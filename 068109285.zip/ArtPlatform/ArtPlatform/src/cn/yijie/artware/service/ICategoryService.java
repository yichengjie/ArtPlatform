package cn.yijie.artware.service;

import java.util.List;

import cn.yijie.artware.entity.Category;
import cn.yijie.artware.utils.Page;

public interface ICategoryService {
	
	public void doAddCategory(Category entity);
	public void doAddCategories(List<Category> cs) ;
	public void doUpdateCategory(Category entity) ;
	public void doDeleteCategory(Category entity) ;
	public Category findCategoryById(int id) ;
	public List<Category> findAllCategories() ;
	public List<Category> findCategoryWithPage(Page page) ;
	public List<Category> findCategoryByLike (String keyWord ,Page page) ;
	public void doAddBatchCategory(List<Category> cs) ;
	public boolean doDeleteCategoryById(int id) ;
	public List<Category> findCategoryWithLimitNum(int limitNum) ;

}
