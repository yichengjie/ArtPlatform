package cn.yijie.artware.service;

import java.util.List;

import cn.yijie.artware.entity.News;
import cn.yijie.artware.utils.Page;

public interface INewsService {
	
	public void doAddNews(News news) ;
	public void doDeleteNews(News news) ;
	public boolean doDeleteNewsById (int id) ;
	public void doUpdateNews(News news) ;
	public List<News> findAllNews(Page page) ;
	public News findNewsById(int id) ;
	public List<News> findNewsByLike(String keyWord,Page page) ;
	public List<News> findNewsByLimitNumOrderByDate(int limitNum) ;

}
