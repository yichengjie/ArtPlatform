package cn.yijie.artware.job;

import java.util.List;

import org.apache.log4j.Logger;

import cn.yijie.artware.entity.ArtWare;
import cn.yijie.artware.service.IHotArtWareSataicService;
import cn.yijie.artware.utils.ArtWareDailyStaticXMLDataUtil;

public class CreateMyFrontFlashXMLDataJob {
	
	private Logger log = Logger.getLogger(this.getClass().getName()) ;
	private IHotArtWareSataicService hotArtWareSataicService ;
	private ArtWareDailyStaticXMLDataUtil artWareDailyStaticXMLDataUtil ;
	
	public void work(){
		log.info("��ͳ������д��xml�ļ�������ִ�п�ʼ") ;
		List<ArtWare> ars = this.hotArtWareSataicService.findTodayHotArtware() ;
		
		if(ars!=null&&ars.size()>0){
			log.info("���е���������Ϊ :" + ars.size()) ;
			this.artWareDailyStaticXMLDataUtil.writeMyDataToXMlFile(ars) ;
			log.info("����д�����") ;
		}else{
			log.info("û���κ�������Ҫд�뵽xml�ļ���") ;
		}
		
	}
	
	public IHotArtWareSataicService getHotArtWareSataicService() {
		return hotArtWareSataicService;
	}


	public void setHotArtWareSataicService(
			IHotArtWareSataicService hotArtWareSataicService) {
		this.hotArtWareSataicService = hotArtWareSataicService;
	}


	public ArtWareDailyStaticXMLDataUtil getArtWareDailyStaticXMLDataUtil() {
		return artWareDailyStaticXMLDataUtil;
	}


	public void setArtWareDailyStaticXMLDataUtil(
			ArtWareDailyStaticXMLDataUtil artWareDailyStaticXMLDataUtil) {
		this.artWareDailyStaticXMLDataUtil = artWareDailyStaticXMLDataUtil;
	}


}
