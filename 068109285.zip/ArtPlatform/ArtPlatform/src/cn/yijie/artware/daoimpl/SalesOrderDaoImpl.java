package cn.yijie.artware.daoimpl;

import java.util.List;

import org.springframework.stereotype.Component;

import cn.yijie.artware.dao.HibernateDao;
import cn.yijie.artware.dao.ISalesOrderDao;
import cn.yijie.artware.entity.SalesOrder;
import cn.yijie.artware.utils.Page;

@Component("salesOrderDao")
public class SalesOrderDaoImpl  extends HibernateDao<SalesOrder> implements ISalesOrderDao {

	@Override
	public void saveSalesOrder(SalesOrder salesOrder) {
		// TODO Auto-generated method stub
		super.save(salesOrder) ;
	}

	@Override
	public List<SalesOrder> getListSalesOrders(Page page) {
		// TODO Auto-generated method stub
		
		String hql_section = "SalesOrder sorder" ;
		return super.findAllEntityWithPage(hql_section, page);
	}

	@Override
	public void updateSalesOrder(SalesOrder salesOrder) {
		// TODO Auto-generated method stub
		super.update(salesOrder) ;
	}

	@Override
	public SalesOrder getSalesOrderById(int id) {
		// TODO Auto-generated method stub
		return super.findEntityById(SalesOrder.class, id);
	}
	
	@Override
	public SalesOrder findEagerSalesOrderById(int id) {
		// TODO Auto-generated method stub
		String hql = "from SalesOrder sord join fetch sord.salesItems where sord.id = " + id ;
		
		return super.findUniqeObject(hql);
	}

	@Override
	public List<SalesOrder> findSalesOrdersByLike(String keyWord, Page page) {
		// TODO Auto-generated method stub
		String hql_section = "SalesOrder s" ;
		String where_criteria_section = "s.username_consignee like ? or s.addr_consignee like ? or s.user.username like ? or s.orderStauts like ? or s.orderDate like ?" ;
		String tempStr ="%"+keyWord+"%" ;
		String [] params ={tempStr,tempStr,tempStr,tempStr,tempStr} ;
		return super.findEntityWithPage(hql_section, where_criteria_section, params, page);
	}

	@Override
	public void deleteSalesOrdersById(int id) {
		// TODO Auto-generated method stub
		SalesOrder s = super.findEntityById(SalesOrder.class, id) ;
		if(s!=null){
			super.delete(s) ;
		}else{
			
			System.out.println("ɾ������ʧ�ܣ�������Ķ���id����");
		}
		
	}

	@Override
	public List<SalesOrder> findMySalesOrder(int userId,Page page) {
		// TODO Auto-generated method stub
		
		String hql_section = "SalesOrder sord where sord.user.id = " + userId ;
		return super.findAllEntityWithPage(hql_section, page);
	}

	
	

}
