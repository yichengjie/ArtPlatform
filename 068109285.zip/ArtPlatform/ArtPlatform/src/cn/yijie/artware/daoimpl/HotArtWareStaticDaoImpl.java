package cn.yijie.artware.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.stereotype.Component;

import cn.yijie.artware.dao.HibernateDao;
import cn.yijie.artware.dao.IHotArtWareStaticDao;
import cn.yijie.artware.entity.ArtWare;
import cn.yijie.artware.entity.HotArtWareStatic;
import cn.yijie.artware.entity.MainPicture;
import cn.yijie.artware.utils.MyDateNumUtil;

@Component("hotArtWareStaticDao")
public class HotArtWareStaticDaoImpl extends HibernateDao<HotArtWareStatic> implements IHotArtWareStaticDao {
	
	private  Logger log = Logger.getLogger(this.getClass().getName()) ;
	@Override
	public List<HotArtWareStatic> findStaticTheHotArtWareInfo(int limitNum) {
		
		log.info("ͳ�����ȹ���Ʒ����ִ�п�ʼ :findStaticTheHotArtWareInfo()") ;
		final String sql =" SELECT  s.artWareId  aid , SUM(s.count) st " +
					" from t_salesitem s " + 
					" WHERE s.artWareId  is not NULL " +
					" GROUP BY s.artWareId " +
					" ORDER BY st DESC " +
					" LIMIT 0, "+limitNum;
		log.info("ͳ�Ƶ�sql ��" + sql) ;
	   List<HotArtWareStatic>  list = this.getHibernateTemplate().execute(new HibernateCallback<List<HotArtWareStatic>>() {
			@Override
			public List<HotArtWareStatic>  doInHibernate(Session session) throws HibernateException,
					SQLException {
				List<HotArtWareStatic> temp = new ArrayList<HotArtWareStatic>() ;
				// TODO Auto-generated method stub
				@SuppressWarnings("deprecation")
				Connection con = session.connection();      
			    PreparedStatement ps = con.prepareStatement(sql);      
			    ResultSet rs = ps.executeQuery(); 
			    Date date = new Date() ;
			    while(rs.next()){
			    	HotArtWareStatic hc = new HotArtWareStatic() ;
			    	hc.setDayId(date) ;
			    	hc.setArtWareId(rs.getInt("aid")) ;
			    	hc.setCount(rs.getInt("st")) ;
			    	//����ѯ���Ľ�����ӵ�list������ȥ
			    	temp.add(hc) ;
			    }
			    rs.close();      
			    ps.close();      
			    session.flush();      
			    session.close();      
				return temp;
			}
		}) ;
	   if(list!=null){
		   log.info("��ͳ����" +list.size()+ "����¼") ;
	   }else{
		   
		   log.info("û��ͳ�Ƶ��κ����ݣ�") ;
	   }
	  
	   return list ;
	}

	@Override
	public boolean findTodayHotArtWareExist() {
		// TODO Auto-generated method stub
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd") ;
		log.info("��ѯ�����ͳ�������Ƿ���ڷ���ִ�п�ʼ : findTodayHotArtWareExist()" ) ;
		String HQL =  "from HotArtWareStatic h where h.dayId = '"+format.format(new Date())+"'";
		log.info("��ѯ���ȹ���Ʒsql : " +HQL) ;
		List<HotArtWareStatic> list = super.findList(HQL) ;
		log.info("��ѯ������������Ϊ��" + list.size()) ;
		boolean flag = false ;
		if(list!=null&&list.size()>0){
			flag = true ;
		}
		log.info("�鿴���صĽ��Ϊ : " + flag + "  (true ���������������Ѵ��� ,false :����ͳ�����ݲ�����) " ) ;
		return flag;
	}

	@Override
	public void doInsertHotArtWareStatic(List<HotArtWareStatic> hcs) {
		// TODO Auto-generated method stub
		log.info("�������ȹ���Ʒ����ִ�п�ʼ �� doInsertHotArtWareStatic()") ;
		if(hcs!=null&&hcs.size()>0){
			log.info("��������������Ϊ�� "  + hcs.size()) ;
			super.updaetBatch(hcs) ;
		}else{
			
			log.info("û���κοɲ�������ݣ�") ;
		}
	}

	@Override
	public List<ArtWare> findTodayHotArtware(int limitNum) {
		// TODO Auto-generated method stub
		log.info("��ѯ�������ȹ���Ʒ����ִ�� :findTodayHotArtware()") ;
		
		String dateIdStr = MyDateNumUtil.getTodayDateStr("yyyy-MM-dd") ;
		
		final String sql = "select a.id aid ,a.name aname ,mp.id mpid ,mp.name mpname from t_artware a ,t_mainpicture mp, t_hotartwarestatic hc where a.mainPicture_id = mp.id and a.id = hc.artWareId and hc.dayId = '"+dateIdStr+"'  order by hc.count desc" ;
		
		List<ArtWare>  list = this.getHibernateTemplate().execute(new HibernateCallback<List<ArtWare>>() {
			@Override
			public List<ArtWare>  doInHibernate(Session session) throws HibernateException,
					SQLException {
				List<ArtWare> temp = new ArrayList<ArtWare>() ;
				// TODO Auto-generated method stub
				@SuppressWarnings("deprecation")
				Connection con = session.connection();      
			    PreparedStatement ps = con.prepareStatement(sql);      
			    ResultSet rs = ps.executeQuery(); 
			    while(rs.next()){
			    	ArtWare a = new ArtWare() ;
			    	MainPicture mpic = new MainPicture() ;
			    	a.setId(rs.getInt("aid")) ;
			    	a.setName(rs.getString("aname")) ;
			    	mpic.setId(rs.getInt("mpid")) ;
			    	mpic.setName(rs.getString("mpname")) ;
			    	a.setMainPicture(mpic) ;
			    	//����ѯ���Ľ�����ӵ�list������ȥ
			    	temp.add(a) ;
			    }
			    rs.close();      
			    ps.close();      
			    session.flush();      
			    session.close();      
				return temp;
			}
		}) ;
		log.info("��ѯ�������ȵ��� : " +list.size() +"��") ;
		return list;
	}

}
