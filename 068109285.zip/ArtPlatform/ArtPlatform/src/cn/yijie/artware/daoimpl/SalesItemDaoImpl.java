package cn.yijie.artware.daoimpl;

import java.util.List;

import org.springframework.stereotype.Component;

import cn.yijie.artware.dao.HibernateDao;
import cn.yijie.artware.dao.ISalesItemDao;
import cn.yijie.artware.entity.SalesItem;
import cn.yijie.artware.utils.Page;
@Component("salesItemDao")
public class SalesItemDaoImpl extends HibernateDao<SalesItem> implements ISalesItemDao {

	@Override
	public List<SalesItem> findSalesItemByUser(int userId ,Page page) {
		// TODO Auto-generated method stub
		
		//String hql  = "select sm from SalesOrder sord  join fetch sord.salesItems sm where sord.user.id =" + userId ;
		
		//String hql  = "select sm from SalesOrder sord  join  SalesItem sm " ;
		//String hql  = "from SalesItem sm " ;
		  
		  String hql_count = "select count(*) from SalesOrder sord inner join sord.salesItems sm where sord.user.id =" + userId ; ;
		  long rows = super.getRows(hql_count) ;
		  page.setTotalRows((int)rows) ;
		  String hql = "select sm from SalesOrder sord inner join sord.salesItems sm where sord.user.id =" + userId ;
		  return super.findListWithReadyPage(hql, null, page);
	}

	@Override
	public List<SalesItem> findSalesItemBySalesOrderId(int salesOrderId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<SalesItem> findAllSalesItemByArtWareId(int artWareId) {
		// TODO Auto-generated method stub
		String hql = "from SalesItem sitm  where sitm.artWare.id = " + artWareId ;
		return super.findAll(hql);
	}

	@Override
	public void doUpdateSalesItemSetArtWareIdNull(int artWareId) {
		// TODO Auto-generated method stub
		String hql = "update SalesItem sm set sm.artWare.id = null where sm.artWare.id = " + artWareId ;
		super.update(hql) ;
	}

}
