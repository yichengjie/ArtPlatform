package cn.yijie.artware.daoimpl;

import java.util.List;

import org.springframework.stereotype.Component;

import cn.yijie.artware.dao.HibernateDao;
import cn.yijie.artware.dao.ICommentDao;
import cn.yijie.artware.entity.Comment;
import cn.yijie.artware.utils.Page;

@Component("commentDao")
public class CommentDaoImpl extends HibernateDao<Comment> implements ICommentDao {

	@Override
	public void doAddComment(Comment comment) {
		// TODO Auto-generated method stub
		super.save(comment) ;
	}

	@Override
	public boolean doDeleteComentById(int id) {
		// TODO Auto-generated method stub
		Comment c = this.findCommentById(id) ;
		if(c!=null){
			super.delete(c) ;
			return true;
		}
		return false;
	}

	@Override
	public List<Comment> findAllCommentByArtWareId(int artWareId,Page page) {
		// TODO Auto-generated method stub
		String hql_count = "SELECT COUNT(*) FROM ArtWare a INNER JOIN a.comments c where a.id =  " + artWareId ;
		String hql = "SELECT c FROM ArtWare a INNER JOIN a.comments c where a.id =  " + artWareId ;
		long count  = super.getRows(hql_count) ;
		page.setTotalRows((int)count) ;
		return super.findListWithReadyPage(hql, null, page) ;
	}

	@Override
	public Comment findCommentById(int id) {
		// TODO Auto-generated method stub
		return super.findEntityById(Comment.class, id);
	}

	
}
