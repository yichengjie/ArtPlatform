package cn.yijie.artware.daoimpl;

import java.util.List;

import org.springframework.stereotype.Component;

import cn.yijie.artware.dao.HibernateDao;
import cn.yijie.artware.dao.IArtWareDao;
import cn.yijie.artware.entity.ArtWare;
import cn.yijie.artware.utils.Page;

@Component("artWareDao")
public class ArtWareDaoImpl extends HibernateDao<ArtWare> implements IArtWareDao {

	@Override
	public void saveArtWare(ArtWare artWare) {
		// TODO Auto-generated method stub
		super.save(artWare) ;
	}
	

	@Override
	public List<ArtWare> findAllArtWare(Page page) {
		// TODO Auto-generated method stub
		String hql_section = "ArtWare art" ;
		return super.findAllEntityWithPage(hql_section, page) ;
	}

	@Override
	public ArtWare findEagerArtWareById(int id) {
		// TODO Auto-generated method stub//
		//String hql = "from ArtWare a left join fetch a.commonPictures cp , a.comments ac  where a.id = " + id ;
		String hql = "from ArtWare a left join fetch a.commonPictures cp left join fetch a.comments ac where a.id = " + id ;
		//return super.findOneEntity(hql) ;
		return super.findUniqeObject(hql) ;
	}


	@Override
	public List<ArtWare> findByCategoryId(int categoryId, Page page) {
		// TODO Auto-generated method stub
		String count_hql = "select count(*) from ArtWare a where a.category.id =  " + categoryId  ;
		String hql  = "select a from ArtWare a where a.category.id = "+categoryId ;
		long countRow = (long)super.getRows(count_hql) ;
		page.setTotalRows((int)countRow) ;
		return super.findListWithReadyPage(hql, null, page) ;
	}


	@Override
	public boolean deleteArtWareById(int artWareId) {
		// TODO Auto-generated method stub
		ArtWare entity = this.findEntityById(ArtWare.class, artWareId) ;
		if(entity!= null){
			entity.setCategory(null) ;
			super.delete(entity) ;
			return true;
		}else{
			System.out.println("ɾ������ʧ��!δ���ҵ�Id��Ӧ�Ĺ���Ʒ!");
			return false;
		}
	}


	@Override
	public void deleteArtWare(int[] idArray) {
		// TODO Auto-generated method stub
		if(idArray!=null&&idArray.length>0){
			for (int i = 0; i < idArray.length; i++) {
				this.deleteArtWareById(idArray[i]) ;
			}
		}else{
			
			System.out.println("ɾ������Ʒʧ��,����Ʒid�����ڣ�");
		}
		
		
	}


	@Override
	public void update(ArtWare artWare) {
		// TODO Auto-generated method stub
		super.update(artWare) ;
	}


	@Override
	public List<ArtWare> listArtWareByCategoryLimitNum(int categoryId,
			int limitNum) {
		// TODO Auto-generated method stub
		String hql = "from ArtWare a  where a.category.id = " +categoryId +" order by a.pubdate desc" ;
		List<ArtWare> ars = super.findAllWithPage(0, limitNum, hql) ;
		return ars;
	}


	@Override
	public List<ArtWare> listArtWareByLimitNumOrderByDate(int limitNum) {
		// TODO Auto-generated method stub
		String hql = "from ArtWare a  order by a.pubdate desc" ;
		List<ArtWare> ars = super.findAllWithPage(0, limitNum, hql) ;
		return ars;
	}


	@Override
	public List<ArtWare> findArtWareByLike(String keyWord, Page page) {
		// TODO Auto-generated method stub
		//String hql = "from ArtWare a where a.name like ? or a.descr like ? or a.category.name like ? or a.category.descr like ? " ;
		String hql_section = "ArtWare a " ;
		String where_criteria_section = "a.name like ? or a.descr like ? or a.category.name like ? or a.category.descr like ? " ;
		String tempStr = "%"+keyWord+"%" ;
		String []params = {tempStr,tempStr,tempStr,tempStr} ;
		List<ArtWare> ars = super.findEntityWithPage(hql_section, where_criteria_section, params, page) ;
		return ars;
	}


	@Override
	public List<ArtWare> findArtWareByLikeAndByCategoryId(String keyWord,
			int categoryId, Page page) {
		// TODO Auto-generated method stub
		String hql_section = "ArtWare a " ;
		String where_criteria_section = "a.category.id = "+categoryId+" and (a.name like ? or a.descr like ? ) ";
		//String where_criteria_section = "a.category.id = "+categoryId ;
		//String []params = null ;
		String tempStr = "%"+keyWord+"%" ;
		String []params = {tempStr,tempStr} ;
		List<ArtWare> ars = super.findEntityWithPage(hql_section, where_criteria_section, params, page) ;
		return ars;
	}



	

}
