package cn.yijie.artware.daoimpl;

import java.util.List;

import org.springframework.stereotype.Component;

import cn.yijie.artware.dao.HibernateDao;
import cn.yijie.artware.dao.INewsDao;
import cn.yijie.artware.entity.News;
import cn.yijie.artware.utils.Page;

@Component("newsDao")
public class NewsDaoImpl extends HibernateDao<News> implements INewsDao {

	@Override
	public void doAddNews(News news) {
		// TODO Auto-generated method stub
		super.save(news) ;
	}

	@Override
	public void doDeleteNews(News news) {
		// TODO Auto-generated method stub
		super.delete(news) ;
	}

	@Override
	public boolean doDeleteNewsById(int id) {
		// TODO Auto-generated method stub
		News n = this.findNewsById(id) ;
		if(n != null){
			
			super.delete(n) ;
			return true;
		}
		return false;
	}

	@Override
	public void doUpdateNews(News news) {
		// TODO Auto-generated method stub
		super.update(news) ;
	}

	@Override
	public List<News> findAllNews(Page page) {
		// TODO Auto-generated method stub
		String hql_section = "News n" ;
		String order_section = "n.pubDate DESC" ;
		return super.findAllEntityWithPageOrderByDate(hql_section, order_section, page);
	}

	@Override
	public News findNewsById(int id) {
		// TODO Auto-generated method stub
		return super.findEntityById(News.class, id);
	}

	@Override
	public List<News> findNewsByLimitNumOrderByDate(int limitNum) {
		// TODO Auto-generated method stub
		String HQL = "FROM News n ORDER BY n.pubDate DESC" ;
		return super.findAllWithPage(0, limitNum, HQL);
	}

	@Override
	public List<News> findNewsByLike(String keyWord ,Page page) {
		// TODO Auto-generated method stub
		String hql_section = "News n" ;
		String where_criteria_section = "n.title like ? or n.summary like ? or n.content like ?" ;
		String tempStr ="%" + keyWord + "%" ;
		String [] params = {tempStr,tempStr,tempStr}  ;
		return super.findEntityWithPage(hql_section, where_criteria_section, params, page);
	}

}
