package cn.yijie.artware.daoimpl;

import org.springframework.stereotype.Component;

import cn.yijie.artware.dao.HibernateDao;
import cn.yijie.artware.dao.IPictureDao;
import cn.yijie.artware.entity.Picture;

@Component("pictureDao")
public class PictureDaoImpl  extends HibernateDao<Picture> implements IPictureDao {

	@Override
	public void deletePicture(Picture pic) {
		// TODO Auto-generated method stub
		super.delete(pic) ;
	}

	@Override
	public Picture findPictureById(int picId) {
		// TODO Auto-generated method stub
		return super.findEntityById(Picture.class, picId);
	}

}
