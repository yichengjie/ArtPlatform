package cn.yijie.artware.daoimpl;

import java.util.List;

import org.springframework.stereotype.Component;

import cn.yijie.artware.dao.HibernateDao;
import cn.yijie.artware.dao.IMessageDao;
import cn.yijie.artware.entity.Message;
import cn.yijie.artware.utils.Page;
@Component("messageDao")
public class MessageDaoImpl extends HibernateDao<Message> implements IMessageDao{
	
	@Override
	public void doAddMessage(Message message) {
		// TODO Auto-generated method stub
		super.save(message) ;
	}

	@Override
	public List<Message> listAllMessage(Page pageModel) {
		// TODO Auto-generated method stub
		String hql_section = "Message m " ;
		String order_section = "m.pubDate desc" ;
		return  super.findAllEntityWithPageOrderByDate(hql_section, order_section, pageModel) ;
	}

	@Override
	public Message findMessageById(int id) {
		// TODO Auto-generated method stub
		return super.findEntityById(Message.class, id);
	}

	@Override
	public void doDeleteMessage(int id) {
		// TODO Auto-generated method stub
		Message m = this.findMessageById(id) ;
		if(m!=null){
			
			super.delete(m) ;
		}
		
	}


}
