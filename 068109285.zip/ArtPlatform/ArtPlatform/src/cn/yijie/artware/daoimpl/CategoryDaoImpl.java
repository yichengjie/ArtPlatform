package cn.yijie.artware.daoimpl;

import java.util.List;

import org.springframework.stereotype.Component;

import cn.yijie.artware.dao.HibernateDao;
import cn.yijie.artware.dao.ICategoryDao;
import cn.yijie.artware.entity.Category;
import cn.yijie.artware.utils.Page;

@Component("categoryDao")
public class CategoryDaoImpl extends HibernateDao<Category> implements ICategoryDao {

	@Override
	public void saveCategory(Category entity) {
		// TODO Auto-generated method stub
		super.save(entity) ;
	}

	@Override
	public void updateCategory(Category entity) {
		// TODO Auto-generated method stub
		super.update(entity) ;
	}

	@Override
	public void deleteCategory(Category entity) {
		// TODO Auto-generated method stub
		super.delete(entity) ;
	}

	@Override
	public Category findCategoryById(int id) {
		// TODO Auto-generated method stub
		return super.findEntityById(Category.class, id);
	}

	@Override
	public List<Category> findAllCategories() {
		// TODO Auto-generated method stub
		String HQL  = "from Category c " ;
		return super.findAll(HQL);
	}

	@Override
	public void saveCategories(List<Category> cs) {
		// TODO Auto-generated method stub
		super.saveBatchingEntities(cs) ;
	}

	@Override
	public List<Category> findCategoryWithPage(Page page) {
		// TODO Auto-generated method stub
		String hql_section = "Category c" ;
		return super.findAllEntityWithPage(hql_section, page);
	}

	@Override
	public List<Category> findCategoryByLike(String keyWord , Page page) {
		String hql_section = "Category c" ;
		String where_criteria_section = "c.name like ? or c.descr like ?" ;
		String [] params = {"%" +keyWord+"%" ,"%"+keyWord+"%"}  ;
		return super.findEntityWithPage(hql_section, where_criteria_section, params, page);
	}

	@Override
	public List<Category> findCategoryWithLimitNum(int limitNum) {
		// TODO Auto-generated method stub
		String hql = "from Category c" ;
		return super.findAllWithPage(0, limitNum, hql);
	}
}
