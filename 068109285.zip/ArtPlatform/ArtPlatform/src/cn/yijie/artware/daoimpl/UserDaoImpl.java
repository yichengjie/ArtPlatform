package cn.yijie.artware.daoimpl;

import java.util.List;

import org.springframework.stereotype.Component;

import cn.yijie.artware.dao.HibernateDao;
import cn.yijie.artware.dao.IUserDao;
import cn.yijie.artware.entity.User;
import cn.yijie.artware.utils.Page;

@Component("userDao")
public class UserDaoImpl extends HibernateDao<User> implements IUserDao{
	@Override
	public void saveUser(User entity) {
		// TODO Auto-generated method stub
		super.save(entity) ;
	}
	@Override
	public void updateUser(User entity) {
		// TODO Auto-generated method stub
		super.update(entity) ;
	}
	@Override
	public void deleteUser(User entity) {
		// TODO Auto-generated method stub
		super.delete(entity) ;
	}
	@Override
	public List<User> findAllUser() {
		// TODO Auto-generated method stub
		String HQL = "from User u" ;
		return super.findAll(HQL) ;
	}
	@Override
	public User findUserById(int id) {
		// TODO Auto-generated method stub
		return super.findEntityById(User.class, id) ;
	}
	@Override
	public User loginUser(User user) {
		// TODO Auto-generated method stub
		String hql = "from User u where u.username= '" +user.getUsername()+"' and u.password = '" + user.getPassword()+"'" ;
		return super.findUniqeObject(hql);
	}
	@Override
	public List<User> findUsers(Page page) {
		// TODO Auto-generated method stub
		String hql_section = "User u" ;
		return super.findAllEntityWithPage(hql_section, page);
	}
	@Override
	public User findUserByName(String username) {
		// TODO Auto-generated method stub
		String hql = "from User u where u.username= '" +username+"'" ;
		User u = super.findUniqeObject(hql);
		return u ;
	}
}
