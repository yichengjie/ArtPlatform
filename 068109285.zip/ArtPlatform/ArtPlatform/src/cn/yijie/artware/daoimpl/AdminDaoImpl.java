package cn.yijie.artware.daoimpl;

import org.springframework.stereotype.Component;

import cn.yijie.artware.dao.HibernateDao;
import cn.yijie.artware.dao.IAdminDao;
import cn.yijie.artware.entity.Admin;

@Component("adminDao")
public class AdminDaoImpl extends HibernateDao<Admin> implements IAdminDao {
	

	@Override
	public Admin loginAdmin(Admin admin) {
		// TODO Auto-generated method stub
		String hql = "from Admin a where a.username = '" + admin.getUsername() +"' and a.password = '" + admin.getPassword() + "'" ; 
		return super.findUniqeObject(hql);
	}

	@Override
	public void saveAdmin(Admin admin) {
		// TODO Auto-generated method stub
		super.save(admin) ;
	}

}
