package cn.yijie.artware.filter;


import java.io.UnsupportedEncodingException;   
  
import javax.servlet.http.HttpServletRequest;   
import javax.servlet.http.HttpServletRequestWrapper;   
  
public class GetHttpServletRequestWrapper extends HttpServletRequestWrapper {   
  
    private String charset = "UTF-8";    
    public GetHttpServletRequestWrapper(HttpServletRequest request) {   
        super(request);   
    }   
  
    /**  
     * ��ñ�װ�ζ�������úͲ��õ��ַ�����  
     * @param request  
     * @param charset  
     */  
    public GetHttpServletRequestWrapper(HttpServletRequest request, String charset) {   
        super(request);   
        this.charset = charset;   
    }   
  
    /**  
     * @param  ʵ���Ͼ��ǵ��ñ���װ����������getParameter������ò�����Ȼ���ٽ��б���ת��  
     */ 
    @Override
    public String getParameter(String name) { 
    	
        String value = super.getParameter(name);
        value = value == null ? null : convert(value); 
        
        System.out.println("+++++++++++++++++++++++++++++++");
        System.out.println("getת������ַ���Ϊ�� " + value);
        System.out.println("+++++++++++++++++++++++++++++++");
        return value;   
    } 
    public String convert(String target) {   
    	System.out.println("+++++++++++++++++++++++++++++++");
        System.out.println("getת��ǰ���ַ���Ϊ��  " + target);
        System.out.println("+++++++++++++++++++++++++++++++");
        try {   
            return new String(target.trim().getBytes("ISO-8859-1"), this.charset);   
        } catch (UnsupportedEncodingException e) {   
            return target;   
        }   
    }   
  
}  
