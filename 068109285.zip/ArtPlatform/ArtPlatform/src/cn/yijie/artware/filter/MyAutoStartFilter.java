package cn.yijie.artware.filter;

import java.io.IOException;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import cn.yijie.artware.entity.Category;
import cn.yijie.artware.entity.News;
import cn.yijie.artware.service.ICategoryService;
import cn.yijie.artware.service.INewsService;

public class MyAutoStartFilter implements Filter {
	
	private WebApplicationContext wac = null ;
	

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse resp,
			FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		chain.doFilter(req, resp);
	}

	@Override
	public void init(FilterConfig cfg) throws ServletException {
		// TODO Auto-generated method stub
		
		ServletContext application = cfg.getServletContext() ;
		
		wac = WebApplicationContextUtils.getWebApplicationContext(application) ;
		ICategoryService categoryService  = (ICategoryService)wac.getBean("categoryService") ;
		INewsService newsService = (INewsService)wac.getBean("newsService") ;
		
		List<Category> allCategory = categoryService.findAllCategories() ;
		application.setAttribute("allCategory", allCategory) ;
		
		//ǰ̨չ�ֺ��������ļ�������
		List<News> frontNews = newsService.findNewsByLimitNumOrderByDate(4) ;
		application.setAttribute("frontNews", frontNews) ;
		
		
		System.out.println("---------------------------------------------");
		System.out.println("��������ʱ��ʼ����");
		System.out.println("---------------------------------------------");
	}

}
