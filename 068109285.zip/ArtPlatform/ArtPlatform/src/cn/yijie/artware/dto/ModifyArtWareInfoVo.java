package cn.yijie.artware.dto;

public class ModifyArtWareInfoVo {
	
	private String artWareName ;
	private double artWareNormalPrice ;
	private double artWareMemberPrice ;
	private String artWareDescr ;
	
	public String getArtWareName() {
		return artWareName;
	}
	public void setArtWareName(String artWareName) {
		this.artWareName = artWareName;
	}
	public double getArtWareNormalPrice() {
		return artWareNormalPrice;
	}
	public void setArtWareNormalPrice(double artWareNormalPrice) {
		this.artWareNormalPrice = artWareNormalPrice;
	}
	public double getArtWareMemberPrice() {
		return artWareMemberPrice;
	}
	public void setArtWareMemberPrice(double artWareMemberPrice) {
		this.artWareMemberPrice = artWareMemberPrice;
	}
	public String getArtWareDescr() {
		return artWareDescr;
	}
	public void setArtWareDescr(String artWareDescr) {
		this.artWareDescr = artWareDescr;
	}

}
