package cn.yijie.artware.utils;

import java.util.Collection;
import java.util.Iterator;

public class PrintCollectionUtil {
	
	public static void printEntities(Collection<?> ens){
		
		if(ens!= null&&ens.size()>0){
			for (Iterator <?>iterator = ens.iterator(); iterator.hasNext();) {
				
				System.out.println(iterator.next());
			}
		}else{
			
			System.out.println("û�в��ҵ���Ӧ��һ����¼��");
		}
	}

}
