package cn.yijie.artware.utils;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import cn.yijie.artware.entity.Admin;
import cn.yijie.artware.entity.User;

import com.opensymphony.xwork2.ActionContext;

public class AuthorityUtil {
	
	//����ĵ�¼�Ļ�Ա��״̬
	public static void saveUser(User user){
		
		Map<String ,Object> session = ActionContext.getContext().getSession() ;
		session.put("user_login", user) ;
	}
	//��ȡ��½�Ļ�Ա��״̬
	public static User getUser() {
		// TODO Auto-generated method stub
		 Map<String ,Object> session =ActionContext.getContext().getSession() ; 
		return (User)session.get("user_login") ;
	}
	//���HttpSevletSession
	public static HttpSession getSession(){
		
		return ServletActionContext.getRequest().getSession() ;
	}
	//�����¼�Ĺ���Ա��״̬
	public static void saveAdmin(Admin admin){
		
		Map<String ,Object> session = ActionContext.getContext().getSession() ;
		session.put("admin_login", admin) ;
	}
	
	//��ȡ��¼����Ա��״̬
	public static Admin getAdmin() {
		// TODO Auto-generated method stub
		Map<String ,Object> session =ActionContext.getContext().getSession() ; 
		return (Admin)session.get("admin_login") ;
	}
	
	
}
