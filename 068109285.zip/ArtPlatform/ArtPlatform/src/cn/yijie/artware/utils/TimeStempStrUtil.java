package cn.yijie.artware.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TimeStempStrUtil {
	
	public static String getTimeStempStr(){
		
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMddhhmmss")  ;
		Date date = new Date() ;
		String str = format.format(date) ;
		return str;
	}
	
	
	public static void main(String[] args) {
		
		String str = getTimeStempStr() ;
		System.out.println(str);
	}

}
