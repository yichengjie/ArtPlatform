package cn.yijie.artware.utils;

public class MyNunberUtil {
	
	public  static Integer getNumFromStr(String str){
		
		if(str!=null&&str.trim().length()>0&&str.matches("\\d*")){
			return Integer.parseInt(str) ;
		}else{
			return null ;
		}
	}
	
	public static void main(String[] args) {
		
		String str = "13a435" ;
		System.out.println(getNumFromStr(str));
	}
}
