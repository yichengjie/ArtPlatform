package cn.yijie.artware.utils;

import cn.yijie.artware.dto.ModifyArtWareInfoVo;
import cn.yijie.artware.entity.ArtWare;

public class ModifyArtWareUtil {
	
	public static ArtWare modify(ArtWare entity,ModifyArtWareInfoVo infoVo){
		
		if(infoVo.getArtWareName()!=null&&infoVo.getArtWareName().length()>0){
			entity.setName(infoVo.getArtWareName()) ;
		}
		
		if(infoVo.getArtWareDescr()!=null&&infoVo.getArtWareDescr().length()>0){
			
			entity.setDescr(infoVo.getArtWareDescr()) ;
		}
		
		if(infoVo.getArtWareNormalPrice()>0){
			entity.setNormalPrice(infoVo.getArtWareNormalPrice()) ;
		}
		
		if(infoVo.getArtWareMemberPrice()>0){
			
			entity.setMemberPrice(infoVo.getArtWareMemberPrice()) ;
		}
		
		return entity;
	}

}
