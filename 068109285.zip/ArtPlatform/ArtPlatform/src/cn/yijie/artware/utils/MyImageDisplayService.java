package cn.yijie.artware.utils;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;

public class MyImageDisplayService {
	
	public BufferedImage diplayImg(String size,String imgurl) throws IOException
    {
        BufferedImage img = ImageIO.read(new URL(imgurl));
        int old_w = img.getWidth(null);
        int old_h = img.getHeight(null);
        int width =0;
        int height = 0;
        if(size.split(",").length>1 && !size.startsWith(","))
        {
            width = Integer.parseInt(size.split(",")[0]);
            height = Integer.parseInt(size.split(",")[1]);
        }else
        {
            if(size.startsWith(","))
            {
                height = Integer.parseInt(size.split(",")[1]);
                return this.diplayImgwithheight(height, imgurl);
            }else
            {
                width = Integer.parseInt(size.split(",")[0]);
                return this.diplayImgwithwidth(width, imgurl);
            }
        }
        int new_w;
        int new_h;
        //�������
        double rate1 = 1.0 *  width/old_w;//�������ű���
        double rate2 = 1.0 *  height/old_h;//�ߵ����ű���
        if (rate1 > rate2) {
            new_w = (int) Math.round(1.0 *old_w*rate1);
            new_h = (int) Math.round(1.0 *old_h*rate1);
        } else {
            new_w = (int) Math.round(1.0 *old_w*rate2);
            new_h = (int) Math.round(1.0 *old_h*rate2);
        }


        BufferedImage buffImg = new BufferedImage(new_w, new_h, BufferedImage.TYPE_INT_RGB);
        Graphics g = buffImg.createGraphics();
        g.setColor(Color.white);
        g.fillRect(0, 0, new_w, new_h);
        g.drawImage(img, 0, 0, new_w, new_h, null);
        g.dispose();


        if(new_w>width){
            int x = (new_w-width)/2;
            buffImg = buffImg.getSubimage(x, 0, width, height);
        }else
        {
            int y = (new_h-height)/2;
            buffImg = buffImg.getSubimage(0, y, width, height);
        }
        return buffImg;

    }

    public BufferedImage diplayImgwithheight(int height,String imgurl) throws IOException
    {
        BufferedImage img = ImageIO.read(new URL(imgurl));
        int old_w = img.getWidth(null);
        int old_h = img.getHeight(null);

        int new_w;
        int new_h;
        //�������

        double rate2 = 1.0 *  height/old_h;//�ߵ����ű���

        new_w = (int) Math.round(1.0 *old_w*rate2);
        new_h = (int) Math.round(1.0 *old_h*rate2);



        BufferedImage buffImg = new BufferedImage(new_w, new_h, BufferedImage.TYPE_INT_RGB);
        Graphics g = buffImg.createGraphics();
        g.setColor(Color.white);
        g.fillRect(0, 0, new_w, new_h);
        g.drawImage(img, 0, 0, new_w, new_h, null);
        g.dispose();

        return buffImg;

    }

    public BufferedImage diplayImgwithwidth(int width,String imgurl) throws IOException
    {
        BufferedImage img = ImageIO.read(new URL(imgurl));
        int old_w = img.getWidth(null);
        int old_h = img.getHeight(null);

        int new_w;
        int new_h;
        //�������

        double rate2 = 1.0 *  width/old_w;//�ߵ����ű���

        new_w = (int) Math.round(1.0 *old_w*rate2);
        new_h = (int) Math.round(1.0 *old_h*rate2);



        BufferedImage buffImg = new BufferedImage(new_w, new_h, BufferedImage.TYPE_INT_RGB);
        Graphics g = buffImg.createGraphics();
        g.setColor(Color.white);
        g.fillRect(0, 0, new_w, new_h);
        g.drawImage(img, 0, 0, new_w, new_h, null);
        g.dispose();

        return buffImg;

    }
    public static void main(String[] args) throws IOException {
    	
        new MyImageDisplayService().diplayImg("198,153", "F:\\g.jpg");
       // String str = ",160";
        //System.out.println(str.split(",")[0]);
    }

}
