var checkStatusFlag = false;
function queryFormCheck(){
    document.queryform.target = "displayFrame";
    document.queryform.action = "registAction.action";
	var strNameTip = "" ;
	var flag1 = false;
	if(!checkStatusFlag){
		flag1 = checkUserNameExist() ;
	}
	strNameTip = $("#usernametip").html() ;
	$(".tip").html("");
	$("#usernametip").html(strNameTip) ;
	var flag2 = checkMyPassword("password") ;
    var flag3 = checkMyAddress("address", 3, 15);
	var flag4 = checkMyPhone("phone");
	var flag5 = checkMyEmail("email") ;
    if (!flag1&&flag2 && flag3 && flag4&&flag5) {
		//alert("ok") ;
        $("#queryform").submit() ;
    }
}
$(document).ready(function(){

    $("#username").bind("blur", function(){
        checkUserNameExist();
    });
    
});
function checkUserNameExist(){
	checkStatusFlag = true; 
	var flagname = false ;
	var flag1 = checkMyInputStatus("username", 3, 15);
	if(flag1){
	    var unameStr = $("#username").val();
		var usernametip = $("#usernametip") ;
	    $.ajax({
	        url: "/ArtPlatform/checkUserExistActin.action",
			type:"post" ,
			data :{registusername:unameStr} ,
			dataType:"json" ,
			beforeSend:function(){usernametip.html("<font size = '1px'>验证用户名</font>");} ,
	        success: function(data){
				var colorStr = "" ;
				if(data=="用户名已存在"){
					colorStr = "red" ;
					flagname = true ;
				}else{
					colorStr = "green" ;
					flagname = false;
				}
			   setMyTipInfo2("username","&nbsp;"+data,colorStr) ;
	        }
	    });
	}else{//如果初次检查不合格的话
		flagname = true;
	}
    return flagname ;
}
function checkMyAddress(inputId){
	var myAddressValue = getValueByInputId(inputId) ;
	if(myStrLength(myAddressValue)>0){
		var myAddressFlag = checkMyInputStatus(inputId, 3, 15);
		return myAddressFlag ;
	}else{
		return true ;
	}
	
}
function checkMyInputStatus(inputId, minLength, maxLength){
    var inputjq = $("#" + inputId);
    var len = inputjq.val().length;
    if (len >= minLength && len <= maxLength) {
        return true;
    }
    else {
        setMyTipInfo(inputId,"长度不满足("+minLength+"-"+maxLength+")位之间") ;
		return false;
    }
}
function checkMyEmail(inputId) {
	var myemailStr = $("#"+inputId).val() ;
	var myemailFlag = isEmail(myemailStr) ;
	if(!myemailFlag){
		setMyTipInfo(inputId,"&nbsp;邮箱格式有误") ;
	}
	return myemailFlag ;
}
function checkMyPassword(inputId){
	
	var strvalue = $("#"+inputId).val() ;
	var strflag = checkStrongPasswordType(strvalue) ;
	if(!strflag){
		setMyTipInfo(inputId,"&nbsp;密码强度太低(字母,数字,特殊字符)") ;
	}
	return strflag ;
}
function checkMyPhone(inputId){
	
	var myPhoneValue = getValueByInputId(inputId) ;
	
	if(myStrLength(myPhoneValue)>0){
		var myPhoneFlag = checkPhone(myPhoneValue) ;
		if(!myPhoneFlag){
			setMyTipInfo(inputId,"手机号码不合法") ;	
		}
		return myPhoneFlag ;
	}else{
		
		return true ;
	}
}
function getValueByInputId(inputId){
	
	return $("#"+inputId).val()  ;
}
function setMyTipInfo(inputId,tipInfo){
	
	$("#" + inputId + "tip").html("<font color = 'red' size = '1px'>&nbsp;"+tipInfo+"</font>");	
}
function setMyTipInfo2(inputId,tipInfo,colorStr){
	
	$("#" + inputId + "tip").html("<font color = '"+colorStr+"' size = '1px'>&nbsp;"+tipInfo+"</font>");	
}
function checkPhone(v){ 
    var a = /^((\(\d{3}\))|(\d{3}\-))?13\d{9}|14[57]\d{8}|15\d{9}|18\d{9}$/ ;    
    if( v.length!=11||!v.match(a) )  
    {    
		return false;   
    }  
    else{  
       return true ;  
    }  
}  
function isEmail(str) 
{
	regexp = /^([a-z,A-Z,0-9,_,-,.]+[@]{1}[a-z,A-Z,0-9,_,-]+[.]{1}[a-z,A-Z,0-9,_,-]+[.]{0,1}[a-z,A-Z,0-9,_,-,.]*)$/; 
	if (!(regexp.test(str)||str=="")) 
	{ 
		return false; 
	} 
		return true; 
}
function checkStrongPasswordType(str)
{
	var result = false;
	var str0 	= /[a-z]/g;
	var str1 	= /[A-Z]/g;
	var num 	= /[0-9]/g;
	var other	= /[\x21-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]/g;
	var all		= /^[\x21-\x7e]{8,}$/g;
	var i=4;
	if(all.test(str))
	{
		if(!str0.test(str)) i--;
		if(!str1.test(str)) i--;
		if(!num.test(str)) i--;
		if(!other.test(str)) i--;
		if(i>=3) result=true;
	}
	return result;
}
function myStrLength(s){
    var l = 0;
    var a = s.split("");
    for (var i = 0; i < a.length; i++) {
        if (a[i].charCodeAt(0) < 299) {
            l++;
        }
        else {
            l += 2;
        }
    }
    return l;
}
