function queryFormCheck(){
			$("form")//选择form    
			  .eq(1)//first()//选择第一个 第二个用eq(1) 最后一个 last()    
			  .attr("action", "loginAction.action")//更改属性    
			  .submit();//提交
        
}

 //验证码变换
function changeImage(img){
 //alert("空!!!");
 img.src = "image.jsp" ;
 img.src=img.src + "?" + new Date().getTime();
}

function focusOnText(inputId){
	$("#"+inputId).focus();
}

$(document).ready(function(){
	focusOnText("username") ;
}) ;

function checkForm() {	
	if (document.form1.netuserid.value == "") {
			  alert("用户名不能为空");
			 document.form1.netuserid.focus();
	   }
	  else if (document.form1.netuserid.value.indexOf("'")!=-1) {
			  alert("用户名含有非法字符:单引号");
			 document.form1.netuserid.focus();
	   }
	else if(document.form1.password.value == "") {
			  alert("密码不能为空");
			 document.form1.password.focus();
	   }
	else if(document.form1.rand.value == "") {
			  alert("请输入右图中的四位数字");
			 document.form1.rand.focus();
	   }
	else {form1.submit();}
}

function resetForm() {
	document.form1.reset();

}
function KeyPress() {
	InString=String.fromCharCode(window.event.keyCode);
	if (window.event.keyCode==13) {
	  if (document.form1.netuserid.value == "") {
			  alert("用户名不能为空");
			 document.form1.netuserid.focus();
	   }
	     else if (document.form1.netuserid.value.indexOf("'")!=-1) {
			  alert("用户名含有非法字符:单引号");
			 document.form1.netuserid.focus();
	   }
	  else if(document.form1.password.value == "") {
			  alert("密码不能为空");
			 document.form1.password.focus();
	   }
	  else if(document.form1.rand.value == "") {
			  alert("请输入右图中的四位数字");
			 document.form1.rand.focus();
	   }
	  else {form1.submit();}
											  
	}
}

/*
var checkStatusFlag = false;
var flag1 = false;
function queryFormCheck(){
        var strNameTip = "";
        if (!checkStatusFlag) {
            flag1 = checkUserNameExist();
        }
        strNameTip = $("#usernametip").html();
        $(".tip").html("");
        $("#usernametip").html(strNameTip);
		
        var flag2 = checkMyInputNotNull("password");
        if(flag1&&flag2){
			$("form")//选择form    
			  .eq(1)//first()//选择第一个 第二个用eq(1) 最后一个 last()    
			  .attr("action", "loginAction.action")//更改属性    
			  .submit();//提交
		}
        
}


$(document).ready(function(){
	
	$("#username").focus() ;
    $("#username").bind("blur", function(){
        checkUserNameExist();
    });
    
});

function checkUserNameExist(){
    	checkStatusFlag = true;
		
		var checkflag1 = checkMyInputStatus("username",3,15) ;
		if(checkflag1){
			var unameStr = $("#username").val();
	        var usernametip = $("#usernametip");
	        $.ajax({
	            url: "/ArtPlatform/checkUserExistActin.action",
	            type: "post",
	            data: {
	                registusername: unameStr
	            },
	            dataType: "json",
	            beforeSend: function(){
	                usernametip.html("<font size = '1px'>验证用户名</font>");
	            },
	            success: function(data){
	                var colorStr = "";
	                if (data == "用户名可用") {//用户名不存在的情况
	                    colorStr = "red";
	                    flag1 = false;
						setMyTipInfo2("username", "&nbsp;用户名不存在", colorStr);
	                }else{
						usernametip.html("");
						flag1 = true ;
					}
	            }
	        });
	    
	    	return flag1;
	}else{
		
		return false;
	}
        
}

function checkMyInputStatus(inputId, minLength, maxLength){
    var inputjq = $("#" + inputId);
    var len = inputjq.val().length;
    if (len >= minLength && len <= maxLength) {
        return true;
    }
    else {
        setMyTipInfo(inputId, "长度不满足(" + minLength + "-" + maxLength + ")位之间");
        return false;
    }
}

function checkMyInputNotNull(inputId){

    var inputjq = $("#" + inputId).val();
	var inputjqTemp = deleteBlankSpace(inputjq) ;
	var inputjqLen = myStrLength(inputjqTemp) ;
    if(inputjqLen>0){
		return true ;
	}else{
		setMyTipInfo(inputId,"&nbsp;这里不能为空 ！") ;
		return false ;
	}
    
}

function deleteBlankSpace(str){

    if (str != null && str.length>0) {
    	return str.replace(/[ ]/g, "");
    }else{
		return "" ;
	}
}

function myStrLength(s){
    var l = 0;
    var a = s.split("");
    for (var i = 0; i < a.length; i++) {
        if (a[i].charCodeAt(0) < 299) {
            l++;
        }
        else {
            l += 2;
        }
    }
    return l;
}

function setMyTipInfo(inputId, tipInfo){

    $("#" + inputId + "tip").html("<font color = 'red' size = '1px'>&nbsp;" + tipInfo + "</font>");
}

function setMyTipInfo2(inputId,tipInfo,colorStr){
	
	$("#" + inputId + "tip").html("<font color = '"+colorStr+"' size = '1px'>&nbsp;"+tipInfo+"</font>");	
}
*/