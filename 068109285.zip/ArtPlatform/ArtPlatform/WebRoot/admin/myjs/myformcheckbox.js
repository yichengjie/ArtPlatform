		$(document).ready(function(){
			$("#selectAll").click(mySelectAll) ;
		}) ;
		
		function mySelectAll(){
			var checked = $("#selectAll").attr("checked") ;
			$(".id").each(function(){
				var subchecked = $(this).attr("checked") ;
				if(subchecked!=checked){
					$(this).click() ;
				}
			}) ;
		}