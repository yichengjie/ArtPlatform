$(document).ready(function(){
	
	$("#mysubmit").bind("click",function(){
		queryFormCheck() ;
	}) ;
}) ;

//图片添加组件添加
function addMore(){
		var td = document.getElementById("more") ;/* 创建br元素 */
		var br = document.createElement("br") ;    /*创建表单元素*/
		var input = document.createElement("input") ;/*创建表单元素*/
		var button = document.createElement("input") ;/* 创建表单元素 */
		input.type = "file" ;                       /*设置变量input的属性  */
		input.name = "commonPicture" ;              
		button.type = "button" ;					/* 设置变量button的属性 */
		button.value = "Remove" ;		
		button.onclick = function(){               /* 单击变量Button的方法 */
			td.removeChild(br) ;						/* 移除br元素 */
			td.removeChild(input) ;						/* 移除input元素*/
			td.removeChild(button) ;					/* 移除button元素 */
		} ;				
		td.appendChild(br) ;                           /* 添加br元素 */
		td.appendChild(input) ;							/*添加button元素  */
		td.appendChild(button) ;						/*添加变量button的方法  */
}
//提交表单
function queryFormCheck(){
	$(".myinputtip").html("") ;
	var flag1 = checkMyInputNotNull("artWareName") ;
	var flag2 = checkMyPrice("artWareNormalPrice") ;
	var flag3 = checkMyPrice("artWareMemberPrice") ;
	var flag4 = CheckMyCharacter("artWareDescr") ;
	//alert("flag1 : " + flag1 + "  , flag2 : " + flag2 + "  , flag3 : " + flag3 +"  , flag4 : " + flag4  ) ;
	if(flag1&&flag2&&flag3&&flag4){
		$("form")//选择form    
		.eq(0)//first()//选择第一个 第二个用eq(1) 最后一个 last()    
		.attr("action", "/ArtPlatform/admin/addArtWareAction.action")//更改属性    
		.submit();//提交
	}
	
}

//检查非法字符如果合法返回true,非法返回false
function CheckMyCharacter(inputId){
	var strvalue = $("#"+inputId).val() ;
	if(strvalue!=null&&$.trim(strvalue).length>0){
		var flagttt = CheckCharacterforDescr(strvalue) ;
		if(flagttt){
			setMyTipInfo(inputId,"含非法字符!") ;
			return false ;
		}else{
			return true ;
		}
	}else{
		return true ;
	}
	
}
//检测价格是否为flot类型
function checkMyPrice(inputId){
	var tflag = checkMyInputNotNull(inputId) ;
	if(tflag){
		var strVale = $.trim($("#"+inputId).val()) ;
		var ttflag = isNumber(strVale,"float") ;
		if(!ttflag){
			setMyTipInfo(inputId,"请输入数字!") ;
			return false ;
		}else{
			return true ;
		}
	}else{
		return tflag ;
	}
}

//检查输入框是否为空
function checkMyInputNotNull(inputId){
    var inputjq = $("#" + inputId).val();
	var inputjqTemp = deleteBlankSpace(inputjq) ;
	var inputjqLen = myStrLength(inputjqTemp) ;
    if(inputjqLen>0){
		return true ;
	}else{
		setMyTipInfo(inputId,"&nbsp;这里不能为空 ！") ;
		return false ;
	}
}
//显示提示信息
function setMyTipInfo(inputId,tipInfo){
	
	$("#" + inputId + "tip").html("<font color = 'red' size = '1px'>&nbsp;"+tipInfo+"</font>");	
}
//删除空格
function deleteBlankSpace(str){

    if (str != null && str.length>0) {
    	return str.replace(/[ ]/g, "");
    }else{
		return "" ;
	}
}
//字符串长度
function myStrLength(s){
    var l = 0;
    var a = s.split("");
    for (var i = 0; i < a.length; i++) {
        if (a[i].charCodeAt(0) < 299) {
            l++;
        }
        else {
            l += 2;
        }
    }
    return l;
}



