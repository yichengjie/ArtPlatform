$(document).ready(function(){
	$("#mysubmit").bind("click",function(){
		queryFormCheck() ;
	}) ;
}) ;

//提交表单
function queryFormCheck(){
	$(".myinputtip").html("") ;
	var flag1 = checkMyNewsTitle("newsName") ;
	var flag2 = CheckMyCharacter("newsDescr") ;
	var flag3 = CheckMyCharacter("newsContent") ;
	if(flag1&&flag2&&flag3){
		$("form")//选择form    
		.eq(0)//first()//选择第一个 第二个用eq(1) 最后一个 last()    
		.attr("action", "/ArtPlatform/admin/addNewsAction.action")//更改属性    
		.submit();//提交
	}
}


function checkMyNewsTitle(inputId){
	var flagt1 = checkMyInputNotNull(inputId) ;
	if(flagt1){
		var flagt2 = CheckMyCharacter(inputId) ;
		return flagt2 ;
	}else{
		return false ;
	}
}

//检查非法字符如果合法返回true,非法返回false
function CheckMyCharacter(inputId){
	var strvalue = $("#"+inputId).val() ;
	if(strvalue!=null&&$.trim(strvalue).length>0){
		var flagttt = CheckCharacterforDescr(strvalue) ;
		if(flagttt){
			setMyTipInfo(inputId,"含非法字符!") ;
			return false ;
		}else{
			return true ;
		}
	}else{
		return true ;
	}
	
}

//检查输入框是否为空
function checkMyInputNotNull(inputId){
    var inputjq = $("#" + inputId).val();
	var inputjqTemp = deleteBlankSpace(inputjq) ;
	var inputjqLen = myStrLength(inputjqTemp) ;
    if(inputjqLen>0){
		return true ;
	}else{
		setMyTipInfo(inputId,"&nbsp;这里不能为空 ！") ;
		return false ;
	}
}
//显示提示信息
function setMyTipInfo(inputId,tipInfo){
	
	$("#" + inputId + "tip").html("<font color = 'red' size = '1px'>&nbsp;"+tipInfo+"</font>");	
}
//删除空格
function deleteBlankSpace(str){

    if (str != null && str.length>0) {
    	return str.replace(/[ ]/g, "");
    }else{
		return "" ;
	}
}
//字符串长度
function myStrLength(s){
    var l = 0;
    var a = s.split("");
    for (var i = 0; i < a.length; i++) {
        if (a[i].charCodeAt(0) < 299) {
            l++;
        }
        else {
            l += 2;
        }
    }
    return l;
}
