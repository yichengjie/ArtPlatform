
function checkall(){
	var flag = document.getElementById("checkFlag");
	var temp = document.getElementsByName("infoid"); 
    for (var i =0; i<temp.length; i++) 
     {
		temp[i].checked = flag.checked;				
     }	
}
function checkall2(id1,id2){
	var flag = document.getElementById(id1);
	var temp = document.getElementsByName(id2); 
    for (var i =0; i<temp.length; i++) 
     {
		temp[i].checked = flag.checked;				
     }	
}
function reSizeList(frameid)
{
	if(frameid==null||frameid=="")
	{
		frameid="displayFrame";
	}
	if(eval("parent."+frameid)!=null){
		 var oBody = eval("parent."+frameid+".document.body");
		 var oFrame = parent.document.all(frameid);
		 
		 var oWidth =  parent.document.body.scrollWidth-2;
		 var theWidth = oBody.scrollWidth + (oBody.offsetWidth - oBody.clientWidth);
		 if(oWidth!=theWidth && oBody.clientWidth!=0){
			 if(theWidth<oWidth)
				oFrame.style.width = oWidth;
			 else
				oFrame.style.width = theWidth;
		 }
		 oFrame.style.height = oBody.scrollHeight + (oBody.offsetHeight - oBody.clientHeight);
		 oFrame.style.height = oBody.scrollHeight + (oBody.offsetHeight - oBody.clientHeight);
	}
}
/* ����ѯ�б���ÿ�������¼��������� 2010-3-19 */
var IteResultTable = function(table, ifCanDrag,ifLight){
	if(typeof(table) == 'string'){
		table =  document.getElementById(table);
	}
	if(ifLight==null || !ifLight==false)
	{
		var lastTr = null;
		var bind = function(element, type, fn, data){
			var handle = function(event){
				return fn.call(element, (event || window.event), data);
			};
			if(window.addEventListener){
				element.addEventListener(type, handle, false);
			} else {
				element.attachEvent('on' + type, handle);
			}
		}
		bind(table, 'mousedown', function(evt){
			var tr = null;
			var e = evt.srcElement;
			while(e && e != table){
				if(e.tagName == 'TR'){
					tr = e;
				}
				e = e.parentNode;
			}
			if(table.rows[0] != tr && tr){
				if(lastTr){
					lastTr.style.backgroundColor = "#FFFFFF";
				}
				tr.style.backgroundColor = "#E4F5FF";
				lastTr = tr;
			}
		});
	}
	if(ifCanDrag === false)return;
	var speciaColumns={ 
		  '200': '�豸����,��������,Ӧ������,��·����,��·Ⱥ����,·������,�˿�����,����Ϣ,�����·����,ҵ������,�ͻ�����(����),��ͬ����(Mbps),���뽻����ip(�˿�),�ͻ�IP��ַ��,���涩��email��ַ,ADSL�豸,����ԭ��,��ϴ�豸', 
		  '120': 'ʱ��,����' 
		}; 

	var colResizePara__={fixWidth:false,speciaColumns:speciaColumns,onLoad:function(){if(ifCanDrag&&jQuery.isFunction(ifCanDrag))return ifCanDrag()}};
	if(typeof colResize == 'undefined') {
		if(typeof jQuery == 'undefined') 
			jsLazyLoad("/nms/Common/Scripts/jqueryandcolresizable-1.0.js",function(){colResize(table,colResizePara__)});
		else
			jsLazyLoad("/nms/Common/Scripts/colresizable-1.0.js",function(){colResize(table,colResizePara__)});
	}else
		colResize(table,colResizePara__);
}
function jsLazyLoad(a, b) {
	var c = document.createElement("script");
	if (typeof b != "undefined") {
		c.onload = function() {
			if (!c.called) {
				c.called = true;
				b()
			}
		};
		c.onreadystatechange = function() {
			if (!c.called)
				if ("loaded" == c.readyState || "complete" == c.readyState) {
					c.called = true;
					b()
				}
		}
	}
	c.src = a + (a.indexOf("?") != -1 ? "&" : "?") + "_=" + 1.0;
	document.getElementsByTagName("head")[0].appendChild(c)
}
function Trim(Liter){	
	return Liter.trim();
}
function ByteLength(inputstr){	
	return inputstr.getByteLength();
}
function transUrlParaCode(para)
{
	var s = para;
	if (para != null) 
	{
		s = para.replaceAll("%", "%25");
		s = s.replaceAll(" ", "%20");
		s = s.replaceAll("/", "%2F");
		s = s.replaceAll("#", "%23");
		s = s.replaceAll("\\+", "%2B");
		s = s.replaceAll("\\?", "%3F");
		s = s.replaceAll("&", "%26");
		s = s.replaceAll("\\=", "%3D");
	}
	return s;
}
String.prototype.getByteLength = function (){return this.replace(/[^\x00-\xff]/g,"00").length;}
String.prototype.trim = function(){return this.replace(/(^\s*)|(\s*$)/g, ""); }
String.prototype.replaceAll  = function(s1,s2){	return this.replace(new RegExp(s1,"gm"),s2); }

var waitingDivID__="waiting_loading_div_";
var waitingFrameID__="waiting_loading_frame_";
var waitingMsg____="�������ڽ���,���Ժ�...";
function IteBtnOperation(btnobj,sInnerHtml,option)
{
	if(typeof(btnobj) == 'string'){
		btnobj =  document.getElementById(btnobj);
	}	
	if(sInnerHtml=="" || sInnerHtml == null)
		btnobj.innerHTML = "<iframe id="+waitingFrameID__+" scrolling=\"no\" frameborder=\"0\" class=\"btn-waiting-absolutef\"></iframe><div  class=\"btn-waiting-absolute\"><div class=\"btn-waiting-icon\"></div><div class=\"btn-waiting-text\">"+waitingMsg____+"</div></div>";
	else
		btnobj.innerHTML = sInnerHtml;
	
}
var srcObj;
function showLoading(fnName,newWaitingMsg____){
	if(newWaitingMsg____)
		waitingMsg____ = newWaitingMsg____;
	document.onkeydown=function(){  
	    if (event.keyCode==116||event.keyCode==13) {  
	        event.keyCode = 0;  
	        event.cancelBubble = true;  
	        return false;  
	    } 
	} 

	var loadingObj=document.getElementById(waitingDivID__);
	if(!loadingObj){
		var iframe = document.createElement('<iframe id="'+waitingFrameID__+'" scrolling="no" frameborder="0" class="btn-waiting" style="display:none" > </iframe>');
		var outdiv=document.createElement('<div id="'+waitingDivID__+'" class="btn-waiting" style="display:none"></div>');
		outdiv.className="btn-waiting";
		var innerdiv1=document.createElement('<div class="btn-waiting-icon"></div>');
		innerdiv1.className="btn-waiting-icon";
		var innerdiv2=document.createElement('<div class="btn-waiting-text"></div>');
		innerdiv2.className="btn-waiting-text";
		var msg=document.createTextNode(waitingMsg____);
		outdiv.appendChild(innerdiv1);
		innerdiv2.appendChild(msg);
		outdiv.appendChild(innerdiv2);
		document.body.appendChild(iframe);
		document.body.appendChild(outdiv);
		loadingObj=document.getElementById(waitingDivID__);
	}
	srcObj = getSrcObj__(fnName);
	srcObj.disabled=true;
	loadingObj.style.display='';
	document.getElementById(waitingFrameID__).style.display='';
	var displayFrame=document.getElementById("displayFrame");
	if(displayFrame){
		if(window.addEventListener){
			displayFrame.addEventListener("load", hideLoading__, false);
		} else {
			displayFrame.attachEvent('onload', hideLoading__);
		}
	}
}
function getSrcObj__(name){
	try{
		var evt = (evt) ? evt : ((window.event) ? event : null);
		if(evt && evt.keyCode!=13){
			var srcObj = (window.event) ? evt.srcElement : evt.target; 
		}else{
			if(!name)
				name="queryFormCheck"; 
			var a=document.getElementsByTagName("A");
			for(var i=0;i<a.length;i++){
				var str=a[i].onclick?a[i].onclick.toString():a[i].getAttribute("href");
				if(str!=null&&str.indexOf(name)!=-1){
					if(a[i].firstChild.tagName!="IMG"||a[i].firstChild.width>20){
						srcObj = a[i];
						break;
					}
				}
			}
			if(!srcObj){
				a=document.getElementsByTagName("IMG");
				for(var i=0;i<a.length;i++){
					var str=a[i].onclick?a[i].onclick.toString():"";
					if(str.indexOf(name)!=-1){
						srcObj = a[i];
						break;
					}
				}
			}
		}
		if(srcObj.tagName=="SPAN")
			srcObj=srcObj.parentElement;		
	}catch(e){
		srcObj=document.body;
	}
	return srcObj;
}
function getFnName(callee){
	var _callee = callee.toString().replace(/[\s\?]*/g,""),  
	comb = _callee.length >= 50 ? 50 :_callee.length;  
	_callee = _callee.substring(0,comb);  
	var name = _callee.match(/^function([^\(]+?)\(/);  
	if(name && name[1]){  
	   return name[1];  
	}  
	var caller = callee.caller,  
	_caller = caller.toString().replace(/[\s\?]*/g,"");  
	var last = _caller.indexOf(_callee),  
	str = _caller.substring(last-30,last);  
	name = str.match(/var([^\=]+?)\=/);  
	if(name && name[1]){  
		return name[1];  
	}  
	return "anonymous" ;
}
function hideLoading__(){
	document.getElementById(waitingDivID__).style.display="none";
	document.getElementById(waitingFrameID__).style.display="none";
	srcObj.disabled=false;
	document.onkeydown=function(){  
	    if ( event.keyCode==116||event.keyCode==13) {  
	        return true;  
	    } 
	} 
}
var popupName__=new Array();
var currUrl____=new Array();
function loadPopup(para1,para2,para3){
	var exsit=false;
	for(var i=0;i<popupName__.length;i++){
		if(popupName__[i]&&popupName__[i].open&&!popupName__[i].closed&&currUrl____[i]==para1){
			popupName__[i].focus();
			exsit=true;
			break;
		}
	}
	if(!exsit) {
		var winName="window"+(Math.random()+"").substring(2);
		var iWidth="";
		var iHeight="";
		var isResizable="yes";
		if(para3){
			if(isNaN(para3)){
				winName=para2;
				para3=para3.toLowerCase().replace(/undefined/g,"").replace(/availwidth/g,"availWidth").replace(/availheight/g,"availHeight").replaceAll("'","").replaceAll('"','');
				var options=para3.split(",");
				for(var i=0;i<options.length;i++ ){
					var items = options[i].split("=");
					if(items[0].trim()=="width")
						iWidth=items[1];
					else if(items[0].trim()=="height")
						iHeight=items[1];
					else if(items[0].trim()=="resizable")
						isResizable=items[1];
				}
			}else{
				iWidth=para2;
				iHeight=para3;
			}
		}
		if(""==iWidth)iWidth=window.screen.availWidth;
		if(""==iHeight)iHeight=window.screen.availHeight;
		var iTop = (window.screen.availHeight-iHeight)/2;
		var iLeft = (window.screen.availWidth-iWidth)/2;
		var params='height='+iHeight+',innerHeight='+iHeight+',width='+iWidth+',innerWidth='+iWidth+',top='+iTop+',left='+iLeft+',toolbar=no,menubar=no,scrollbars=yes,resizable='+isResizable+',location=no,status=yes';
		popupName__.push(window.open(para1,winName,params));
		currUrl____.push(para1);
	}
}