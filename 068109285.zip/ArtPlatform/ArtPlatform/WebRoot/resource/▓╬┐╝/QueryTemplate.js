function queryFormCheck()
{
	document.queryform.target="displayFrame";	
	document.queryform.action="QueryListTemplate.jsp";	
	document.queryform.submit();
	showLoading(getFnName(arguments.callee));
}
function todelete()
{
	if(confirm("ȷ��Ҫɾ����?"))
	{
		queryform.action="TemplateOper.jsp";
		queryform.submit();
		showLoading(getFnName(arguments.callee));	
	}
}

function opennew()
{
    loadPopup("TemplateNew.jsp","","width=850,height=550,scrollbars=yes,resizable=no");
}
function openadd()
{
	loadPopup("TemplateAdd.jsp","","width=850,height=300,scrollbars=yes,resizable=no");
}
function openMod(idColumn)
{
    loadPopup("TemplateMod.jsp?idColumn="+idColumn,"","width=800,height=300,scrollbars=yes,resizable=no");
}
function openDetail(idColumn)
{
    loadPopup("TemplateDetail.jsp?idColumn="+idColumn,"","width="+screen.availWidth+",height="+screen.availHeight+",left=0,top=0,scrollbars=yes,resizable=no");
}
function exportExcel(){
	showLoading();
	var paras = "&nameColumn="+ $(":input[name=nameColumn]").val()+"&column3="+$(":input[name=column3]").val();
	$.get("TemplateOper.jsp?operType=exportExcel"+paras,function(data){
		loadPopup("/nms/Common/Inc/exportExcel.jsp?","exportwin","width=400,height=300")
		$("#path").val(data.trim());
		$("form").attr("action","TemplateOper.jsp").attr("target","exportwin").submit();
		hideLoading__();
	});
}