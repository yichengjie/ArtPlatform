/*******************************************************************
 函数名：	encode(word)
 功能：		屏蔽HTML
 入口参数：	word 		
 返回值：	按html格式返回提交的html文本
*******************************************************************/
function encode(word){
		
		 illegalchar=new Array('<','&','"',">",' ');
		var result="",result1="",temp="";
		for(var j=0;j<illegalchar.length;j++){
				//if (word.indexOf(illegalchar[j])!=-1){
					//for(int i=0;i<word.length;i++)
					while(word.indexOf(illegalchar[j])!=-1)
					{
						var k=word.indexOf(illegalchar[j])
						resultFirst=word.substring(0,k)
						//document.write("ww"+k)
						var c =word.charAt(k)
						switch (c)
						{
						  case '<' : temp="&lt;";
						    break;
						  case '&' : temp="＆";
									             
						    break;
						  case '>' : temp="&gt;";
							break;
						  case '"' : temp="&quot;";
							break;
						  case ' ' : temp="&nbsp;";
							break;
						// default : continue;
						}
						result=result+resultFirst+temp
						word=word.substring(k+1,word.length)
						 //document.write(result+"0"+temp+"0"+word.substring(0,k))
						//result=result+temp+word.substring(0,k)
						
						//word=word.substring(k+1,word.length)
						
						//document.write(u)
						//document.write(word+u)
						//document.write(word)
					}
				  //result=result+word
				 //document.write(word)
				 // result=result+word.substring(0,k)	
				}
		//document.write("www"+word)
		 result=result+word
		//document.write(result)
		if (result.length==0)
		   return word;
		  
		 //document.write(result)
		   return result;
		}
		
