/*
*修改记录: 日期，修改人，修改方法名（除：配置文件），任务号/bug号（规则同vss label），本次修改功能描述。
2010-12-02,杨静,BUG22686,isEmail()所用的正则表达式有问题，方括号中的-号前应加转义字符\，变为\-。 
2009-08-11,刘文博,ID1793,强密码的校验,2009080405
2009-06-30,刘文博,BUG13738,ID1627,提示非法字符--单引号
2009-02-23, 覃华云, ID1279，2009022002, 增加transUrlParaCode(),replaceAll()
2008-08-21,李丹,bug8147,增加函数CheckCharacterRight(Character),判断参数是否含有特殊字符（右键参数）
2008-07-10,李丹,bug7245,bug7248,增加函数CheckCharacterforDescr(Character),判断是否含有特殊字符和中文汉字。
2008-02-13,李丹,ID626,增加函数SplitStr(str,sep),将字符串str，按照标记sep拆分;FormatIPToAllIP(sIP)，将IP地址转换为全地址。
*/

/*******************************************************************
 函数名：	isNumber(inputstr,mode)
 功能：		判断inputstr是否为十进制的mode型数字（整型或浮点型）
 入口参数：	inputstr：。
 		mode: "float",浮点型；"int"，整型。
 返回值：	BOOLEAN型 （true/false）
*******************************************************************/
//---------------------------------------------------------------------------
  function isNumber(inputstr,mode){
  	 var str = " " + inputstr + " " ;
  	 var startindex, endindex ;
  	 var returnbool=true, tag = true ;
  	 var i ;
  	 var firstchar ;
  	 var negative = false, positive = false, unuse = false, zero = false ;
  	 startindex = str.indexOf(" ")
  	 endindex = str.lastIndexOf(" ")
  	 while(tag){
  	 	tag = false
  	 	firstchar = str.substring(startindex, startindex+1)
  	 	if(firstchar == " " && !zero){
  	 	  startindex++
  	 	  tag = true
  	 	  unuse=true
  	 	}else if( firstchar == "0" ){
  	 	  startindex++
  	 	  tag = true
  	 	  zero = true
  	 	}else if(firstchar == "-"){
  	 	  if(negative || positive || zero){returnbool = false}
  	 	  else{
  	 	  startindex++
  	 	  tag = true
  	 	  negative=true
  	 	  }
  	 	}else if(firstchar == "+"){
  	 	  if(negative || positive || zero){returnbool = false}
  	 	  else{
  	 	  startindex++
  	 	  tag = true
  	 	  positive=true
  	 	  }
  	 	}  
  	 	if(str.substring(endindex,endindex+1) <= " "){ //相当于RTrim()
  	 	  endindex--
  	 	  tag=true
  	 	}
  	 	if (endindex <= startindex) tag = false
  	}
    str = str.substring(startindex, endindex+1)
    if(returnbool){
  	 if (mode.toLowerCase() == "int"){
        if(str.indexOf(".")!=-1)returnbool=false;
  	 	else {
			if (negative) str = "-" + str
  			i = parseInt(str)
		}
  	 }
  	 else if(mode.toLowerCase() == "float"){
  	   if (str.substring(0,1) == ".") str = "0" + str
  	   if (negative) str = "-" + str
  	   i = parseFloat(str)
  	 }
  	 else i = parseFloat(str)
  	 if (i == str){
  	 	returnbool = true
  	 }
  	 else returnbool = false
  	 }
  	 return returnbool
  }
  /*******************************************************************
 函数名：	IPFormatting(IPstr)
 功能：		判断IPstr是否为合法的IP地址。
 入口参数：	IPstr：以西文"."作为分隔符的IP地址。（只识别十进制）
 返回值：	如果合法，返回对IPstr做必要处理后的IP地址字串；
 				否则，返回"Error"。
*******************************************************************/
//------------------------------------------------------------------
function IPFormatting(IPstr){
	if (IPstr==null)
	{
		return "Error";
	}
	if (IPstr=="")
	{
		return "Error";
	}
	//如果传入的IP地址不为空
	IPstr=IPstr+".";//加一个'.'以方便接下来以'.'为分隔符进行截取
	var i=1;
	var j;
	var temp="";//用于存储临时截取ip地址的每一段
	var ReturnIP="";//最后返回的ip地址
	while (IPstr.indexOf(".")!=-1)
	{
		if (i>4)
		{
			return "Error";
		}
		temp=IPstr.substring(0,IPstr.indexOf("."));
		while ((j=temp.indexOf(" "))!=-1)//如果数字前面有空格
		{
			temp=temp.substring(0,j)+temp.substring(j+1,temp.length);
		}
		j=0;
		while (temp.length>1)//去掉数字前面的0
		{
			if (temp.charAt(j)==0)
			{
				temp=temp.substring(1,temp.length);
			}
			else
			{
				break;
			}
		}
		if (!isNumber(temp,"int"))//进行整数验证
		{
			return "Error";
		}
		if (parseInt(temp)>255 || parseInt(temp)<0 || (parseInt(temp)==0 && i==1))//控制其大小不能超过255也不能小于0
		{
			return "Error";
		}
		ReturnIP = ReturnIP+parseInt(temp)+".";
		IPstr=IPstr.substring(IPstr.indexOf(".")+1,IPstr.length);
		i++;
	}
	if (i!=5)
	{
		return "Error";
	}
	return ReturnIP.substring(0,ReturnIP.length-1);
}	 	

  /*******************************************************************
 函数名：	IPPrefixFormatting(IPstr)
 功能：		判断IPstr是否为合法的IP地址前缀，例如10.0.0.1,10.0.0,10.0,10。
 入口参数：	IPstr：以西文"."作为分隔符的IP地址。（只识别十进制）
 返回值：	如果合法，返回对IPstr做必要处理后的IP地址字串；
 				否则，返回"Error"。
*******************************************************************/
//------------------------------------------------------------------
function IPPrefixFormatting(IPstr){
	if (IPstr==null)
	{
		return "Error";
	}
	if (IPstr=="")
	{
		return "Error";
	}
	//如果传入的IP地址不为空
	IPstr=IPstr+".";//加一个'.'以方便接下来以'.'为分隔符进行截取
	var i=1;
	var j;
	var temp="";//用于存储临时截取ip地址的每一段
	var ReturnIP="";//最后返回的ip地址
	while (IPstr.indexOf(".")!=-1)
	{
		if (i>4)
		{
			return "Error";
		}
		temp=IPstr.substring(0,IPstr.indexOf("."));
		while ((j=temp.indexOf(" "))!=-1)//如果数字前面有空格
		{
			temp=temp.substring(0,j)+temp.substring(j+1,temp.length);
		}
		j=0;
		while (temp.length>1)//去掉数字前面的0
		{
			if (temp.charAt(j)==0)
			{
				temp=temp.substring(1,temp.length);
			}
			else
			{
				break;
			}
		}
		if (!isNumber(temp,"int"))//进行整数验证
		{
			return "Error";
		}
		if (parseInt(temp)>255 || parseInt(temp)<0 || (parseInt(temp)==0 && i==1))//控制其大小不能超过255也不能小于0
		{
			return "Error";
		}
		ReturnIP = ReturnIP+parseInt(temp)+".";
		IPstr=IPstr.substring(IPstr.indexOf(".")+1,IPstr.length);
		i++;
	}
	if (i>5)
	{
		return "Error";
	}
	return ReturnIP.substring(0,ReturnIP.length-1);
}	 	 

 /*******************************************************************
 函数名：	IPV6Formatting(IPstr)
 功能：		判断IPstr是否为合法的IP地址。
 入口参数：	IPstr：以西文"."作为分隔符的IP地址。（只识别十进制）
 返回值：	如果合法，返回对IPstr做必要处理后的IP地址字串；
 				否则，返回"Error"。
********************************************************************/
//------------------------------------------------------------------
function IPV6Formatting(IPstr){
	if (IPstr==null)
	{
		return "Error";
	}
	if (IPstr=="")
	{
		return "Error";
	}
	
	var i = 0;	

	var marknum = 0;

	////不能出现两个::
	var mark1 = IPstr.indexOf("::");
	var mark2 = IPstr.lastIndexOf("::");
	if(mark1!=mark2)
	{
		return "Error";
	}

	////v4
	var tmpstr = IPstr;
	if(tmpstr.indexOf(".")>=0)
	{
		var v4tmp = tmpstr.substring(tmpstr.lastIndexOf(":")+1,tmpstr.length);
		if(IPFormatting(v4tmp).indexOf("Error")>=0)
		{
			return "Error";			
		}
		marknum = marknum +2;///:可少一个
		tmpstr = tmpstr.substring(0,tmpstr.lastIndexOf(":"));///v4部分不再检查
	}

	var strlen = tmpstr.length;
	for(i=0;i<strlen;i++)
	{
		var tmpchar = tmpstr.charAt(i);
		if(tmpchar!=':' && (tmpchar<'0' || tmpchar>'9') && (tmpchar<'a' || tmpchar>'f') && (tmpchar<'A' || tmpchar>'F'))
		{
			return "Error";
		}
	}
	
	/////
	tmpstr = tmpstr + ":";
	while(tmpstr.indexOf(":")!=-1)
	{
		var substr = tmpstr.substring(0,tmpstr.indexOf(":"));
		var tmplen = tmpstr.length;
		if(tmplen != tmpstr.indexOf(":")+1)
		{
			tmpstr = tmpstr.substring(tmpstr.indexOf(":")+1,tmpstr.length);
		}
		else
		{
			tmpstr = "";
		}
		if(substr!="")
		{
			if(substr.length>4)
			{
				return "Error";
			}
		}
		marknum=marknum+1;
		if(marknum>8)
		{
			return "Error";
		}
		
	}
	if(marknum<3)
	{
		return "Error";
	}
	if(mark1==-1 && marknum<8)
	{
		return "Error";
	}


	return IPstr;
}	 	 

/*******************************************************************
 函数名：	CheckCharacter(Character)
 功能：		判断Character是否含有非法字符。
 入口参数：	Character：需要检验的字符串
 返回值：	BOOLEAN型 （true/false）
                如果合法，返回false；
 				否则，返回true。
*******************************************************************/
//------------------------------------------------------------------
function CheckCharacter(Character){
	if (Character==null)
	{
		return false;
	}
	if (Character.indexOf("%")!=-1)
	{
		return true;
	}
	if (Character.indexOf("'")!=-1)
	{
		return true;
	}
	if (Character.indexOf(",")!=-1)
	{
		return true;
	}
	/*if (Character.indexOf(" ")!=-1)
	{
		return true;
	}*/
	if (Character.indexOf("&")!=-1)
	{
		return true;
	}
	if (Character.indexOf("=")!=-1)
	{
		return true;
	}
	if (Character.indexOf('"')!=-1)
	{
		return true;
	}
	if (Character.indexOf("·")!=-1)
	{
		return true;
	}
	if (Character.indexOf("——")!=-1)
	{
		return true;
	}
	if (Character.indexOf("<")!=-1)
	{
		return true;
	}
	if (Character.indexOf(">")!=-1)
	{
		return true;
	}
	return false;
}
/*还有中文返回true*/
function checkchinese(inputstr)
{
		for (var i=0;i<inputstr.length ;i++ )
		{
			var temp=inputstr.charAt(i);
			if (temp.charCodeAt()>16384 && temp.charCodeAt()<65024)
			{
				return true;
			}
		}
		return false;
}

/*******************************************************************
 函数名：	CheckCharacterRight(Character)
 功能：		判断Character是否含有非法字符，用于右键参数。
 入口参数：	Character：需要检验的字符串
 返回值：	BOOLEAN型 （true/false）
                如果合法，返回false；
 				否则，返回true。
*******************************************************************/
//------------------------------------------------------------------
function CheckCharacterRight(Character){
	if (Character==null)
	{
		return false;
	}
	if (Character.indexOf("%")!=-1)
	{
		return true;
	}
	if (Character.indexOf("'")!=-1)
	{
		return true;
	}
	if (Character.indexOf(",")!=-1)
	{
		return true;
	}
	if (Character.indexOf(" ")!=-1)
	{
		return true;
	}
	if (Character.indexOf("#")!=-1)
	{
		return true;
	}
	if (Character.indexOf("&")!=-1)
	{
		return true;
	}
	if (Character.indexOf("=")!=-1)
	{
		return true;
	}
	if (Character.indexOf('"')!=-1)
	{
		return true;
	}
	if (Character.indexOf("·")!=-1)
	{
		return true;
	}
	if (Character.indexOf("——")!=-1)
	{
		return true;
	}
	if (Character.indexOf("<")!=-1)
	{
		return true;
	}
	if (Character.indexOf(">")!=-1)
	{
		return true;
	}
	return false;
}
/*******************************************************************
 函数名：	CheckCharacterforOID(Character)
 功能：		判断Character是否含有非法字符。
 入口参数：	Character：需要检验的字符串
 返回值：	BOOLEAN型 （true/false）
                如果合法，返回false；
 				否则，返回true。
*******************************************************************/
//------------------------------------------------------------------
function CheckCharacterforOID(Character){
	if (Character==null)
	{
		return false;
	}
	if (Character.indexOf("%")!=-1)
	{
		return true;
	}
	if (Character.indexOf("'")!=-1)
	{
		return true;
	}
	if (Character.indexOf(",")!=-1)
	{
		return true;
	}
	/*if (Character.indexOf(" ")!=-1)
	{
		return true;
	}*/
	if (Character.indexOf("&")!=-1)
	{
		return true;
	}
	if (Character.indexOf("=")!=-1)
	{
		return true;
	}
	if (Character.indexOf('"')!=-1)
	{
		return true;
	}
	if (Character.indexOf("·")!=-1)
	{
		return true;
	}
	if (Character.indexOf("——")!=-1)
	{
		return true;
	}
	if (Character.indexOf("<")!=-1)
	{
		return true;
	}
	if (Character.indexOf(">")!=-1)
	{
		return true;
	}
	if (checkchinese(Character))
	{
		return true;
	}
	return false;
}
/*******************************************************************
 函数名：	CheckCharacterforDescr(Character)
 功能：		判断Character是否含有非法字符。
 入口参数：	Character：需要检验的字符串
 返回值：	BOOLEAN型 （true/false）
                如果合法，返回false；
 				否则，返回true。
*******************************************************************/
//------------------------------------------------------------------
function CheckCharacterforDescr(Character){
	if (Character==null)
	{
		return false;
	}
	if (Character.indexOf("%")!=-1)
	{
		return true;
	}
	if (Character.indexOf("'")!=-1)
	{
		return true;
	}
	if (Character.indexOf(",")!=-1)
	{
		return true;
	}
	if (Character.indexOf("&")!=-1)
	{
		return true;
	}
	if (Character.indexOf("=")!=-1)
	{
		return true;
	}
	if (Character.indexOf('"')!=-1)
	{
		return true;
	}
	if (Character.indexOf("<")!=-1)
	{
		return true;
	}
	if (Character.indexOf(">")!=-1)
	{
		return true;
	}
	if (checkchinese(Character))
	{
		return true;
	}
	return false;
}
/*******************************************************************
 函数名：	CheckParagraph(Paragraph)
 功能：		判断Character是否含有非法字符。
 入口参数：	Character：需要检验的字符串
 返回值：	BOOLEAN型 （true/false）
                如果合法，返回false；
 				否则，返回true。
*******************************************************************/
//------------------------------------------------------------------
function CheckParagraph(Paragraph){
	if (Paragraph==null)
	{
		return false;
	}
    if (Paragraph.indexOf("%")!=-1)
	{
		return true;
	}
	if (Paragraph.indexOf("'")!=-1)
	{
		return true;
	}
	if (Paragraph.indexOf("&")!=-1)
	{
		return true;
	}
	if (Paragraph.indexOf("=")!=-1)
	{
		return true;
	}
	if (Paragraph.indexOf("·")!=-1)
	{
		return true;
	}
	if (Paragraph.indexOf("——")!=-1)
	{
		return true;
	}
	if (Paragraph.indexOf("<")!=-1)
	{
		return true;
	}
	if (Paragraph.indexOf(">")!=-1)
	{
		return true;
	}
	return false;
}
/*******************************************************************
 函数名：	CheckmibOID(Liter)
 功能：		判断oid是否合法的oid格式。
 入口参数：	Liter-OID
 返回值：	BOOLEAN型 （true/false）
                如果合法，返回false；
 				否则，返回true。
*******************************************************************/
//------------------------------------------------------------------
function CheckmibOID(Liter){
	if (Liter==null)
	{return false;
	}
	if (Liter=="")
	{return false;
	}
	if (Liter.substring(0,1)!=".")
	{
		return true;
	}
	if (Liter.substring(Liter.length-1,Liter.length)==".")
	{
		return true;
	}
	var Symbol=0;
	for (var i=1;i<Liter.length ;i++ )
	{
		var temp=Liter.substring(i,i+1);
		if (temp!="." && (temp<"0" || temp>"9"))
		{
			return true;
		}
		else
		{
			if (temp=="." && Symbol==1)
			{
				return true;
			}
			if (temp==".")
			{Symbol=1;
			}else
			{Symbol=0;}
		}
	}
}
/*******************************************************************
 函数名：	strFilter(Liter)
 功能：		Filter,过滤字符串中指定的部分
 入口参数：	Liter:字符串
 返回值：	过滤字符串中指定的部分(将字符串Liter过滤掉aim部分)
*******************************************************************/
//------------------------------------------------------------------
function strFilter(Liter,aim){
	if (Liter==null)
	{
		return Liter;
	}
	if (Liter=="")
	{
		return Liter;
	}
	if (aim==null)
	{
		return Liter;
	}
	if (aim=="")
	{
		return Liter;
	}
	var foot=aim.length;
	var temp="";
	for (var i=0;i<Liter.length-foot+1 ;i++ )
	{
		temp=Liter.substring(i,i+foot);
		if (temp==aim)
		{
			Liter=Liter.substring(0,i)+Liter.substring(i+foot,Liter.length);
			i--;
		}
	}
	return Liter;
}
/*******************************************************************
 函数名：	wipeoffenter(Liter)
 功能：		Filter,过滤字符串中回车
 入口参数：	Liter:字符串
 返回值：	过滤字符串中回车
*******************************************************************/
//------------------------------------------------------------------
function wipeoffenter(Liter){
	if (Liter==null)
	{
		return Liter;
	}
	if (Liter=="")
	{
		return Liter;
	}
	Liter=Trim(Liter);
	var temp="";
	for (var i=0;i<Liter.length ;i++ )
	{
		temp=Liter.substring(i,i+1);
		if ((temp.charCodeAt(0)==13) || (temp.charCodeAt(0)==10))
		{
			Liter=Liter.substring(0,i)+Liter.substring(i+2,Liter.length);
		}
	}
	return Liter;
}
/*******************************************************************
 函数名：	Trim(Liter)
 功能：		Trim。
 入口参数：	Liter:字符串
 返回值：	去除前后空格的字符串
*******************************************************************/
//------------------------------------------------------------------
function Trim(Liter){
	if (Liter==null)
	{
		return Liter;
	}
	if (Liter=="")
	{
		return Liter;
	}
	for (var i=0;i<Liter.length ;i++ )
	{
		var temp=Liter.substring(i,i+1);
		if ((temp!=" ")&&(temp!="\t") && (temp.charCodeAt(0)!=13) && (temp.charCodeAt(0)!=10))
		{
			Liter=Liter.substring(i,Liter.length);
			break;
		}
	}
	for (var i=Liter.length;i>=0 ;i-- )
	{
		var temp=Liter.substring(i-1,i);
		if ((temp!=" ")&&(temp!="\t") && (temp.charCodeAt(0)!=13) && (temp.charCodeAt(0)!=10))
		{
			Liter=Liter.substring(0,i);
			break;
		}
	}
	return Liter;
}


/*******************************************************************
 函数名：	isUnderlineNumOrEngNotCh(inputstr)
 功能：		判断inputstr是否为数字,英文,或下划线
 入口参数：	inputstr 		
 返回值：	BOOLEAN型 （true/false）
                如果有数字，英文或下划线以外的字符，返回false
				否则返回true
*******************************************************************/
//---------------------------------------------------------------------------
function isUnderlineNumOrEngNotCh(inputstr){
	if (inputstr==null)
	{
		return false;
	}
	if (inputstr=="")
	{
		return false;
	}
	for (var i=0;i<inputstr.length ;i++ )
	{

		var temp=inputstr.charAt(i);
		if ((temp>="0" && temp<="9") || (temp>="a" && temp<="z") || (temp>="A" && temp<="Z")  || (temp=="_"))
		{
		}
		else
		{
			return false;
		}
	}
	return true;
}
/*******************************************************************
 函数名：	isUnderlineNumOrEng(inputstr)
 功能：		判断inputstr是否为数字,英文,中文或下划线
 入口参数：	inputstr 		
 返回值：	BOOLEAN型 （true/false）
                如果有数字，英文或下划线以外的字符，返回false
				否则返回true
*******************************************************************/
//---------------------------------------------------------------------------
function isUnderlineNumOrEng(inputstr){
	if (inputstr==null)
	{
		return true;
	}
	if (inputstr=="")
	{
		return true;
	}
	for (var i=0;i<inputstr.length ;i++ )
	{
		var temp=inputstr.charAt(i);
		if ((temp<"0" || temp>"9") && (temp<"a" || temp>"z") && (temp<"A" || temp>"Z") && (temp!="_") && (temp.charCodeAt()<16384 || temp.charCodeAt()>65024))
		{
			return false;
		}
	}
	return true;
}/*******************************************************************
 函数名：	isUnderlineNumOrEngLine(inputstr)
 功能：		判断inputstr是否为数字,英文,中文,下划线或"-"
 入口参数：	inputstr 		
 返回值：	BOOLEAN型 （true/false）
                如果有数字，英文或下划线以外的字符，返回false
				否则返回true
*******************************************************************/
//---------------------------------------------------------------------------
function isUnderlineNumOrEngLine(inputstr){
	if (inputstr==null)
	{
		return true;
	}
	if (inputstr=="")
	{
		return true;
	}
	for (var i=0;i<inputstr.length ;i++ )
	{
		var temp=inputstr.charAt(i);
		if ((temp<"0" || temp>"9") && (temp<"a" || temp>"z") && (temp<"A" || temp>"Z") && (temp!="_")&&(temp!="-") && (temp.charCodeAt()<16384 || temp.charCodeAt()>65024))
		{
			return false;
		}
	}
	return true;
}

/*******************************************************************
 函数名：	isDigitalOrEnglish(inputstr)
 功能：		判断inputstr是否为数字或英文
 入口参数：	inputstr 		
 返回值：	BOOLEAN型 （true/false）
*******************************************************************/
//---------------------------------------------------------------------------
function isDigitalOrEnglish(inputstr){
	if (inputstr==null)
	{
		return true;
	}
	if (inputstr=="")
	{
		return true;
	}
	for (var i=0;i<inputstr.length ;i++ )
	{
		var temp=inputstr.charAt(i);
		if ((temp<"0" || temp>"9") && (temp<"a" || temp>"z") && (temp<"A" || temp>"Z"))
		{
			return false;
		}
	}
	return true;
}

/*******************************************************************
 函数名：	isFileorDirName(inputstr)
 功能：		判断inputstr是否为合法的文件或目录名,是否只含有数字,字母,下划线,英文横杠和点,且只能以字母或数字开头
 入口参数：	inputstr 		
 返回值：	BOOLEAN型 （true/false）
*******************************************************************/
//---------------------------------------------------------------------------
function isFileorDirName(inputstr){
	if (inputstr==null)
	{
		return true;
	}
	if (inputstr=="")
	{
		return true;
	}
	for (var i=0;i<inputstr.length ;i++ )
	{
		var temp=inputstr.charAt(i);
		if ((temp<"0" || temp>"9") && (temp<"a" || temp>"z") && (temp<"A" || temp>"Z") && !(temp=="_" || temp=="-" || temp=="."))
		{
			return false;
		}
		if (i==0)
		{
			if (temp=="_" || temp=="-" || temp==".")
			{
				return false;
			}
		}
	}
	return true;
}

/*******************************************************************
 函数名：	isFileorDirNameIPv6(inputstr)
 功能：		判断inputstr是否为合法的文件或目录名,是否只含有数字,字母,下划线,英文横杠,点和冒号,且只能以字母或数字开头
 入口参数：	inputstr 		
 返回值：	BOOLEAN型 （true/false）
*******************************************************************/
//---------------------------------------------------------------------------
function isFileorDirNameIPv6(inputstr){
	if (inputstr==null)
	{
		return true;
	}
	if (inputstr=="")
	{
		return true;
	}
	for (var i=0;i<inputstr.length ;i++ )
	{
		var temp=inputstr.charAt(i);
		if ((temp<"0" || temp>"9") && (temp<"a" || temp>"z") && (temp<"A" || temp>"Z") && !(temp=="_" || temp=="-" || temp=="."||temp==":"))
		{
			return false;
		}
		if (i==0)
		{
			if (temp=="_" || temp=="-" || temp=="."||temp==":")
			{
				return false;
			}
		}
	}
	return true;
}
/*******************************************************************
 函数名：	ByteLength(inputstr)
 功能：		计算inputstr的字节长度
 入口参数：	inputstr 		
 返回值：	inputstr的字节长度
*******************************************************************/
//---------------------------------------------------------------------------
function ByteLength(inputstr){
	var Length=inputstr.length;
	for (var i=0;i<Length ;i++ )
	{
		var temp=inputstr.charAt(i);
		if (temp.charCodeAt()<0 || temp.charCodeAt()>255)
		{
			Length++;
		}
	}
	return Length;
}


/************************************************************************************
判断字符串str是否为Email格式（是否含有@符号），返回值为true或false
*************************************************************************************/
function isEmail(str) 
{ 
	regexp = /^([a-z,A-Z,0-9,_,\-,.]+[@]{1}[a-z,A-Z,0-9,_,\-]+[.]{1}[a-z,A-Z,0-9,_,\-]+[.]{0,1}[a-z,A-Z,0-9,_,\-,.]*)$/; 
	if (!(regexp.test(str)||str=="")) 
	{ 
		return false; 
	} 
		return true; 
}

/*******************************************************************
 函数名：	isResName(inputstr)
 功能：		判断inputstr是否由字母(a-z,A-Z)、数字(0-9)、下划线(_)、横杠(-)、点(.)，波浪号(~)、中英文小括号、中文字符和空格组成，且以字母和中文字符开头。不允许有其他字符（包括空格、#、@等）

 入口参数：	inputstr 		
 返回值：	BOOLEAN型 （true/false）
                如果有指定以外的字符，返回false
				否则返回true
*******************************************************************/
//---------------------------------------------------------------------------
function isResName(inputstr){
	if (inputstr==null)
	{
		return true;
	}
	if (inputstr=="")
	{
		return true;
	}
	for (var i=0;i<inputstr.length ;i++ )
	{
		var temp=inputstr.charAt(i);
		if ((temp<"0" || temp>"9") && (temp<"a" || temp>"z") && (temp<"A" || temp>"Z") && (temp!="_") && (temp.charCodeAt()<16384 || temp.charCodeAt()>65024) && !(temp=="(" || temp==")" || temp=="（" || temp=="）" || temp=="-" || temp=="." || temp=="~" || temp==" " || temp==":"))
		{
			return false;
		}
		if (i==0)
		{
			if ((temp<="9" && temp>="0") || ("_-.()（）~".indexOf(temp)!=-1))
			{
				return false;
			}
		}
	}
	return true;
}
/*******************************************************************
 函数名：	isResNameEn(inputstr)
 功能：		判断inputstr是否由字母(a-z,A-Z)、数字(0-9)、下划线(_)、横杠(-)、点(.)，波浪号(~)、英文小括号组成，且以字母开头。不允许有其他字符（包括空格、#、@等）

 入口参数：	inputstr 		
 返回值：	BOOLEAN型 （true/false）
                如果有指定以外的字符，返回false
				否则返回true
*******************************************************************/
//---------------------------------------------------------------------------
function isResNameEn(inputstr){
	if (inputstr==null)
	{
		return true;
	}
	if (inputstr=="")
	{
		return true;
	}
	for (var i=0;i<inputstr.length ;i++ )
	{
		var temp=inputstr.charAt(i);
		if ((temp<"0" || temp>"9") && (temp<"a" || temp>"z") && (temp<"A" || temp>"Z") && (temp!="_") && !(temp=="(" || temp==")" || temp=="（" || temp=="）" || temp=="-" || temp=="." || temp=="~" || temp==":" ))
		{
			return false;
		}
		if (i==0)
		{
			if ((temp<="9" && temp>="0") || ("_-.()（）~".indexOf(temp)!=-1))
			{
				return false;
			}
		}
	}
	return true;
}
/*******************************************************************
 函数名：	isResNameforQuery(inputstr)
 功能：		判断inputstr是否含有单引号'
 入口参数：	inputstr 		
 返回值：	BOOLEAN型 （true/false）
                如果有单引号，返回false
				否则返回true
*******************************************************************/
//---------------------------------------------------------------------------
function isResNameforQuery(inputstr){
	if (inputstr==null)
	{
		return true;
	}
	if (inputstr=="")
	{
		return true;
	}
	if(inputstr.indexOf("'")!=-1)
		return false;
	return true;
}
/*******************************************************************
 函数名：	checkResNameforQuery(obj,strName)
 功能：		判断obj.value是否有单引号，如果有提示:strName+"含有非法字符!"
 入口参数：	obj,strName		
 返回值：	BOOLEAN型 （true/false）
                如果有单引号，返回false
				否则返回true
*******************************************************************/
function checkResNameforQuery(obj,strName)
{
	if(!isResNameforQuery(obj.value))
	{
		obj.focus();
		alert(strName+"含有非法字符!");
		return false;
	}
	return true;
}
/************************************************************************************
输入掩码位数，得到掩码地址
*************************************************************************************/
function getMaskAddr(strBitNumber) 
{ 
	var bstring="";
	var strAddr="";
	var intBitNumber=parseInt(strBitNumber,10);
	for (var i=0;i<intBitNumber;i++)	bstring+="1";
	for (var i=intBitNumber;i<32;i++)	bstring+="0";
	var seg1 = parseInt(bstring.substring(0,8),2);
	var seg2 = parseInt(bstring.substring(8,16),2);
	var seg3 = parseInt(bstring.substring(16,24),2);
	var seg4 = parseInt(bstring.substring(24,32),2);
	strAddr = strAddr+seg1+"."+seg2+"."+seg3+"."+seg4;
	return strAddr;
}

/************************************************************************************
输入IP地址字符串，得到INT数值
*************************************************************************************/
function ipStrToInt(ipString)
{
    var begin=0;
    var end=0,segValue=0,returnValue=0;

    //分析地址前三段
    for(var i=0;i<3;i++)
    {
        //找不到"."分隔符，为非法IP
        end = ipString.indexOf(".",begin);
        if (end==-1) return 0;

        //数据不在0－255之间，为非法IP
        segValue=parseInt(ipString.substring(begin,end));
        if ((segValue<0) || (segValue>255)) return 0;

        //拼装返回值
        returnValue = (returnValue << 8) | segValue ;

        //下一段的起始点
        begin = end+1;

    }

    //地址最后一段数据不在0－255之间，为非法IP
    segValue=parseInt(ipString.substring(begin));
    if ((segValue<0) || (segValue>255)) return 0;

    //拼装最后一段
    returnValue = (returnValue << 8) | segValue ;

    //返回
    return returnValue;
}
	
/************************************************************************************
输入掩码位数，得到掩码INT数值
*************************************************************************************/
function getMaskIntValue(bitNumber)
{
    var maskIntValue = 0x80000000;
    if ((bitNumber<=0) || (bitNumber>32)) return 0;
    maskIntValue >>= (bitNumber - 1);
    return maskIntValue ;
}

/************************************************************************************
输入IP地址INT数值，得到字符串
*************************************************************************************/
function ipIntToStr(intIpString)
{
    var retValue="";
    var intValue=0;
    intValue = (intIpString&0xff000000)>>>24
	retValue += intValue ;
    retValue += ".";
    intValue = (intIpString&0x00ff0000)>>>16;
	retValue += intValue ;
    retValue += ".";
    intValue = (intIpString&0x0000ff00)>>>8;
	retValue += intValue ;
    retValue += ".";
    intValue = (intIpString&0x000000ff);
	retValue += intValue ;
    return retValue;
}

/************************************************************************************
输入IP地址及掩码位数，得到地址范围 ipmin-ipmax 如:10.0.0.0-10.0.0.255
*************************************************************************************/
function getIpRange(strIpAddr,strBitNumber)
{
    var mask=getMaskIntValue(strBitNumber);
    var minip=ipStrToInt(strIpAddr)&mask;
    var maxip=minip|(mask^0xffffffff);
    return ipIntToStr(minip)+"-"+ipIntToStr(maxip);
}

/************************************************************************
函数名： isDomainName(input)
功能　： 判断输入是否为合法的域名，即由字母a-z,A-Z,横杠-,数字0-9,及点.组成
传入参数：input 
输出：true  ,false
************************************************************************/
function isDomainName(input)
{
	if(input==null)return false;
	var result=false;
	var temp;
	var nextflag=false;//标记，下一字符能否为.或-
	for(var i=0;i<input.length;i++)
	{
		temp=input.charAt(i);
		if(!(temp>="a"&&temp<="z")&&!(temp>="A"&&temp<="Z")&&!(temp>="0"&&temp<="9")&&(temp!="-")&&(temp!="."))
			return false;
		if(!nextflag&&(temp=="-"||temp=="."))
			return false;
		if(i==input.length-1&&temp==".")
			return false;
		if(temp==".")
		{
			nextflag=false;
			result=true;
		}
		else
			nextflag=true;
	}
	return result;
}

/*******************************************************************
 函数名：	CheckOneCharacter(Paragraph,OneChar)
 功能：		判断Paragraph是否含有非法字符(串)OneChar
 入口参数：	Paragraph：需要检验的字符串,OneChar需要校验的非法字符(串)
 返回值：	BOOLEAN型 （true/false）
                如果合法，返回false；
 				否则，返回true。
*******************************************************************/
function CheckOneCharacter(Paragraph,OneChar){
	if (Paragraph==null)
	{
		return false;
	}
    if (Paragraph.indexOf(OneChar)!=-1)
	{
		return true;
	}	
	return false;
}
/*******************************************************************
 函数名：	CheckChars(Paragraph,Chars)
 功能：		判断Paragraph是否含有非法字符Chars中的每一个
 入口参数：	Paragraph：需要检验的字符串,Charsr需要校验的非法字符串
 返回值：	BOOLEAN型 （true/false）
                如果合法，返回false；
 				否则，返回true。
*******************************************************************/
function CheckChars(Paragraph,Chars)
{
	if (Paragraph==null)
	{
		return false;
	}
	for(var i=0;i<Chars.length;i++)
	{
		var OneChar = Chars.substring(i,i+1);
		if (Paragraph.indexOf(OneChar)!=-1)
		{
			return true;
		}
	}
	return false;
}


/*******************************************************************
 函数名：	checkLoopBackAddr(IPstr)
 功能：		判断 资源配置/设备配置/设备增加 中的Loopback地址是否正确,
			它应该支持202.97.3,202.97.3.1-127，218.30.254.79格式。
 入口参数：	IPstr 为需要校验的IP地址
 返回值：	BOOLEAN型 （true/false）
                如果合法，返回false；
 				否则，返回true。
 Author: Stephen John
*******************************************************************/
function checkLoopBackAddr(IPstr)
{
	// Condition1: the IPstr is null, "Error" will be returned.
	if (IPstr == null)
	{
		return "error:1";
	}
	

	// Condition2: the IPstr is "", "Error" will be returned.
	if (IPstr == "error:2")
	{
		return 2;
	}

	// Condition3: none of the above
	/* Condition3.1: if the IPstr contains ',', then IPstr will be divided into several 
	 * groups according to the separator ','。
	 */
	if (IPstr.indexOf(",") != -1)
	{

		IPstr = IPstr + ",";//add a ',' to the end of Ipstr to make it easy to divide the IPstr string by the separator ','。 
		var temp;
		var finalstr = "";
		while (IPstr.indexOf(",") != -1)
		{
			temp		= IPstr.substring(0, IPstr.indexOf(","))
			finalstr	= finalstr + checkLoopBackAddrDetail(temp)+",";
			IPstr		= IPstr.substring(IPstr.indexOf(",")+1, IPstr.length);
		}
		if (finalstr.indexOf("Error:3")!= -1)
		{
			return "Error:3";
		}
		if (finalstr.indexOf("Error:4")!= -1)
		{
			return "Error:4";
		}
		if (finalstr.indexOf("Error:5")!= -1)
		{
			return "Error:5";
		}
		else
		{
			return finalstr.substring(0, finalstr.length-1);
		}	 
	}

	/*Condition3.2: if the IPstr doesn't contain ',' */
	else
	{
		//alert("missing u");
		var finalstr = checkLoopBackAddrDetail(IPstr);
		
		if (finalstr.indexOf("Error:3")!= -1)
		{
			return "Error:3";
		}
		if (finalstr.indexOf("Error:4")!= -1)
		{
			return "Error:4";
		}
		if (finalstr.indexOf("Error:5")!= -1)
		{
			return "Error:5";
		}
		else
		{
			return finalstr;
		}

	}//end of else


}



//------------------------------------------------------------------------------------------------------------------------------------------
function checkLoopBackAddrDetail(IPstr)
{
	
		var temp;					//store each substring of the TempIPstr string which is divided into several groups
		var i = 1;					//indicate which substring has been loaded
		var j = 0;					//just a flag, see if the last substring of the TempIPstr contains '-'
		var k ;						//a temporary variable
		var x = 0;					//the number of "-" that TempIPstr contains.
		var n = 0;					//the number of ":" that TempIPstr contains.
		
		//see if IPstr contains '-'
		for (var a=0; a<IPstr.length ; a++)
		{
			/* if TempIPstr contains "-" */
			if (IPstr.charAt(a) == '-' )
			{
				x++;
			}
			//alert("x = "+ x);
		}//end of for

		if (x>0)//that means TempIPstr contains "-";
		{
				var TempIPstr	= IPstr;
				TempIPstr		= TempIPstr + ".";
				IPstr			= "";					//the final ip address that will be returned.

				/* loop the whole TempIPstr */
				while (TempIPstr.indexOf(".") != -1)
				{
						var b = 0; // a temporary variable
						var c = 0; // a temporary variable

						/* if TempIPstr has more than four groups, then return "Error" 
						if (i>4)
						{
							return "Error";
						}*/
						
						temp = TempIPstr.substring(0, TempIPstr.indexOf("."));

						/* see if the last substring of the TempIPstr contains "-", indicated through the variable j */
						
						for (var a=0; a<temp.length ; a++)
						{
							/* if temp contains "-" */
							if (temp.charAt(a) == '-' )
							{
								b++;
							}
							
						}//end of for
						
						for (var a=0; a<temp.length ; a++)
						{
							/* if temp contains ":" */
							if (temp.charAt(a) == ':' )
							{
								c++;
							}
							
						}//end of for

						if (c>0) // this means temp contains ":"
						{
							return "Error:3";
						}

						if (x > 0) //that means temp contains "-";
						{

							if (x != 1)
							{
								return "Error:3";
							}
							if (x == 1 && b == 1)
							{

								j = i;//store the info that which substring of TempIPstr is being loaded.
								var part1;
								var part2;
								part1 =	temp.substring(0, temp.indexOf("-"));

								part2 = temp.substring(temp.indexOf("-")+1, temp.length);

								/* if part1 or part2 is "", then "Error" would be returned. */
								while ((k = part1.indexOf(" "))!=-1)//如果数字前面有空格
								{
									part1 = part1.substring(0, k) + part1.substring(k+1, part1.length);
								}
								while ((k = part2.indexOf(" "))!=-1)//如果数字前面有空格
								{
									part2 = part2.substring(0, k) + part2.substring(k+1, part2.length);
								}
								k=0;
								while (part1.length>1)//去掉数字前面的0
								{
									if (part1.charAt(k)==0)
									{
										part1 = part1.substring(1, part1.length);
									}
									else
									{
										break;
									}
								}
								while (part2.length>1)//去掉数字前面的0
								{
									if (part2.charAt(k)==0)
									{
										part2 = part1.substring(1, part2.length);
									}
									else
									{
										break;
									}
								}
								if (!isNumber(part1,"int"))//进行整数验证
								{
									return "Error:3";
								}
								if (!isNumber(part2,"int"))//进行整数验证
								{
									return "Error:3";
								}
								if (parseInt(part1)>255 || parseInt(part1)<0 || (parseInt(part1)==0 && i==1))//控制其大小不能超过255也不能小于0
								{
									return "Error:3";
								}
								if (parseInt(part2)>255 || parseInt(part2)<0 || (parseInt(part2)==0 && i==1))//控制其大小不能超过255也不能小于0
								{
									return "Error:3";
								}
								if (parseInt(part1) >= parseInt(part2))//if part1 >= part2
								{
									//alert(">255");
									return "Error:4";
								}
								temp	= parseInt(part1) + "-" + parseInt(part2);

							}//end of if (x == 1 && b == 1)
							/*if (i < 4)
							{
								IPstr	= IPstr + parseInt(temp)+".";	
							}*/
							//if (i == 4)
							//{
							IPstr	= IPstr + temp +".";
							//}			
							
							TempIPstr	= TempIPstr.substring(TempIPstr.indexOf(".")+1, TempIPstr.length);

						}//end of if

						else//if temp contains no "-";
						{
							/*
							while ((k = temp.indexOf(" "))!=-1)//如果数字前面有空格
							{
								temp = temp.substring(0, k) + temp.substring(k+1, temp.length);
							}
							k=0;
							while (temp.length>1)//去掉数字前面的0
							{
								if (temp.charAt(k)==0)
								{
									temp = temp.substring(1, temp.length);
								}
								else
								{
									break;
								}
							}
							if (!isNumber(temp,"int"))//进行整数验证
							{
								return "Error";
							}
							
							if (parseInt(temp)>255 || parseInt(temp)<0 || (parseInt(temp)==0 && i==1))//控制其大小不能超过255也不能小于0
							{
								return "Error";
							}
							IPstr		= IPstr + parseInt(temp)+".";
							TempIPstr	= TempIPstr.substring(TempIPstr.indexOf(".")+1, TempIPstr.length);*/

						}//end of else

						i++;
				
				}//end of while

				/* if j is not 4, it means that not the last substring of the TempIPstr contains "-" */
				if (j > 0 && j != 4)
				{
					return "Error:3";
				}
				return IPstr.substring(0, IPstr.length-1);
		}//end of if (x>0)
		else 
		{
				//alert("4444");
				return IPstr;
		}
		
		
		

}
//------------------------------------------------------------------------------------------------------------------------------------------

/*******************************************************************
 函数名：	isDigital(inputstr)
 功能：		判断inputstr是否为数字
 入口参数：	inputstr 		
 返回值：	BOOLEAN型 （true/false）
*******************************************************************/
//---------------------------------------------------------------------------
function isDigital(inputstr){
	if (inputstr==null)
	{
		return true;
	}
	if (inputstr=="")
	{
		return true;
	}
	for (var i=0;i<inputstr.length ;i++ )
	{
		var temp=inputstr.charAt(i);
		if ((temp<"0" || temp>"9"))
		{
			return false;
		}
	}
	return true;
}

/*******************************************************************
 函数名：	isEnglish(inputstr)
 功能：		判断inputstr是否为英文
 入口参数：	inputstr 		
 返回值：	BOOLEAN型 （true/false）
*******************************************************************/
//---------------------------------------------------------------------------
function isEnglish(inputstr){
	if (inputstr==null)
	{
		return true;
	}
	if (inputstr=="")
	{
		return true;
	}
	for (var i=0;i<inputstr.length ;i++ )
	{
		var temp=inputstr.charAt(i);
		if ((temp<"a" || temp>"z") && (temp<"A" || temp>"Z"))
		{
			return false;
		}
	}
	return true;
}


/*******************************************************************
 函数名：	SplitStr(str,sep)
 功能：		将字符串str，按照标记sep拆分
 入口参数：	str：被拆分字符串，sep：拆分标记
 返回值：	拆分后的字符串数组
*******************************************************************/
//------------------------------------------------------------------
function SplitStr(str,sep)
{
	//alert("str"+str);
	if(sep==null||sep=="")
		sep=' ';	
	//alert("2");
	var result=new Array();

	var r=0;
	
	if(sep!=null)
	{			
		var start=0,count=0;

		//alert("3");

		while(start+count<str.length)
		{
			if(sep.indexOf(str.charAt(start+count))==-1)
			{
				//alert("count++:"+str.charAt(start+count));
				count++;
			}
			else
			{				
				if(count==0)
					start++;
				else
				{
					result[r++]=str.substring(start,start+count);
					//alert("str:"+str.substring(start,start+count));
					start+=count;
					count=0;
				}
			}			
		}

		//alert("4");
		if(count!=0)
		{
			result[r++]=str.substring(start,start+count);
		}			
	}
	return result;	
}


/*******************************************************************
 函数名：	FormatIPToAllIP(sIP)
 功能：		将10.0.0.2转换为010.000.000.002格式
 入口参数：	sIP:IP地址
 返回值：	标准格式IP地址
*******************************************************************/
//------------------------------------------------------------------
	function FormatIPToAllIP(sIP) 
    {
    	//alert("begin formatIP");
		var result = "";
		
		var loc = sIP.indexOf(".");
		var ip1 = Trim(sIP.substring(0,loc));
		var loc1 = sIP.indexOf(".",loc+1);
		var ip2 = Trim(sIP.substring(loc+1,loc1));
		loc = loc1;
		loc1 = sIP.indexOf(".",loc+1);
		var ip3 = Trim(sIP.substring(loc+1,loc1));
		var ip4 = Trim(sIP.substring(loc1+1,sIP.length));
		
		//alert(sIP);
		//alert(ip1.length);
		//alert(ip2.length);
		//alert(ip3.length);
		//alert(ip4.length);
		
		if(ip1.length == 1) 
        {
			result += "00" + ip1;
		}
		else
		{
			if(ip1.length == 2) 
			{
				result += "0" + ip1;
			}
			else
			{
				if(ip1.length == 3) 
				{
					result += ip1;
				}
			}
		}
		result += ".";
		
		if(ip2.length == 1) 
        {
			result += "00" + ip2;
		}
		else
		{
			if(ip2.length == 2) 
			{
				result += "0" + ip2;
			}
			else
			{
				if(ip2.length == 3) 
				{
					result += ip2;
				}
			}
		}
		result += ".";
		
		if(ip3.length == 1) 
        {
			result += "00" + ip3;
		}
		else
		{
			if(ip3.length == 2) 
			{
				result += "0" + ip3;
			}
			else
			{
				if(ip3.length == 3) 
				{
					result += ip3;
				}
			}
		}
		result += ".";
		
		if(ip4.length == 1) 
        {
			result += "00" + ip4;
		}
		else
		{
			if(ip4.length == 2) 
			{
				result += "0" + ip4;
			}
			else
			{
				if(ip4.length == 3) 
				{
					result += ip4;
				}
			}
		}
		
		//alert(result);
		
        return result;
    }

	/*******************************************************************
	 函数名：	getByteLength()
	 功能：		取得当前字符串的长度，中文为2个字符
	 入口参数：	无
	 返回值：	当前字符串的长度
	*******************************************************************/
	//------------------------------------------------------------------
	String.prototype.getByteLength = function ()
	{
	  return this.replace(/[^\x00-\xff]/g,"00").length;
	}


/*******************************************************************
	 函数名：	transUrlParaCode()
	 功能：		转化url链接中参数的特殊字符:% 空格 / # + ? & =,只能用于参数值，不可加在整个url前

	 入口参数：	字符串
	 返回值：	字符串
*******************************************************************/
function transUrlParaCode( para) {
    var s = para;
    if (para != null) {
      s = para.replaceAll("%", "%25");
      s = s.replaceAll(" ", "%20");
      s = s.replaceAll("/", "%2F");
      s = s.replaceAll("#", "%23");
      s = s.replaceAll("\\+", "%2B");
      s = s.replaceAll("\\?", "%3F");
      s = s.replaceAll("&", "%26");
      s = s.replaceAll("\\=", "%3D");
    }
    return s;
  }

/*******************************************************************
	 函数名：	replaceAll()
	 功能：		全部替换字符串中某字符为另外的字符
	 入口参数：	s1 要替换的字符串,s2替换后的字符串
	 返回值：   字符串
*******************************************************************/
String.prototype.replaceAll  = function(s1,s2){    
return this.replace(new RegExp(s1,"gm"),s2);    
} 

/*******************************************************************
	 函数名：	checkStrongPasswordType(str)
	 功能：		强密码的校验： 1、密码必须同时包含以下3到4种元素：大写字母、小写字母、数字，还有特殊字符（例如标点符号） 2、密钥长度不少于8位。
	 入口参数：	str 要校验的字符串
	 返回值：   boolean 是否校验通过
*******************************************************************/
function checkStrongPasswordType(str)
{
	var result = false;
    var str0 	= /[a-z]/g;//小写字母
	var str1 	= /[A-Z]/g;//大写字母
	var num 	= /[0-9]/g;//数字
	var other	= /[\x21-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]/g;//特殊字符
	var all		= /^[\x21-\x7e]{8,}$/g;//强密码条件
	
	var i=4;
	if(all.test(str))
	{
		if(!str0.test(str)) i--;
		if(!str1.test(str)) i--;
		if(!num.test(str)) i--;
		if(!other.test(str)) i--;
		
		if(i>=3) result=true;
	}

	return result;
}
/*******************************************************************
	 函数名：	LimitLength(obj,slength)
	 功能：		控件限制长度
	 入口参数：	
	 返回值：   
*******************************************************************/
function LimitLength(obj,slength)
{
	if(obj)
	{
		if(obj.value.getByteLength()>slength)
		{
			alert("最多可以输入"+slength+"个字符");
			obj.focus();
			return ;
		}
	}
}