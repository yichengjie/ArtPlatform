function isResNameforQuery(inputstr)
{
	if (inputstr==null)
	{
		return true;
	}
	if (inputstr=="")
	{
		return true;
	}
	if(inputstr.indexOf("'")!=-1)
		return false;
	return true;
}

function checkResNameforQuery(obj,strName)
{
	if(!isResNameforQuery(obj.value))
	{
		obj.focus();
		alert(strName+"含有非法字符!");
		return false;
	}
	return true;
}

function isResName(inputstr)
{
	if (inputstr==null)
	{
		return true;
	}
	if (inputstr=="")
	{
		return true;
	}
	for (var i=0;i<inputstr.length ;i++ )
	{
		var temp=inputstr.charAt(i);
		if ((temp<"0" || temp>"9") && (temp<"a" || temp>"z") && (temp<"A" || temp>"Z") && (temp!="_") && (temp.charCodeAt()<16384 || temp.charCodeAt()>65024) && !(temp=="(" || temp==")" || temp=="（" || temp=="）" || temp=="-" || temp=="." || temp=="~" || temp==" " || temp==":"))
		{
			return false;
		}
		if (i==0)
		{
			if ((temp<="9" && temp>="0") || ("_-.()（）~".indexOf(temp)!=-1))
			{
				return false;
			}
		}
	}
	return true;
}

function isResNameEn(inputstr)
{
	if (inputstr==null)
	{
		return true;
	}
	if (inputstr=="")
	{
		return true;
	}
	for (var i=0;i<inputstr.length ;i++ )
	{
		var temp=inputstr.charAt(i);
		if ((temp<"0" || temp>"9") && (temp<"a" || temp>"z") && (temp<"A" || temp>"Z") && (temp!="_") && !(temp=="(" || temp==")" || temp=="（" || temp=="）" || temp=="-" || temp=="." || temp=="~" || temp==":" ))
		{
			return false;
		}
		if (i==0)
		{
			if ((temp<="9" && temp>="0") || ("_-.()（）~".indexOf(temp)!=-1))
			{
				return false;
			}
		}
	}
	return true;
}

function isDomainName(input)
{
	if(input==null)return false;
	var result=false;
	var temp;
	var nextflag=false;
	for(var i=0;i<input.length;i++)
	{
		temp=input.charAt(i);
		if(!(temp>="a"&&temp<="z")&&!(temp>="A"&&temp<="Z")&&!(temp>="0"&&temp<="9")&&(temp!="-")&&(temp!="."))
			return false;
		if(!nextflag&&(temp=="-"||temp=="."))
			return false;
		if(i==input.length-1&&temp==".")
			return false;
		if(temp==".")
		{
			nextflag=false;
			result=true;
		}
		else
			nextflag=true;
	}
	return result;
}
function CheckmibOID(Liter)
{
	if (Liter==null)
	{
		return false;
	}
	if (Liter=="")
	{
		return false;
	}
	if (Liter.substring(0,1)!=".")
	{
		return true;
	}
	if (Liter.substring(Liter.length-1,Liter.length)==".")
	{
		return true;
	}
	var Symbol=0;
	for (var i=1;i<Liter.length ;i++ )
	{
		var temp=Liter.substring(i,i+1);
		if (temp!="." && (temp<"0" || temp>"9"))
		{
			return true;
		}
		else
		{
			if (temp=="." && Symbol==1)
			{
				return true;
			}
			if (temp==".")
			{
				Symbol=1;
			}
			else
			{
				Symbol=0;
			}
		}
	}
}

function isEmail(str) 
{
	regexp = /^([a-z,A-Z,0-9,_,-,.]+[@]{1}[a-z,A-Z,0-9,_,-]+[.]{1}[a-z,A-Z,0-9,_,-]+[.]{0,1}[a-z,A-Z,0-9,_,-,.]*)$/; 
	if (!(regexp.test(str)||str=="")) 
	{ 
		return false; 
	} 
		return true; 
}

function checkStrongPasswordType(str)
{
	var result = false;
	var str0 	= /[a-z]/g;
	var str1 	= /[A-Z]/g;
	var num 	= /[0-9]/g;
	var other	= /[\x21-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]/g;
	var all		= /^[\x21-\x7e]{8,}$/g;
	var i=4;
	if(all.test(str))
	{
		if(!str0.test(str)) i--;
		if(!str1.test(str)) i--;
		if(!num.test(str)) i--;
		if(!other.test(str)) i--;
		if(i>=3) result=true;
	}
	return result;
}